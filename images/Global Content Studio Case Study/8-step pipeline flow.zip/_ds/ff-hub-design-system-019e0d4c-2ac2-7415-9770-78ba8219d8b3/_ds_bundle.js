/* @ds-bundle: {"format":4,"namespace":"FinancialFinesseDesignSystem_019e0d","components":[{"name":"Icon","sourcePath":"assets/icons/Icon.jsx"},{"name":"AimeeLogo","sourcePath":"components/brand/AimeeLogo.jsx"},{"name":"Logo","sourcePath":"components/brand/Logo.jsx"},{"name":"AccentButton","sourcePath":"components/buttons/AccentButton.jsx"},{"name":"Button","sourcePath":"components/buttons/Button.jsx"},{"name":"NavButton","sourcePath":"components/buttons/NavButton.jsx"},{"name":"PrimaryButton","sourcePath":"components/buttons/PrimaryButton.jsx"},{"name":"SecondaryButton","sourcePath":"components/buttons/SecondaryButton.jsx"},{"name":"TertiaryButton","sourcePath":"components/buttons/TertiaryButton.jsx"},{"name":"Accordion","sourcePath":"components/content/Accordion.jsx"},{"name":"Avatar","sourcePath":"components/content/Avatar.jsx"},{"name":"Chip","sourcePath":"components/content/Chip.jsx"},{"name":"ChipStructure","sourcePath":"components/content/ChipStructure.jsx"},{"name":"ContentChips","sourcePath":"components/content/ContentChips.jsx"},{"name":"ContentTags","sourcePath":"components/content/ContentTags.jsx"},{"name":"ContentThumbnailCard","sourcePath":"components/content/ContentThumbnailCard.jsx"},{"name":"ImagePlaceholder","sourcePath":"components/content/ImagePlaceholder.jsx"},{"name":"Tag","sourcePath":"components/content/Tag.jsx"},{"name":"TagStructure","sourcePath":"components/content/TagStructure.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Toggle","sourcePath":"components/forms/Toggle.jsx"},{"name":"IconAimee","sourcePath":"components/glyphs/IconAimee.jsx"},{"name":"IconAlarm","sourcePath":"components/glyphs/IconAlarm.jsx"},{"name":"IconArrowDown","sourcePath":"components/glyphs/IconArrowDown.jsx"},{"name":"IconArrowLeft","sourcePath":"components/glyphs/IconArrowLeft.jsx"},{"name":"IconArrowRight","sourcePath":"components/glyphs/IconArrowRight.jsx"},{"name":"IconArrowUp","sourcePath":"components/glyphs/IconArrowUp.jsx"},{"name":"IconArticles","sourcePath":"components/glyphs/IconArticles.jsx"},{"name":"IconBiteSize","sourcePath":"components/glyphs/IconBiteSize.jsx"},{"name":"IconBook","sourcePath":"components/glyphs/IconBook.jsx"},{"name":"IconBookmark","sourcePath":"components/glyphs/IconBookmark.jsx"},{"name":"IconBulb","sourcePath":"components/glyphs/IconBulb.jsx"},{"name":"IconCalculator","sourcePath":"components/glyphs/IconCalculator.jsx"},{"name":"IconCalendar","sourcePath":"components/glyphs/IconCalendar.jsx"},{"name":"IconCalendarCheck","sourcePath":"components/glyphs/IconCalendarCheck.jsx"},{"name":"IconCall","sourcePath":"components/glyphs/IconCall.jsx"},{"name":"IconChatBubble","sourcePath":"components/glyphs/IconChatBubble.jsx"},{"name":"IconCheck","sourcePath":"components/glyphs/IconCheck.jsx"},{"name":"IconChevronDown","sourcePath":"components/glyphs/IconChevronDown.jsx"},{"name":"IconChevronLeft","sourcePath":"components/glyphs/IconChevronLeft.jsx"},{"name":"IconChevronRight","sourcePath":"components/glyphs/IconChevronRight.jsx"},{"name":"IconChevronUp","sourcePath":"components/glyphs/IconChevronUp.jsx"},{"name":"IconChipPlaceholder","sourcePath":"components/glyphs/IconChipPlaceholder.jsx"},{"name":"IconClipboard","sourcePath":"components/glyphs/IconClipboard.jsx"},{"name":"IconClose","sourcePath":"components/glyphs/IconClose.jsx"},{"name":"IconCopy","sourcePath":"components/glyphs/IconCopy.jsx"},{"name":"IconEdit","sourcePath":"components/glyphs/IconEdit.jsx"},{"name":"IconExpand","sourcePath":"components/glyphs/IconExpand.jsx"},{"name":"IconFilter","sourcePath":"components/glyphs/IconFilter.jsx"},{"name":"IconHelp","sourcePath":"components/glyphs/IconHelp.jsx"},{"name":"IconHome","sourcePath":"components/glyphs/IconHome.jsx"},{"name":"IconInfo","sourcePath":"components/glyphs/IconInfo.jsx"},{"name":"IconInfographic","sourcePath":"components/glyphs/IconInfographic.jsx"},{"name":"IconLifeEvents","sourcePath":"components/glyphs/IconLifeEvents.jsx"},{"name":"IconLogOut","sourcePath":"components/glyphs/IconLogOut.jsx"},{"name":"IconMenu","sourcePath":"components/glyphs/IconMenu.jsx"},{"name":"IconMenuDots","sourcePath":"components/glyphs/IconMenuDots.jsx"},{"name":"IconMenuOpen","sourcePath":"components/glyphs/IconMenuOpen.jsx"},{"name":"IconNotification","sourcePath":"components/glyphs/IconNotification.jsx"},{"name":"IconPlus","sourcePath":"components/glyphs/IconPlus.jsx"},{"name":"IconReset","sourcePath":"components/glyphs/IconReset.jsx"},{"name":"IconSearch","sourcePath":"components/glyphs/IconSearch.jsx"},{"name":"IconShare","sourcePath":"components/glyphs/IconShare.jsx"},{"name":"IconShow","sourcePath":"components/glyphs/IconShow.jsx"},{"name":"IconStars","sourcePath":"components/glyphs/IconStars.jsx"},{"name":"IconUser","sourcePath":"components/glyphs/IconUser.jsx"},{"name":"IconVideos","sourcePath":"components/glyphs/IconVideos.jsx"},{"name":"IconWorld","sourcePath":"components/glyphs/IconWorld.jsx"},{"name":"ActionItem","sourcePath":"components/hub/ActionItem.jsx"},{"name":"Aimee","sourcePath":"components/hub/Aimee.jsx"},{"name":"AimeeWidget","sourcePath":"components/hub/AimeeWidget.jsx"},{"name":"AimeeLauncher","sourcePath":"components/hub/AimeeWidget.jsx"},{"name":"BadgeCard","sourcePath":"components/hub/BadgeCard.jsx"},{"name":"Beak","sourcePath":"components/hub/Beak.jsx"},{"name":"BeakWrapper","sourcePath":"components/hub/BeakWrapper.jsx"},{"name":"Benefit","sourcePath":"components/hub/Benefit.jsx"},{"name":"ChatQuickReply","sourcePath":"components/hub/ChatQuickReply.jsx"},{"name":"EventsCards","sourcePath":"components/hub/EventsCards.jsx"},{"name":"HomeSummaryCard","sourcePath":"components/hub/HomeSummaryCard.jsx"},{"name":"LifeEventCard","sourcePath":"components/hub/LifeEventCard.jsx"},{"name":"MilestoneBadge","sourcePath":"components/hub/MilestoneBadge.jsx"},{"name":"MyFinancialWellnessScore","sourcePath":"components/hub/MyFinancialWellnessScore.jsx"},{"name":"Notif","sourcePath":"components/hub/Notif.jsx"},{"name":"NotifList","sourcePath":"components/hub/NotifList.jsx"},{"name":"ProgressLevel","sourcePath":"components/hub/ProgressLevel.jsx"},{"name":"SmallMilestoneBadge","sourcePath":"components/hub/SmallMilestoneBadge.jsx"},{"name":"SmallMilsetoneBadge","sourcePath":"components/hub/SmallMilsetoneBadge.jsx"},{"name":"StatusDropdown","sourcePath":"components/hub/StatusDropdown.jsx"},{"name":"StatusIndicator","sourcePath":"components/hub/StatusIndicator.jsx"},{"name":"StatusPill","sourcePath":"components/hub/StatusPill.jsx"},{"name":"Tooltip","sourcePath":"components/hub/Tooltip.jsx"},{"name":"Image11LandscapeNone","sourcePath":"components/media/Image11LandscapeNone.jsx"},{"name":"Image21LandscapeNone","sourcePath":"components/media/Image21LandscapeNone.jsx"},{"name":"Component2","sourcePath":"components/misc/Component2.jsx"},{"name":"Frame1000004665","sourcePath":"components/misc/Frame1000004665.jsx"},{"name":"Frame1000004752","sourcePath":"components/misc/Frame1000004752.jsx"},{"name":"Frame2087327407","sourcePath":"components/misc/Frame2087327407.jsx"},{"name":"Frame36070","sourcePath":"components/misc/Frame36070.jsx"},{"name":"Group6829","sourcePath":"components/misc/Group6829.jsx"},{"name":"Group6832","sourcePath":"components/misc/Group6832.jsx"},{"name":"XYAsis","sourcePath":"components/misc/XYAsis.jsx"},{"name":"BottomNav","sourcePath":"components/navigation/BottomNav.jsx"},{"name":"Nav","sourcePath":"components/navigation/Nav.jsx"},{"name":"Tab","sourcePath":"components/navigation/Tab.jsx"},{"name":"TopNav","sourcePath":"components/navigation/TopNav.jsx"}],"sourceHashes":{"assets/icons/Icon.jsx":"b81dfc2559d3","assets/icons/icon-data.js":"41e46a6cbd60","components/brand/AimeeLogo.jsx":"261e52f5cd1e","components/brand/Logo.jsx":"c580b5dabd2b","components/buttons/AccentButton.jsx":"5f7d0bb21a27","components/buttons/Button.jsx":"8a9f9cedb882","components/buttons/NavButton.jsx":"dd223db719ae","components/buttons/PrimaryButton.jsx":"3a66e32c0e8b","components/buttons/SecondaryButton.jsx":"b08766afe752","components/buttons/TertiaryButton.jsx":"74b0813b54f1","components/content/Accordion.jsx":"b8c9be4a64e0","components/content/Avatar.jsx":"50887862bc44","components/content/Chip.jsx":"5271c3d6356a","components/content/ChipStructure.jsx":"1b389484dab6","components/content/ContentChips.jsx":"3b5d6462c6d3","components/content/ContentTags.jsx":"f72716c0518c","components/content/ContentThumbnailCard.jsx":"291c7c7a49bf","components/content/ImagePlaceholder.jsx":"403f21af50a7","components/content/Tag.jsx":"c8bcb4647b1e","components/content/TagStructure.jsx":"c49b8b7ca826","components/forms/Checkbox.jsx":"5d9ec5c71fd7","components/forms/Input.jsx":"4fa0a7ec946f","components/forms/Toggle.jsx":"75c897e47127","components/glyphs/IconAimee.jsx":"ed31fc7b3985","components/glyphs/IconAlarm.jsx":"afe40d9c3180","components/glyphs/IconArrowDown.jsx":"6c247935a6c9","components/glyphs/IconArrowLeft.jsx":"17db563be29b","components/glyphs/IconArrowRight.jsx":"62e6694e1fa2","components/glyphs/IconArrowUp.jsx":"7073de5ee5b3","components/glyphs/IconArticles.jsx":"82027c72397d","components/glyphs/IconBiteSize.jsx":"13991543282c","components/glyphs/IconBook.jsx":"17778a36f37d","components/glyphs/IconBookmark.jsx":"065bca9a0561","components/glyphs/IconBulb.jsx":"06b4a07cfc20","components/glyphs/IconCalculator.jsx":"c555625a86a1","components/glyphs/IconCalendar.jsx":"9af87c54d0b2","components/glyphs/IconCalendarCheck.jsx":"6efade504c1d","components/glyphs/IconCall.jsx":"27698ce853c6","components/glyphs/IconChatBubble.jsx":"1dc2c996286f","components/glyphs/IconCheck.jsx":"c07472132862","components/glyphs/IconChevronDown.jsx":"0e72a4322915","components/glyphs/IconChevronLeft.jsx":"ab10e3cd32bc","components/glyphs/IconChevronRight.jsx":"05b544810f8d","components/glyphs/IconChevronUp.jsx":"ab305d9d0090","components/glyphs/IconChipPlaceholder.jsx":"77ce4e389544","components/glyphs/IconClipboard.jsx":"d5bb3fe3e571","components/glyphs/IconClose.jsx":"cb30d359d494","components/glyphs/IconCopy.jsx":"b17eaafcb4ec","components/glyphs/IconEdit.jsx":"f94806c3e4ef","components/glyphs/IconExpand.jsx":"7424f3b1f1e0","components/glyphs/IconFilter.jsx":"7374d008b1b9","components/glyphs/IconHelp.jsx":"d150f1be175d","components/glyphs/IconHome.jsx":"be7a8f1098a5","components/glyphs/IconInfo.jsx":"372c2ca7bfef","components/glyphs/IconInfographic.jsx":"620b781eb578","components/glyphs/IconLifeEvents.jsx":"78affc199008","components/glyphs/IconLogOut.jsx":"89ac0bdf0cf1","components/glyphs/IconMenu.jsx":"e40e41e8ee55","components/glyphs/IconMenuDots.jsx":"eea4021f5b07","components/glyphs/IconMenuOpen.jsx":"31fedc8fb6be","components/glyphs/IconNotification.jsx":"ab504303d632","components/glyphs/IconPlus.jsx":"4f25ecc0ae89","components/glyphs/IconReset.jsx":"201a845433d3","components/glyphs/IconSearch.jsx":"e7e53926eac5","components/glyphs/IconShare.jsx":"d011bf5640cb","components/glyphs/IconShow.jsx":"b5f5317afc97","components/glyphs/IconStars.jsx":"48740e300b88","components/glyphs/IconUser.jsx":"5db49fff8465","components/glyphs/IconVideos.jsx":"66820023a949","components/glyphs/IconWorld.jsx":"6357717a22e0","components/hub/ActionItem.jsx":"c7ddd8825c21","components/hub/Aimee.jsx":"e291bc5787a7","components/hub/AimeeWidget.jsx":"0a006ce52627","components/hub/BadgeCard.jsx":"0e8c1e7dc86b","components/hub/Beak.jsx":"5c68db66ffc1","components/hub/BeakWrapper.jsx":"b43b82abf629","components/hub/Benefit.jsx":"7c746368cf45","components/hub/ChatQuickReply.jsx":"876e224ad978","components/hub/EventsCards.jsx":"14eae9d904b3","components/hub/HomeSummaryCard.jsx":"e6942712ca41","components/hub/LifeEventCard.jsx":"1ff4bf612fb5","components/hub/MilestoneBadge.jsx":"9890463cbf81","components/hub/MyFinancialWellnessScore.jsx":"0148bd0056b2","components/hub/Notif.jsx":"4a951e2f7cd1","components/hub/NotifList.jsx":"747b9ad42923","components/hub/ProgressLevel.jsx":"f6caf4c015e1","components/hub/SmallMilestoneBadge.jsx":"83816152d6f9","components/hub/SmallMilsetoneBadge.jsx":"153d20a4cb3d","components/hub/StatusDropdown.jsx":"1d667807d9b6","components/hub/StatusIndicator.jsx":"b10aea4bc36b","components/hub/StatusPill.jsx":"d7ae3b516b55","components/hub/Tooltip.jsx":"2a04b2f06ebd","components/media/Image11LandscapeNone.jsx":"66f479672a32","components/media/Image21LandscapeNone.jsx":"ceb96de763de","components/misc/Component2.jsx":"26a5d9784e6e","components/misc/Frame1000004665.jsx":"f6682ba8339d","components/misc/Frame1000004752.jsx":"eab545053d7b","components/misc/Frame2087327407.jsx":"65de93b6f05b","components/misc/Frame36070.jsx":"b66c22ef18b0","components/misc/Group6829.jsx":"842815d66a42","components/misc/Group6832.jsx":"0b65f3de0f73","components/misc/XYAsis.jsx":"809eaa1d4dc5","components/navigation/BottomNav.jsx":"2c7c614ea450","components/navigation/Nav.jsx":"315281f6137c","components/navigation/Tab.jsx":"c09de10f6786","components/navigation/TopNav.jsx":"a0c3fb839f23","ui_kits/hub/HubAimee.jsx":"935c1732a0d4","ui_kits/hub/HubContent.jsx":"4ca537be2dfd","ui_kits/hub/HubHome.jsx":"7cd8f40ca702"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.FinancialFinesseDesignSystem_019e0d = window.FinancialFinesseDesignSystem_019e0d || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// assets/icons/icon-data.js
try { (() => {
// Generated by fig_materialize (moduleFormat: 'icon-data') — 62 icon(s)
// as { viewBox, body } SVG-markup entries. Render via the sibling Icon.jsx
// (<Icon name="IconAimeeProperty115rem" />), or consume the path data directly.
let __ds_default_assets_icons_icon_data_imae2q;
try {
  __ds_default_assets_icons_icon_data_imae2q = {
    "IconAimeeProperty115rem": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 0 0 L 20 0 L 20 20 L 0 20 L 0 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2)\"/>"
    },
    "IconAimeeProperty11rem": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 0 0 L 13.333 0 L 13.333 13.333 L 0 13.333 L 0 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1.333 1.333)\"/>"
    },
    "IconAlarm": {
      viewBox: "0 0 13 13",
      body: "<path d=\"M 5.5 10 C 4.854 10 4.25 9.879 3.686 9.637 C 3.122 9.396 2.632 9.069 2.214 8.658 C 1.797 8.246 1.465 7.763 1.22 7.207 C 0.975 6.652 0.852 6.056 0.852 5.42 C 0.852 4.784 0.975 4.188 1.22 3.632 C 1.465 3.077 1.797 2.593 2.214 2.182 C 2.632 1.771 3.122 1.444 3.686 1.202 C 4.25 0.961 4.854 0.84 5.5 0.84 C 6.146 0.84 6.75 0.961 7.314 1.202 C 7.878 1.444 8.368 1.771 8.786 2.182 C 9.203 2.593 9.535 3.077 9.78 3.632 C 10.025 4.188 10.148 4.784 10.148 5.42 C 10.148 6.056 10.025 6.652 9.78 7.207 C 9.535 7.763 9.203 8.246 8.786 8.658 C 8.368 9.069 7.878 9.396 7.314 9.637 C 6.75 9.879 6.146 10 5.5 10 Z M 6.946 7.557 L 7.669 6.845 L 6.016 5.216 L 6.016 2.875 L 4.984 2.875 L 4.984 5.623 L 6.946 7.557 Z M 2.195 0 L 2.918 0.712 L 0.723 2.875 L 0 2.163 L 2.195 0 Z M 8.805 0 L 11 2.163 L 10.277 2.875 L 8.082 0.712 L 8.805 0 Z M 5.5 8.982 C 6.507 8.982 7.361 8.637 8.063 7.945 C 8.764 7.254 9.115 6.412 9.115 5.42 C 9.115 4.427 8.764 3.586 8.063 2.894 C 7.361 2.203 6.507 1.858 5.5 1.858 C 4.493 1.858 3.639 2.203 2.937 2.894 C 2.236 3.586 1.885 4.427 1.885 5.42 C 1.885 6.412 2.236 7.254 2.937 7.945 C 3.639 8.637 4.493 8.982 5.5 8.982 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1 1.595)\"/>"
    },
    "IconArrowDownSize15rem": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 7.5 13.333 L 7.5 3.192 L 12.158 7.85 L 13.333 6.667 L 6.667 0 L 0 6.667 L 1.175 7.842 L 5.833 3.192 L 5.833 13.333 L 7.5 13.333 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2) matrix(-1 0 0 -1 16.667 16.665)\"/>"
    },
    "IconArrowDownSize1rem": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 5.718 3.448 L 6.111 3.841 L 6.897 3.056 L 6.504 2.663 L 6.111 3.056 L 5.718 3.448 Z M 3.056 0 L 3.448 -0.393 L 3.056 -0.786 L 2.663 -0.393 L 3.056 0 Z M -0.393 2.663 L -0.786 3.056 L 0 3.841 L 0.393 3.448 L 0 3.056 L -0.393 2.663 Z M 3.611 0.694 L 3.611 0.139 L 2.5 0.139 L 2.5 0.694 L 3.056 0.694 L 3.611 0.694 Z M 2.5 7.917 L 2.5 8.472 L 3.611 8.472 L 3.611 7.917 L 3.056 7.917 L 2.5 7.917 Z M 6.111 3.056 L 6.504 2.663 L 3.448 -0.393 L 3.056 0 L 2.663 0.393 L 5.718 3.448 L 6.111 3.056 Z M 3.056 0 L 2.663 -0.393 L -0.393 2.663 L 0 3.056 L 0.393 3.448 L 3.448 0.393 L 3.056 0 Z M 3.056 0.694 L 2.5 0.694 L 2.5 7.917 L 3.056 7.917 L 3.611 7.917 L 3.611 0.694 L 3.056 0.694 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1.333 1.333) matrix(-1 0 0 -1 9.722 10.694)\"/>"
    },
    "IconArrowLeft": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 7.5 13.333 L 7.5 3.192 L 12.158 7.85 L 13.333 6.667 L 6.667 0 L 0 6.667 L 1.175 7.842 L 5.833 3.192 L 5.833 13.333 L 7.5 13.333 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2) matrix(0 -1 1 0 3.333 16.667)\"/>"
    },
    "IconArrowRightSize15rem": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 7.5 13.333 L 7.5 3.192 L 12.158 7.85 L 13.333 6.667 L 6.667 0 L 0 6.667 L 1.175 7.842 L 5.833 3.192 L 5.833 13.333 L 7.5 13.333 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2) matrix(0 1 -1 0 16.667 3.333)\"/>"
    },
    "IconArrowRightSize1rem": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 5.718 3.448 L 6.111 3.841 L 6.897 3.056 L 6.504 2.663 L 6.111 3.056 L 5.718 3.448 Z M 3.056 0 L 3.448 -0.393 L 3.056 -0.786 L 2.663 -0.393 L 3.056 0 Z M -0.393 2.663 L -0.786 3.056 L 0 3.841 L 0.393 3.448 L 0 3.056 L -0.393 2.663 Z M 3.611 0.694 L 3.611 0.139 L 2.5 0.139 L 2.5 0.694 L 3.056 0.694 L 3.611 0.694 Z M 2.5 7.917 L 2.5 8.472 L 3.611 8.472 L 3.611 7.917 L 3.056 7.917 L 2.5 7.917 Z M 6.111 3.056 L 6.504 2.663 L 3.448 -0.393 L 3.056 0 L 2.663 0.393 L 5.718 3.448 L 6.111 3.056 Z M 3.056 0 L 2.663 -0.393 L -0.393 2.663 L 0 3.056 L 0.393 3.448 L 3.448 0.393 L 3.056 0 Z M 3.056 0.694 L 2.5 0.694 L 2.5 7.917 L 3.056 7.917 L 3.611 7.917 L 3.611 0.694 L 3.056 0.694 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1.333 1.333) matrix(0 1 -1 0 10.625 3.680)\"/>"
    },
    "IconArrowUp": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 5.208 13.542 L 5.208 3.958 L 1.458 7.708 L 0 6.25 L 6.25 0 L 12.5 6.25 L 11.042 7.708 L 7.292 3.958 L 7.292 13.542 L 5.208 13.542 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 5.434 5.006)\"/>"
    },
    "IconArticles": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 0 7.7 L 0 2.1 L 5.6 2.1 L 5.6 7.7 L 0 7.7 Z M 1.05 6.65 L 4.55 6.65 L 4.55 3.15 L 1.05 3.15 L 1.05 6.65 Z M 0 1.05 L 0 0 L 9.8 0 L 9.8 1.05 L 0 1.05 Z M 6.65 3.15 L 6.65 2.1 L 9.8 2.1 L 9.8 3.15 L 6.65 3.15 Z M 6.65 5.425 L 6.65 4.375 L 9.8 4.375 L 9.8 5.425 L 6.65 5.425 Z M 6.65 7.7 L 6.65 6.65 L 9.8 6.65 L 9.8 7.7 L 6.65 7.7 Z M 0 9.8 L 0 8.75 L 9.8 8.75 L 9.8 9.8 L 0 9.8 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3.100 3.100)\"/>"
    },
    "IconBiteSize": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 1.083 8.667 L 1.083 1.083 L 1.083 3.507 L 1.083 3.25 L 1.083 8.667 Z M 2.167 5.417 L 5.159 5.417 C 5.177 5.218 5.223 5.028 5.295 4.848 C 5.367 4.667 5.457 4.496 5.566 4.333 L 2.167 4.333 L 2.167 5.417 Z M 2.167 7.583 L 4.293 7.583 C 4.446 7.403 4.622 7.256 4.821 7.143 C 5.019 7.03 5.227 6.938 5.444 6.866 C 5.408 6.811 5.376 6.753 5.349 6.69 C 5.322 6.626 5.299 6.563 5.281 6.5 L 2.167 6.5 L 2.167 7.583 Z M 2.167 3.25 L 7.583 3.25 L 7.583 2.167 L 2.167 2.167 L 2.167 3.25 Z M 1.083 9.75 C 0.785 9.75 0.53 9.644 0.318 9.432 C 0.106 9.22 0 8.965 0 8.667 L 0 1.083 C 0 0.785 0.106 0.53 0.318 0.318 C 0.53 0.106 0.785 0 1.083 0 L 8.667 0 C 8.965 0 9.22 0.106 9.432 0.318 C 9.644 0.53 9.75 0.785 9.75 1.083 L 9.75 4.577 C 9.624 4.342 9.47 4.135 9.29 3.954 C 9.109 3.774 8.901 3.625 8.667 3.507 L 8.667 1.083 L 1.083 1.083 L 1.083 8.667 L 3.819 8.667 C 3.81 8.721 3.803 8.775 3.798 8.829 C 3.794 8.883 3.792 8.938 3.792 8.992 L 3.792 9.75 L 1.083 9.75 Z M 7.583 7.042 C 7.204 7.042 6.884 6.911 6.622 6.649 C 6.36 6.387 6.229 6.067 6.229 5.688 C 6.229 5.308 6.36 4.988 6.622 4.726 C 6.884 4.464 7.204 4.333 7.583 4.333 C 7.963 4.333 8.283 4.464 8.545 4.726 C 8.807 4.988 8.938 5.308 8.938 5.688 C 8.938 6.067 8.807 6.387 8.545 6.649 C 8.283 6.911 7.963 7.042 7.583 7.042 Z M 4.875 9.75 L 4.875 8.992 C 4.875 8.775 4.931 8.574 5.044 8.389 C 5.157 8.204 5.317 8.071 5.525 7.99 C 5.85 7.854 6.186 7.753 6.534 7.685 C 6.881 7.617 7.231 7.583 7.583 7.583 C 7.935 7.583 8.285 7.617 8.633 7.685 C 8.98 7.753 9.317 7.854 9.642 7.99 C 9.849 8.071 10.01 8.204 10.122 8.389 C 10.235 8.574 10.292 8.775 10.292 8.992 L 10.292 9.75 L 4.875 9.75 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2.854 3.125)\"/>"
    },
    "IconBookProperty1DefaultSize1rem": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 8.4 3.599 L 3 3.599 L 3 2.399 L 8.4 2.399 L 8.4 3.599 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2.600 2)\"/><path d=\"M 9.601 0 C 10.262 0 10.8 0.538 10.8 1.2 L 10.8 9.601 L 1.807 9.601 C 1.53 9.608 1.2 9.717 1.2 10.2 C 1.2 10.683 1.53 10.793 1.807 10.8 L 10.8 10.8 L 10.8 12 L 1.8 12 C 1.076 12 0 11.521 0 10.2 L 0 1.8 C 0 0.479 1.076 0 1.8 0 L 9.601 0 Z M 1.8 1.2 C 1.53 1.207 1.2 1.317 1.2 1.8 L 1.2 8.4 L 9.601 8.4 L 9.601 1.2 L 1.8 1.2 Z\" fill=\"currentColor\" fill-rule=\"evenodd\" transform=\"matrix(1 0 0 1 2.600 2)\"/>"
    },
    "IconBookProperty1SelectedSize1rem": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 9.601 0 C 10.262 0 10.801 0.539 10.801 1.2 L 10.801 9.601 L 1.808 9.601 C 1.531 9.608 1.2 9.718 1.2 10.2 C 1.2 10.683 1.53 10.793 1.808 10.8 L 10.801 10.8 L 10.801 12 L 1.8 12 C 1.076 12 0 11.52 0 10.2 L 0 1.8 C 0 0.48 1.076 0 1.8 0 L 9.601 0 Z M 3 2.4 L 3 3.601 L 8.4 3.601 L 8.4 2.4 L 3 2.4 Z\" fill=\"currentColor\" fill-rule=\"evenodd\" transform=\"matrix(1 0 0 1 2.600 2)\"/>"
    },
    "IconBookmarkDefault": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 0 16.5 L 0 1.833 C 0 1.329 0.18 0.898 0.539 0.539 C 0.898 0.18 1.329 0 1.833 0 L 11 0 C 11.504 0 11.936 0.18 12.295 0.539 C 12.654 0.898 12.833 1.329 12.833 1.833 L 12.833 16.5 L 6.417 13.75 L 0 16.5 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 5.583 3.750)\"/><path d=\"M 0 16.5 L -1 16.5 L -1 18.017 L 0.394 17.419 L 0 16.5 Z M 12.833 16.5 L 12.439 17.419 L 13.833 18.017 L 13.833 16.5 L 12.833 16.5 Z M 6.417 13.75 L 6.811 12.831 L 6.417 12.662 L 6.023 12.831 L 6.417 13.75 Z M 0 16.5 L 1 16.5 L 1 1.833 L 0 1.833 L -1 1.833 L -1 16.5 L 0 16.5 Z M 0 1.833 L 1 1.833 C 1 1.596 1.073 1.419 1.246 1.246 L 0.539 0.539 L -0.169 -0.169 C -0.714 0.377 -1 1.062 -1 1.833 L 0 1.833 Z M 0.539 0.539 L 1.246 1.246 C 1.419 1.073 1.596 1 1.833 1 L 1.833 0 L 1.833 -1 C 1.062 -1 0.377 -0.714 -0.169 -0.169 L 0.539 0.539 Z M 1.833 0 L 1.833 1 L 11 1 L 11 0 L 11 -1 L 1.833 -1 L 1.833 0 Z M 11 0 L 11 1 C 11.237 1 11.415 1.073 11.588 1.246 L 12.295 0.539 L 13.002 -0.169 C 12.457 -0.714 11.771 -1 11 -1 L 11 0 Z M 12.295 0.539 L 11.588 1.246 C 11.761 1.419 11.833 1.596 11.833 1.833 L 12.833 1.833 L 13.833 1.833 C 13.833 1.062 13.547 0.377 13.002 -0.169 L 12.295 0.539 Z M 12.833 1.833 L 11.833 1.833 L 11.833 16.5 L 12.833 16.5 L 13.833 16.5 L 13.833 1.833 L 12.833 1.833 Z M 12.833 16.5 L 13.227 15.581 L 6.811 12.831 L 6.417 13.75 L 6.023 14.669 L 12.439 17.419 L 12.833 16.5 Z M 6.417 13.75 L 6.023 12.831 L -0.394 15.581 L 0 16.5 L 0.394 17.419 L 6.811 14.669 L 6.417 13.75 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 5.583 3.750)\"/>"
    },
    "IconBulb": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 4.063 10.833 C 3.765 10.833 3.51 10.727 3.297 10.515 C 3.085 10.303 2.979 10.048 2.979 9.75 L 5.146 9.75 C 5.146 10.048 5.04 10.303 4.828 10.515 C 4.615 10.727 4.36 10.833 4.063 10.833 Z M 1.896 9.208 L 1.896 8.125 L 6.229 8.125 L 6.229 9.208 L 1.896 9.208 Z M 2.031 7.583 C 1.408 7.213 0.914 6.717 0.548 6.094 C 0.183 5.471 0 4.794 0 4.063 C 0 2.934 0.395 1.975 1.185 1.185 C 1.975 0.395 2.934 0 4.063 0 C 5.191 0 6.15 0.395 6.94 1.185 C 7.73 1.975 8.125 2.934 8.125 4.063 C 8.125 4.794 7.942 5.471 7.577 6.094 C 7.211 6.717 6.717 7.213 6.094 7.583 L 2.031 7.583 Z M 2.356 6.5 L 5.769 6.5 C 6.175 6.211 6.489 5.855 6.71 5.43 C 6.931 5.006 7.042 4.55 7.042 4.063 C 7.042 3.232 6.753 2.528 6.175 1.95 C 5.597 1.372 4.893 1.083 4.063 1.083 C 3.232 1.083 2.528 1.372 1.95 1.95 C 1.372 2.528 1.083 3.232 1.083 4.063 C 1.083 4.55 1.194 5.006 1.415 5.43 C 1.636 5.855 1.95 6.211 2.356 6.5 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3.938 2.583)\"/>"
    },
    "IconCalculator": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 2.708 8.125 L 3.521 8.125 L 3.521 7.042 L 4.604 7.042 L 4.604 6.229 L 3.521 6.229 L 3.521 5.146 L 2.708 5.146 L 2.708 6.229 L 1.625 6.229 L 1.625 7.042 L 2.708 7.042 L 2.708 8.125 Z M 5.417 7.719 L 8.125 7.719 L 8.125 6.906 L 5.417 6.906 L 5.417 7.719 Z M 5.417 6.365 L 8.125 6.365 L 8.125 5.552 L 5.417 5.552 L 5.417 6.365 Z M 6.013 4.306 L 6.771 3.548 L 7.529 4.306 L 8.098 3.738 L 7.34 2.952 L 8.098 2.194 L 7.529 1.625 L 6.771 2.383 L 6.013 1.625 L 5.444 2.194 L 6.202 2.952 L 5.444 3.738 L 6.013 4.306 Z M 1.76 3.358 L 4.469 3.358 L 4.469 2.546 L 1.76 2.546 L 1.76 3.358 Z M 1.083 9.75 C 0.785 9.75 0.53 9.644 0.318 9.432 C 0.106 9.22 0 8.965 0 8.667 L 0 1.083 C 0 0.785 0.106 0.53 0.318 0.318 C 0.53 0.106 0.785 0 1.083 0 L 8.667 0 C 8.965 0 9.22 0.106 9.432 0.318 C 9.644 0.53 9.75 0.785 9.75 1.083 L 9.75 8.667 C 9.75 8.965 9.644 9.22 9.432 9.432 C 9.22 9.644 8.965 9.75 8.667 9.75 L 1.083 9.75 Z M 1.083 8.667 L 8.667 8.667 L 8.667 1.083 L 1.083 1.083 L 1.083 8.667 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3.125 3.125)\"/>"
    },
    "IconCalendarCheck": {
      viewBox: "0 0 13 13",
      body: "<path d=\"M 1.083 10.833 C 0.785 10.833 0.53 10.727 0.318 10.515 C 0.106 10.303 0 10.048 0 9.75 L 0 2.167 C 0 1.869 0.106 1.614 0.318 1.402 C 0.53 1.189 0.785 1.083 1.083 1.083 L 1.625 1.083 L 1.625 0 L 2.708 0 L 2.708 1.083 L 7.042 1.083 L 7.042 0 L 8.125 0 L 8.125 1.083 L 8.667 1.083 C 8.965 1.083 9.22 1.189 9.432 1.402 C 9.644 1.614 9.75 1.869 9.75 2.167 L 9.75 5.62 L 8.667 6.703 L 8.667 4.333 L 1.083 4.333 L 1.083 9.75 L 4.442 9.75 L 5.525 10.833 L 1.083 10.833 Z M 1.083 3.25 L 8.667 3.25 L 8.667 2.167 L 1.083 2.167 L 1.083 3.25 Z M 7.34 11.104 L 5.417 9.181 L 6.175 8.423 L 7.326 9.574 L 9.628 7.272 L 10.386 8.044 L 7.34 11.104 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1.625 1.083)\"/>"
    },
    "IconCalendarProperty1DefaultSize1rem": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 3.333 1.333 L 8.667 1.333 L 8.667 0 L 10 0 L 10 1.333 L 10.667 1.333 C 11.02 1.333 11.359 1.474 11.609 1.724 C 11.86 1.974 12 2.313 12 2.667 L 12 12 C 12 12.354 11.86 12.693 11.609 12.943 C 11.359 13.193 11.02 13.333 10.667 13.333 L 1.333 13.333 C 0.98 13.333 0.641 13.193 0.391 12.943 C 0.14 12.693 0 12.354 0 12 L 0 2.667 C 0 2.313 0.14 1.974 0.391 1.724 C 0.641 1.474 0.98 1.333 1.333 1.333 L 2 1.333 L 2 0 L 3.333 0 L 3.333 1.333 Z M 1.333 4 L 1.333 12 L 10.667 12 L 10.667 4 L 1.333 4 Z M 2.667 6 L 4 6 L 4 7.333 L 2.667 7.333 L 2.667 6 Z M 5.333 6 L 6.667 6 L 6.667 7.333 L 5.333 7.333 L 5.333 6 Z M 8 6 L 9.333 6 L 9.333 7.333 L 8 7.333 L 8 6 Z M 8 8.667 L 9.333 8.667 L 9.333 10 L 8 10 L 8 8.667 Z M 5.333 8.667 L 6.667 8.667 L 6.667 10 L 5.333 10 L 5.333 8.667 Z M 2.667 8.667 L 4 8.667 L 4 10 L 2.667 10 L 2.667 8.667 Z\" fill=\"currentColor\" fill-rule=\"evenodd\" transform=\"matrix(1 0 0 1 2 1.333)\"/>"
    },
    "IconCalendarProperty1SelectedSize1rem": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 3.333 1.333 L 8.667 1.333 L 8.667 0 L 10 0 L 10 1.333 L 10.667 1.333 C 11.02 1.333 11.359 1.474 11.609 1.724 C 11.859 1.974 12 2.313 12 2.667 L 12 12 C 12 12.354 11.859 12.692 11.609 12.942 C 11.359 13.192 11.02 13.333 10.667 13.333 L 1.333 13.333 C 0.98 13.333 0.641 13.192 0.391 12.942 C 0.141 12.692 0 12.354 0 12 L 0 2.667 C 0 2.313 0.141 1.974 0.391 1.724 C 0.641 1.474 0.98 1.333 1.333 1.333 L 2 1.333 L 2 0 L 3.333 0 L 3.333 1.333 Z M 2.667 8.666 L 2.667 9.999 L 4 9.999 L 4 8.666 L 2.667 8.666 Z M 5.333 8.666 L 5.333 9.999 L 6.667 9.999 L 6.667 8.666 L 5.333 8.666 Z M 8 8.666 L 8 9.999 L 9.333 9.999 L 9.333 8.666 L 8 8.666 Z M 2.667 5.999 L 2.667 7.332 L 4 7.332 L 4 5.999 L 2.667 5.999 Z M 5.333 5.999 L 5.333 7.332 L 6.667 7.332 L 6.667 5.999 L 5.333 5.999 Z M 8 5.999 L 8 7.332 L 9.333 7.332 L 9.333 5.999 L 8 5.999 Z M 1.643 3.08 L 1.643 4.413 L 10.643 4.413 L 10.643 3.08 L 1.643 3.08 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 1.334)\"/>"
    },
    "IconCall": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 14.125 15 C 12.389 15 10.674 14.622 8.979 13.865 C 7.285 13.108 5.743 12.035 4.354 10.646 C 2.965 9.256 1.892 7.715 1.136 6.021 C 0.379 4.327 0.001 2.612 0 0.875 C 0 0.625 0.083 0.417 0.25 0.25 C 0.417 0.083 0.625 0 0.875 0 L 4.25 0 C 4.444 0 4.618 0.066 4.771 0.198 C 4.924 0.331 5.014 0.487 5.042 0.667 L 5.583 3.583 C 5.611 3.806 5.604 3.993 5.563 4.146 C 5.521 4.299 5.444 4.431 5.333 4.542 L 3.312 6.583 C 3.59 7.097 3.92 7.594 4.302 8.073 C 4.683 8.551 5.104 9.013 5.563 9.458 C 5.993 9.889 6.444 10.288 6.917 10.657 C 7.389 11.025 7.889 11.362 8.417 11.667 L 10.375 9.708 C 10.5 9.583 10.663 9.49 10.865 9.427 C 11.067 9.365 11.264 9.348 11.458 9.375 L 14.333 9.958 C 14.528 10.014 14.687 10.115 14.812 10.261 C 14.937 10.407 15 10.57 15 10.75 L 15 14.125 C 15 14.375 14.917 14.583 14.75 14.75 C 14.583 14.917 14.375 15 14.125 15 Z M 2.521 5 L 3.896 3.625 L 3.542 1.667 L 1.688 1.667 C 1.757 2.236 1.854 2.799 1.979 3.354 C 2.104 3.91 2.285 4.458 2.521 5 Z M 9.979 12.458 C 10.521 12.694 11.073 12.882 11.636 13.021 C 12.199 13.16 12.764 13.25 13.333 13.292 L 13.333 11.458 L 11.375 11.062 L 9.979 12.458 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2) matrix(1 0 0 1 2.500 2.500)\"/>"
    },
    "IconChatBubble": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 3.136 11.667 L 15 11.667 L 15 1.667 L 1.667 1.667 L 1.667 12.821 L 3.136 11.667 Z M 3.712 13.333 L 0 16.25 L 0 0.833 C 0 0.612 0.088 0.4 0.244 0.244 C 0.4 0.088 0.612 0 0.833 0 L 15.833 0 C 16.054 0 16.266 0.088 16.423 0.244 C 16.579 0.4 16.667 0.612 16.667 0.833 L 16.667 12.5 C 16.667 12.721 16.579 12.933 16.423 13.089 C 16.266 13.246 16.054 13.333 15.833 13.333 L 3.712 13.333 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2) matrix(1 0 0 1 1.667 2.500)\"/>"
    },
    "IconCheck": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 3.325 7.015 L 0 3.69 L 0.831 2.858 L 3.325 5.352 L 8.677 0 L 9.508 0.831 L 3.325 7.015 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1 1) matrix(1 0 0 1 2.246 3.485)\"/>"
    },
    "IconChevronDownSize15rem": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 6.598 8 L 0 1.402 L 1.402 0 L 6.598 5.196 L 11.794 0 L 13.196 1.402 L 6.598 8 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 5.402 8)\"/>"
    },
    "IconChevronDownSize1rem": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 4.375 5.305 L 0 0.93 L 0.93 0 L 4.375 3.445 L 7.82 0 L 8.75 0.93 L 4.375 5.305 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3.625 5.348)\"/>"
    },
    "IconChevronLeftSize15rem": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 6.598 8 L 0 1.402 L 1.402 0 L 6.598 5.196 L 11.794 0 L 13.196 1.402 L 6.598 8 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2) matrix(0 -1 -1 0 14 16.598)\"/>"
    },
    "IconChevronLeftSize1rem": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 4 4.85 L 0 0.85 L 0.85 0 L 4 3.15 L 7.15 0 L 8 0.85 L 4 4.85 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(0 -1 -1 0 10.425 12)\"/>"
    },
    "IconChevronRightSize15rem": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 6.598 8 L 0 1.402 L 1.402 0 L 6.598 5.196 L 11.794 0 L 13.196 1.402 L 6.598 8 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2) matrix(0 1 1 0 6 3.402)\"/>"
    },
    "IconChevronRightSize1rem": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 4 4.85 L 0 0.85 L 0.85 0 L 4 3.15 L 7.15 0 L 8 0.85 L 4 4.85 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(0 1 1 0 5.575 4)\"/>"
    },
    "IconChevronUpSize15rem": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 6.598 8 L 0 1.402 L 1.402 0 L 6.598 5.196 L 11.794 0 L 13.196 1.402 L 6.598 8 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(-1 0 0 -1 18.598 16)\"/>"
    },
    "IconChevronUpSize1rem": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 4.375 5.305 L 0 0.93 L 0.93 0 L 4.375 3.445 L 7.82 0 L 8.75 0.93 L 4.375 5.305 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(-1 0 0 -1 12.375 10.652)\"/>"
    },
    "IconClipboardProperty1DefaultSize1rem": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 2.667 1.333 L 2.667 0 L 9.333 0 L 9.333 1.333 L 11.338 1.333 C 11.703 1.333 12 1.63 12 1.995 L 12 12.671 C 12 12.847 11.93 13.015 11.806 13.139 C 11.682 13.263 11.514 13.333 11.338 13.333 L 0.662 13.333 C 0.486 13.333 0.318 13.264 0.194 13.139 C 0.07 13.015 0 12.847 0 12.671 L 0 1.995 C 0 1.63 0.297 1.333 0.662 1.333 L 2.667 1.333 Z M 2.667 2.667 L 1.333 2.667 L 1.333 12 L 10.667 12 L 10.667 2.667 L 9.333 2.667 L 9.333 4 L 2.667 4 L 2.667 2.667 Z M 4 1.333 L 4 2.667 L 8 2.667 L 8 1.333 L 4 1.333 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 1.333)\"/>"
    },
    "IconClipboardProperty1SelectedSize1rem": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 2 1.333 L 2 4 L 10 4 L 10 1.333 L 11.338 1.333 C 11.703 1.333 12 1.63 12 1.995 L 12 12.671 C 12 12.847 11.93 13.015 11.806 13.139 C 11.682 13.263 11.514 13.333 11.338 13.333 L 0.662 13.333 C 0.486 13.333 0.318 13.264 0.194 13.139 C 0.07 13.015 0 12.847 0 12.671 L 0 1.995 C 0 1.63 0.297 1.333 0.662 1.333 L 2 1.333 Z M 3.333 0 L 8.667 0 L 8.667 2.667 L 3.333 2.667 L 3.333 0 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 1.333)\"/>"
    },
    "IconCloseSize15rem": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 1.167 11.667 L 0 10.5 L 4.667 5.833 L 0 1.167 L 1.167 0 L 5.833 4.667 L 10.5 0 L 11.667 1.167 L 7 5.833 L 11.667 10.5 L 10.5 11.667 L 5.833 7 L 1.167 11.667 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2) matrix(1 0 0 1 4.167 4.167)\"/>"
    },
    "IconCloseSize1rem": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 0.774 9.423 L 0 8.649 L 3.938 4.711 L 0 0.774 L 0.774 0 L 4.711 3.938 L 8.649 0 L 9.423 0.774 L 5.485 4.711 L 9.423 8.649 L 8.649 9.423 L 4.711 5.485 L 0.774 9.423 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3.083 3.743)\"/>"
    },
    "IconCopy": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 3.333 13.333 L 3.333 0 L 14.167 0 L 14.167 13.333 L 3.333 13.333 Z M 5 11.667 L 12.5 11.667 L 12.5 1.667 L 5 1.667 L 5 11.667 Z M 0 16.667 L 0 3.333 L 1.667 3.333 L 1.667 15 L 10.833 15 L 10.833 16.667 L 0 16.667 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2) matrix(1 0 0 1 2.500 1.667)\"/>"
    },
    "IconEdit": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 2.845 11.642 L 11.297 3.191 L 10.118 2.012 L 1.667 10.464 L 1.667 11.642 L 2.845 11.642 Z M 3.536 13.309 L 0 13.309 L 0 9.773 L 9.529 0.244 C 9.685 0.088 9.897 0 10.118 0 C 10.339 0 10.551 0.088 10.707 0.244 L 13.065 2.601 C 13.221 2.758 13.309 2.97 13.309 3.191 C 13.309 3.412 13.221 3.624 13.065 3.78 L 3.536 13.309 Z M 0 14.976 L 15 14.976 L 15 16.642 L 0 16.642 L 0 14.976 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2) matrix(1 0 0 1 2.500 1.599)\"/>"
    },
    "IconExpand": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 0 14 L 0 9.471 L 1.235 9.471 L 1.235 11.897 L 3.994 9.138 L 4.862 10.006 L 2.103 12.765 L 4.529 12.765 L 4.529 14 L 0 14 Z M 9.471 14 L 9.471 12.765 L 11.897 12.765 L 9.138 10.006 L 10.006 9.138 L 12.765 11.897 L 12.765 9.471 L 14 9.471 L 14 14 L 9.471 14 Z M 3.994 4.862 L 1.235 2.103 L 1.235 4.529 L 0 4.529 L 0 0 L 4.529 0 L 4.529 1.235 L 2.103 1.235 L 4.862 3.994 L 3.994 4.862 Z M 10.006 4.862 L 9.138 3.994 L 11.897 1.235 L 9.471 1.235 L 9.471 0 L 14 0 L 14 4.529 L 12.765 4.529 L 12.765 2.103 L 10.006 4.862 Z M 7 8.37 C 6.623 8.37 6.301 8.236 6.033 7.967 C 5.764 7.699 5.63 7.377 5.63 7 C 5.63 6.623 5.764 6.301 6.033 6.033 C 6.301 5.764 6.623 5.63 7 5.63 C 7.377 5.63 7.699 5.764 7.967 6.033 C 8.236 6.301 8.37 6.623 8.37 7 C 8.37 7.377 8.236 7.699 7.967 7.967 C 7.699 8.236 7.377 8.37 7 8.37 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1 0.917)\"/>"
    },
    "IconFilter": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 0 15 L 0.625 15 L 0.625 12.5 L 0 12.5 L -0.625 12.5 L -0.625 15 L 0 15 Z M 8.333 15 L 8.958 15 L 8.958 10 L 8.333 10 L 7.708 10 L 7.708 15 L 8.333 15 Z M 8.333 2.5 L 8.958 2.5 L 8.958 0 L 8.333 0 L 7.708 0 L 7.708 2.5 L 8.333 2.5 Z M 0 5 L 0.625 5 L 0.625 0 L 0 0 L -0.625 0 L -0.625 5 L 0 5 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2) matrix(1 0 0 1 3.333 2.500) matrix(1 0 0 1 2.500 0)\"/><path d=\"M 1.029 9.873 L 1.268 9.296 L 1.268 9.296 L 1.029 9.873 Z M 0.127 8.971 L 0.704 8.732 L 0.704 8.732 L 0.127 8.971 Z M 0.127 6.029 L 0.704 6.268 L 0.704 6.268 L 0.127 6.029 Z M 1.029 5.127 L 1.268 5.704 L 1.268 5.704 L 1.029 5.127 Z M 3.971 5.127 L 3.732 5.704 L 3.732 5.704 L 3.971 5.127 Z M 4.873 6.029 L 4.296 6.268 L 4.296 6.268 L 4.873 6.029 Z M 4.873 8.971 L 4.296 8.732 L 4.296 8.732 L 4.873 8.971 Z M 3.971 9.873 L 3.732 9.296 L 3.732 9.296 L 3.971 9.873 Z M 9.362 4.873 L 9.602 4.296 L 9.602 4.296 L 9.362 4.873 Z M 8.46 3.971 L 9.037 3.732 L 9.037 3.732 L 8.46 3.971 Z M 8.46 1.029 L 9.037 1.268 L 9.037 1.268 L 8.46 1.029 Z M 9.362 0.127 L 9.602 0.704 L 9.602 0.704 L 9.362 0.127 Z M 12.304 0.127 L 12.065 0.704 L 12.065 0.704 L 12.304 0.127 Z M 13.207 1.029 L 12.629 1.268 L 12.629 1.268 L 13.207 1.029 Z M 13.207 3.971 L 12.629 3.732 L 12.629 3.732 L 13.207 3.971 Z M 12.304 4.873 L 12.065 4.296 L 12.065 4.296 L 12.304 4.873 Z M 2.5 10 L 2.5 9.375 C 2.103 9.375 1.837 9.375 1.631 9.361 C 1.43 9.347 1.332 9.322 1.268 9.296 L 1.029 9.873 L 0.79 10.451 C 1.032 10.551 1.281 10.59 1.546 10.608 C 1.804 10.625 2.12 10.625 2.5 10.625 L 2.5 10 Z M 1.029 9.873 L 1.268 9.296 C 1.142 9.244 1.027 9.167 0.93 9.07 L 0.488 9.512 L 0.046 9.954 C 0.259 10.167 0.512 10.336 0.79 10.451 L 1.029 9.873 Z M 0.488 9.512 L 0.93 9.07 C 0.833 8.973 0.756 8.858 0.704 8.732 L 0.127 8.971 L -0.451 9.21 C -0.336 9.488 -0.167 9.741 0.046 9.954 L 0.488 9.512 Z M 0.127 8.971 L 0.704 8.732 C 0.678 8.668 0.653 8.57 0.639 8.369 C 0.625 8.163 0.625 7.897 0.625 7.5 L 0 7.5 L -0.625 7.5 C -0.625 7.88 -0.625 8.196 -0.608 8.454 C -0.59 8.719 -0.551 8.968 -0.451 9.21 L 0.127 8.971 Z M 0 7.5 L 0.625 7.5 C 0.625 7.103 0.625 6.837 0.639 6.631 C 0.653 6.43 0.678 6.332 0.704 6.268 L 0.127 6.029 L -0.451 5.79 C -0.551 6.032 -0.59 6.281 -0.608 6.546 C -0.625 6.804 -0.625 7.12 -0.625 7.5 L 0 7.5 Z M 0.127 6.029 L 0.704 6.268 C 0.756 6.142 0.833 6.027 0.93 5.93 L 0.488 5.488 L 0.046 5.046 C -0.167 5.259 -0.336 5.512 -0.451 5.79 L 0.127 6.029 Z M 0.488 5.488 L 0.93 5.93 C 1.027 5.833 1.142 5.756 1.268 5.704 L 1.029 5.127 L 0.79 4.549 C 0.512 4.664 0.259 4.833 0.046 5.046 L 0.488 5.488 Z M 1.029 5.127 L 1.268 5.704 C 1.332 5.678 1.43 5.653 1.631 5.639 C 1.837 5.625 2.103 5.625 2.5 5.625 L 2.5 5 L 2.5 4.375 C 2.12 4.375 1.804 4.375 1.546 4.392 C 1.281 4.41 1.032 4.449 0.79 4.549 L 1.029 5.127 Z M 2.5 5 L 2.5 5.625 C 2.897 5.625 3.163 5.625 3.369 5.639 C 3.57 5.653 3.668 5.678 3.732 5.704 L 3.971 5.127 L 4.21 4.549 C 3.968 4.449 3.719 4.41 3.454 4.392 C 3.196 4.375 2.88 4.375 2.5 4.375 L 2.5 5 Z M 3.971 5.127 L 3.732 5.704 C 3.858 5.756 3.973 5.833 4.07 5.93 L 4.512 5.488 L 4.954 5.046 C 4.741 4.833 4.488 4.664 4.21 4.549 L 3.971 5.127 Z M 4.512 5.488 L 4.07 5.93 C 4.167 6.027 4.244 6.142 4.296 6.268 L 4.873 6.029 L 5.451 5.79 C 5.336 5.512 5.167 5.259 4.954 5.046 L 4.512 5.488 Z M 4.873 6.029 L 4.296 6.268 C 4.322 6.332 4.347 6.43 4.361 6.631 C 4.375 6.837 4.375 7.103 4.375 7.5 L 5 7.5 L 5.625 7.5 C 5.625 7.12 5.625 6.804 5.608 6.546 C 5.59 6.281 5.551 6.032 5.451 5.79 L 4.873 6.029 Z M 5 7.5 L 4.375 7.5 C 4.375 7.897 4.375 8.163 4.361 8.369 C 4.347 8.57 4.322 8.668 4.296 8.732 L 4.873 8.971 L 5.451 9.21 C 5.551 8.968 5.59 8.719 5.608 8.454 C 5.625 8.196 5.625 7.88 5.625 7.5 L 5 7.5 Z M 4.873 8.971 L 4.296 8.732 C 4.244 8.858 4.167 8.973 4.07 9.07 L 4.512 9.512 L 4.954 9.954 C 5.167 9.741 5.336 9.488 5.451 9.21 L 4.873 8.971 Z M 4.512 9.512 L 4.07 9.07 C 3.973 9.167 3.858 9.244 3.732 9.296 L 3.971 9.873 L 4.21 10.451 C 4.488 10.336 4.741 10.167 4.954 9.954 L 4.512 9.512 Z M 3.971 9.873 L 3.732 9.296 C 3.668 9.322 3.57 9.347 3.369 9.361 C 3.163 9.375 2.897 9.375 2.5 9.375 L 2.5 10 L 2.5 10.625 C 2.88 10.625 3.196 10.625 3.454 10.608 C 3.719 10.59 3.968 10.551 4.21 10.451 L 3.971 9.873 Z M 10.833 5 L 10.833 4.375 C 10.436 4.375 10.17 4.375 9.964 4.361 C 9.763 4.347 9.666 4.322 9.602 4.296 L 9.362 4.873 L 9.123 5.451 C 9.365 5.551 9.615 5.59 9.879 5.608 C 10.137 5.625 10.454 5.625 10.833 5.625 L 10.833 5 Z M 9.362 4.873 L 9.602 4.296 C 9.475 4.244 9.36 4.167 9.263 4.07 L 8.821 4.512 L 8.379 4.954 C 8.592 5.167 8.845 5.336 9.123 5.451 L 9.362 4.873 Z M 8.821 4.512 L 9.263 4.07 C 9.167 3.973 9.09 3.858 9.037 3.732 L 8.46 3.971 L 7.883 4.21 C 7.998 4.488 8.167 4.741 8.379 4.954 L 8.821 4.512 Z M 8.46 3.971 L 9.037 3.732 C 9.011 3.668 8.986 3.57 8.973 3.369 C 8.959 3.163 8.958 2.897 8.958 2.5 L 8.333 2.5 L 7.708 2.5 C 7.708 2.88 7.708 3.196 7.726 3.454 C 7.744 3.719 7.782 3.968 7.883 4.21 L 8.46 3.971 Z M 8.333 2.5 L 8.958 2.5 C 8.958 2.103 8.959 1.837 8.973 1.631 C 8.986 1.43 9.011 1.332 9.037 1.268 L 8.46 1.029 L 7.883 0.79 C 7.782 1.032 7.744 1.281 7.726 1.546 C 7.708 1.804 7.708 2.12 7.708 2.5 L 8.333 2.5 Z M 8.46 1.029 L 9.037 1.268 C 9.09 1.142 9.167 1.027 9.263 0.93 L 8.821 0.488 L 8.379 0.046 C 8.167 0.259 7.998 0.512 7.883 0.79 L 8.46 1.029 Z M 8.821 0.488 L 9.263 0.93 C 9.36 0.833 9.475 0.756 9.602 0.704 L 9.362 0.127 L 9.123 -0.451 C 8.845 -0.336 8.592 -0.167 8.379 0.046 L 8.821 0.488 Z M 9.362 0.127 L 9.602 0.704 C 9.666 0.678 9.763 0.653 9.964 0.639 C 10.17 0.625 10.436 0.625 10.833 0.625 L 10.833 0 L 10.833 -0.625 C 10.454 -0.625 10.137 -0.625 9.879 -0.608 C 9.615 -0.59 9.365 -0.551 9.123 -0.451 L 9.362 0.127 Z M 10.833 0 L 10.833 0.625 C 11.23 0.625 11.497 0.625 11.703 0.639 C 11.904 0.653 12.001 0.678 12.065 0.704 L 12.304 0.127 L 12.543 -0.451 C 12.301 -0.551 12.052 -0.59 11.788 -0.608 C 11.529 -0.625 11.213 -0.625 10.833 -0.625 L 10.833 0 Z M 12.304 0.127 L 12.065 0.704 C 12.192 0.756 12.307 0.833 12.403 0.93 L 12.845 0.488 L 13.287 0.046 C 13.074 -0.167 12.821 -0.336 12.543 -0.451 L 12.304 0.127 Z M 12.845 0.488 L 12.403 0.93 C 12.5 1.027 12.577 1.142 12.629 1.268 L 13.207 1.029 L 13.784 0.79 C 13.669 0.512 13.5 0.259 13.287 0.046 L 12.845 0.488 Z M 13.207 1.029 L 12.629 1.268 C 12.656 1.332 12.68 1.43 12.694 1.631 C 12.708 1.837 12.708 2.103 12.708 2.5 L 13.333 2.5 L 13.958 2.5 C 13.958 2.12 13.959 1.804 13.941 1.546 C 13.923 1.281 13.884 1.032 13.784 0.79 L 13.207 1.029 Z M 13.333 2.5 L 12.708 2.5 C 12.708 2.897 12.708 3.163 12.694 3.369 C 12.68 3.57 12.656 3.668 12.629 3.732 L 13.207 3.971 L 13.784 4.21 C 13.884 3.968 13.923 3.719 13.941 3.454 C 13.959 3.196 13.958 2.88 13.958 2.5 L 13.333 2.5 Z M 13.207 3.971 L 12.629 3.732 C 12.577 3.858 12.5 3.973 12.403 4.07 L 12.845 4.512 L 13.287 4.954 C 13.5 4.741 13.669 4.488 13.784 4.21 L 13.207 3.971 Z M 12.845 4.512 L 12.403 4.07 C 12.307 4.167 12.192 4.244 12.065 4.296 L 12.304 4.873 L 12.543 5.451 C 12.821 5.336 13.074 5.167 13.287 4.954 L 12.845 4.512 Z M 12.304 4.873 L 12.065 4.296 C 12.001 4.322 11.904 4.347 11.703 4.361 C 11.497 4.375 11.23 4.375 10.833 4.375 L 10.833 5 L 10.833 5.625 C 11.213 5.625 11.529 5.625 11.788 5.608 C 12.052 5.59 12.301 5.551 12.543 5.451 L 12.304 4.873 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2) matrix(1 0 0 1 3.333 2.500) matrix(1 0 0 1 0 2.500)\"/>"
    },
    "IconHelp": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 8.333 16.667 C 3.731 16.667 0 12.936 0 8.333 C 0 3.731 3.731 0 8.333 0 C 12.936 0 16.667 3.731 16.667 8.333 C 16.667 12.936 12.936 16.667 8.333 16.667 Z M 8.333 15 C 10.101 15 11.797 14.298 13.047 13.047 C 14.298 11.797 15 10.101 15 8.333 C 15 6.565 14.298 4.87 13.047 3.619 C 11.797 2.369 10.101 1.667 8.333 1.667 C 6.565 1.667 4.87 2.369 3.619 3.619 C 2.369 4.87 1.667 6.565 1.667 8.333 C 1.667 10.101 2.369 11.797 3.619 13.047 C 4.87 14.298 6.565 15 8.333 15 Z M 7.5 11.667 L 9.167 11.667 L 9.167 13.333 L 7.5 13.333 L 7.5 11.667 Z M 7.5 10.007 C 7.5 10.007 9.167 10 9.167 10.007 C 9.167 9.172 11.667 8.333 11.667 6.667 C 11.667 4.825 10.189 3.333 8.341 3.333 C 7.902 3.332 7.468 3.418 7.063 3.585 C 6.658 3.752 6.289 3.997 5.979 4.307 C 5.669 4.617 5.422 4.984 5.254 5.389 C 5.086 5.794 5 6.228 5 6.667 L 6.667 6.667 C 6.667 5.75 7.417 5 8.333 5 C 9.25 5 10 5.75 10 6.667 C 10 7.417 7.5 8.639 7.5 10.007 Z\" fill=\"currentColor\" fill-rule=\"evenodd\" transform=\"matrix(1 0 0 1 2 2) matrix(1 0 0 1 1.667 1.667)\"/>"
    },
    "IconHomeStateHomeSize1rem": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 1.333 10.667 L 3.333 10.667 L 3.333 6.667 L 7.333 6.667 L 7.333 10.667 L 9.333 10.667 L 9.333 4.667 L 5.333 1.667 L 1.333 4.667 L 1.333 10.667 Z M 0 12 L 0 4 L 5.333 0 L 10.667 4 L 10.667 12 L 6 12 L 6 8 L 4.667 8 L 4.667 12 L 0 12 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2.667 2)\"/>"
    },
    "IconHomeStateSelectedSize1rem": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 0 12 L 0 4 L 5.333 0 L 10.667 4 L 10.667 12 L 6 12 L 6 8 L 4.667 8 L 4.667 12 L 0 12 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2.667 2)\"/>"
    },
    "IconInfo": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 7.5 12.5 L 9.167 12.5 L 9.167 7.5 L 7.5 7.5 L 7.5 12.5 Z M 8.333 5.833 C 8.569 5.833 8.768 5.753 8.928 5.593 C 9.088 5.433 9.167 5.236 9.167 5 C 9.166 4.764 9.086 4.567 8.927 4.407 C 8.767 4.247 8.569 4.167 8.333 4.167 C 8.097 4.167 7.899 4.247 7.74 4.407 C 7.581 4.567 7.501 4.764 7.5 5 C 7.499 5.236 7.579 5.434 7.74 5.594 C 7.901 5.755 8.098 5.834 8.333 5.833 Z M 8.333 16.667 C 7.181 16.667 6.097 16.448 5.083 16.01 C 4.069 15.572 3.188 14.979 2.438 14.229 C 1.688 13.48 1.094 12.598 0.657 11.583 C 0.219 10.569 0.001 9.486 0 8.333 C -0.001 7.181 0.218 6.098 0.657 5.083 C 1.095 4.069 1.689 3.187 2.438 2.438 C 3.186 1.688 4.068 1.094 5.083 0.657 C 6.098 0.219 7.182 0 8.333 0 C 9.485 0 10.568 0.219 11.583 0.657 C 12.598 1.094 13.48 1.688 14.229 2.438 C 14.978 3.187 15.572 4.069 16.011 5.083 C 16.45 6.098 16.668 7.181 16.667 8.333 C 16.665 9.486 16.446 10.569 16.01 11.583 C 15.574 12.598 14.98 13.48 14.229 14.229 C 13.478 14.979 12.596 15.573 11.583 16.011 C 10.571 16.449 9.487 16.668 8.333 16.667 Z M 8.333 15 C 10.194 15 11.771 14.354 13.063 13.063 C 14.354 11.771 15 10.194 15 8.333 C 15 6.472 14.354 4.896 13.063 3.604 C 11.771 2.313 10.194 1.667 8.333 1.667 C 6.472 1.667 4.896 2.313 3.604 3.604 C 2.313 4.896 1.667 6.472 1.667 8.333 C 1.667 10.194 2.313 11.771 3.604 13.063 C 4.896 14.354 6.472 15 8.333 15 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2) matrix(1 0 0 1 1.667 1.667)\"/>"
    },
    "IconInfographic": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 6.125 0 C 7.467 0.136 8.61 0.676 9.555 1.619 C 10.501 2.562 11.039 3.704 11.171 5.046 L 7.263 5.046 C 7.156 4.783 7.005 4.555 6.81 4.36 C 6.616 4.166 6.388 4.015 6.125 3.908 L 6.125 0 Z M 7.175 1.298 L 7.175 3.267 C 7.313 3.372 7.445 3.484 7.57 3.601 C 7.696 3.718 7.807 3.85 7.904 3.996 L 9.873 3.996 C 9.64 3.364 9.29 2.815 8.823 2.348 C 8.356 1.881 7.807 1.531 7.175 1.298 Z M 5.075 0 L 5.075 3.908 C 4.715 4.044 4.421 4.261 4.193 4.557 C 3.964 4.854 3.85 5.191 3.85 5.568 C 3.85 5.946 3.964 6.286 4.193 6.589 C 4.421 6.892 4.715 7.107 5.075 7.233 L 5.075 11.142 C 3.626 10.996 2.418 10.392 1.451 9.33 C 0.484 8.268 0 7.015 0 5.571 C 0 4.124 0.484 2.869 1.452 1.806 C 2.42 0.742 3.628 0.14 5.075 0 Z M 4.025 1.298 C 3.131 1.648 2.411 2.209 1.867 2.982 C 1.322 3.755 1.05 4.62 1.05 5.578 C 1.05 6.536 1.322 7.401 1.867 8.174 C 2.411 8.947 3.131 9.503 4.025 9.844 L 4.025 7.88 C 3.656 7.604 3.359 7.266 3.135 6.866 C 2.912 6.466 2.8 6.034 2.8 5.571 C 2.8 5.108 2.912 4.676 3.135 4.276 C 3.359 3.875 3.656 3.539 4.025 3.267 L 4.025 1.298 Z M 7.263 6.096 L 11.171 6.096 C 11.035 7.438 10.495 8.581 9.552 9.526 C 8.609 10.472 7.467 11.01 6.125 11.142 L 6.125 7.233 C 6.388 7.126 6.618 6.976 6.818 6.781 C 7.017 6.587 7.165 6.358 7.263 6.096 Z M 7.904 7.146 C 7.807 7.292 7.698 7.425 7.576 7.547 C 7.455 7.668 7.321 7.778 7.175 7.875 L 7.175 9.844 C 7.807 9.61 8.356 9.26 8.823 8.794 C 9.29 8.327 9.64 7.778 9.873 7.146 L 7.904 7.146 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2.415 2.429)\"/>"
    },
    "IconLifeEventsProperty1DefaultSize1rem": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 6.247 1.514 L 6.731 1.118 L 6.543 0.889 L 6.247 0.889 L 6.247 1.514 Z M 0.195 1.514 L 0.195 0.889 L -0.43 0.889 L -0.43 1.514 L 0.195 1.514 Z M 0.195 5.79 L -0.43 5.79 L -0.43 6.415 L 0.195 6.415 L 0.195 5.79 Z M 6.247 5.79 L 6.247 6.415 L 6.543 6.415 L 6.731 6.187 L 6.247 5.79 Z M 8 3.652 L 8.483 4.049 L 8.808 3.652 L 8.483 3.256 L 8 3.652 Z M 2.667 5.986 L 2.042 5.986 L 2.042 12 L 2.667 12 L 3.292 12 L 3.292 5.986 L 2.667 5.986 Z M 2.667 0 L 2.042 0 L 2.042 1.405 L 2.667 1.405 L 3.292 1.405 L 3.292 0 L 2.667 0 Z M 0 12 L 0 12.625 L 5.333 12.625 L 5.333 12 L 5.333 11.375 L 0 11.375 L 0 12 Z M 8 3.652 L 8.483 3.256 L 6.731 1.118 L 6.247 1.514 L 5.764 1.911 L 7.517 4.049 L 8 3.652 Z M 6.247 5.79 L 6.731 6.187 L 8.483 4.049 L 8 3.652 L 7.517 3.256 L 5.764 5.394 L 6.247 5.79 Z M 6.247 1.514 L 6.247 0.889 L 0.195 0.889 L 0.195 1.514 L 0.195 2.139 L 6.247 2.139 L 6.247 1.514 Z M 0.195 1.514 L -0.43 1.514 L -0.43 5.79 L 0.195 5.79 L 0.82 5.79 L 0.82 1.514 L 0.195 1.514 Z M 0.195 5.79 L 0.195 6.415 L 6.247 6.415 L 6.247 5.79 L 6.247 5.165 L 0.195 5.165 L 0.195 5.79 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 4 2)\"/>"
    },
    "IconLifeEventsProperty1SelectedSize1rem": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 6.247 1.514 L 0.195 1.514 L 0.195 5.79 L 6.247 5.79 L 8 3.652 L 6.247 1.514 Z M 2.667 5.986 L 2.667 12 Z M 2.667 0 L 2.667 1.405 Z M 0 12 L 5.333 12 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 4 2)\"/><path d=\"M 6.247 1.514 L 6.731 1.118 L 6.543 0.889 L 6.247 0.889 L 6.247 1.514 Z M 0.195 1.514 L 0.195 0.889 L -0.43 0.889 L -0.43 1.514 L 0.195 1.514 Z M 0.195 5.79 L -0.43 5.79 L -0.43 6.415 L 0.195 6.415 L 0.195 5.79 Z M 6.247 5.79 L 6.247 6.415 L 6.543 6.415 L 6.731 6.187 L 6.247 5.79 Z M 8 3.652 L 8.483 4.049 L 8.808 3.652 L 8.483 3.256 L 8 3.652 Z M 2.667 5.986 L 2.042 5.986 L 2.042 12 L 2.667 12 L 3.292 12 L 3.292 5.986 L 2.667 5.986 Z M 2.667 0 L 2.042 0 L 2.042 1.405 L 2.667 1.405 L 3.292 1.405 L 3.292 0 L 2.667 0 Z M 0 12 L 0 12.625 L 5.333 12.625 L 5.333 12 L 5.333 11.375 L 0 11.375 L 0 12 Z M 8 3.652 L 8.483 3.256 L 6.731 1.118 L 6.247 1.514 L 5.764 1.911 L 7.517 4.049 L 8 3.652 Z M 6.247 5.79 L 6.731 6.187 L 8.483 4.049 L 8 3.652 L 7.517 3.256 L 5.764 5.394 L 6.247 5.79 Z M 6.247 1.514 L 6.247 0.889 L 0.195 0.889 L 0.195 1.514 L 0.195 2.139 L 6.247 2.139 L 6.247 1.514 Z M 0.195 1.514 L -0.43 1.514 L -0.43 5.79 L 0.195 5.79 L 0.82 5.79 L 0.82 1.514 L 0.195 1.514 Z M 0.195 5.79 L 0.195 6.415 L 6.247 6.415 L 6.247 5.79 L 6.247 5.165 L 0.195 5.165 L 0.195 5.79 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 4 2)\"/>"
    },
    "IconLogOut": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 12.5 3.333 L 11.325 4.508 L 13.475 6.667 L 5 6.667 L 5 8.333 L 13.475 8.333 L 11.325 10.483 L 12.5 11.667 L 16.667 7.5 M 1.667 1.667 L 8.333 1.667 L 8.333 0 L 1.667 0 C 0.75 0 0 0.75 0 1.667 L 0 13.333 C 0 14.25 0.75 15 1.667 15 L 8.333 15 L 8.333 13.333 L 1.667 13.333 L 1.667 1.667 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2) matrix(1 0 0 1 1.667 2.500)\"/>"
    },
    "IconMenu": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 0 10 L 0 8.333 L 15 8.333 L 15 10 L 0 10 Z M 0 5.833 L 0 4.167 L 15 4.167 L 15 5.833 L 0 5.833 Z M 0 1.667 L 0 0 L 15 0 L 15 1.667 L 0 1.667 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2) matrix(1 0 0 1 2.500 5)\"/>"
    },
    "IconMenuDots": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 3.333 1.667 C 3.333 2.109 3.158 2.533 2.845 2.845 C 2.533 3.158 2.109 3.333 1.667 3.333 C 1.225 3.333 0.801 3.158 0.488 2.845 C 0.176 2.533 0 2.109 0 1.667 C 0 1.225 0.176 0.801 0.488 0.488 C 0.801 0.176 1.225 0 1.667 0 C 2.109 0 2.533 0.176 2.845 0.488 C 3.158 0.801 3.333 1.225 3.333 1.667 Z M 9.167 1.667 C 9.167 2.109 8.991 2.533 8.679 2.845 C 8.366 3.158 7.942 3.333 7.5 3.333 C 7.058 3.333 6.634 3.158 6.321 2.845 C 6.009 2.533 5.833 2.109 5.833 1.667 C 5.833 1.225 6.009 0.801 6.321 0.488 C 6.634 0.176 7.058 0 7.5 0 C 7.942 0 8.366 0.176 8.679 0.488 C 8.991 0.801 9.167 1.225 9.167 1.667 Z M 15 1.667 C 15 2.109 14.824 2.533 14.512 2.845 C 14.199 3.158 13.775 3.333 13.333 3.333 C 12.891 3.333 12.467 3.158 12.155 2.845 C 11.842 2.533 11.667 2.109 11.667 1.667 C 11.667 1.225 11.842 0.801 12.155 0.488 C 12.467 0.176 12.891 0 13.333 0 C 13.775 0 14.199 0.176 14.512 0.488 C 14.824 0.801 15 1.225 15 1.667 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2) matrix(0 1 -1 0 11.667 2.501)\"/>"
    },
    "IconMenuOpen": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 0 14.167 L 0 0 L 1.25 0 L 1.25 14.167 L 0 14.167 Z M 3.077 10.681 L 3.077 3.494 L 6.611 7.083 L 3.077 10.681 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 5.695 0.917)\"/>"
    },
    "IconNotificationProperty1Badge": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 6 3 C 6 4.657 4.657 6 3 6 C 1.343 6 0 4.657 0 3 C 0 1.343 1.343 0 3 0 C 4.657 0 6 1.343 6 3 Z\" fill=\"rgb(240,83,17)\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2) matrix(1 0 0 1 13.007 3.242)\"/><path d=\"M 9.167 15.833 C 9.167 16.75 8.417 17.5 7.5 17.5 C 6.583 17.5 5.833 16.75 5.833 15.833 L 9.167 15.833 Z\" fill=\"rgb(56,56,56)\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2) matrix(1 0 0 1 2.500 1.668)\"/><path d=\"M 7.5 0 C 8.417 0 9.167 0.75 9.167 1.667 L 9.167 1.917 C 9.526 2.025 9.867 2.164 10.188 2.33 C 9.754 2.97 9.5 3.742 9.5 4.574 C 9.5 6.727 11.201 8.482 13.333 8.569 L 13.333 12.5 L 15 14.167 L 15 15 L 0 15 L 0 14.167 L 1.667 12.5 L 1.667 7.5 C 1.667 4.917 3.333 2.667 5.833 1.917 L 5.833 1.667 C 5.833 0.75 6.583 0 7.5 0 Z\" fill=\"rgb(56,56,56)\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2) matrix(1 0 0 1 2.500 1.668)\"/>"
    },
    "IconNotificationProperty1Bell": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 5.833 15.833 L 9.167 15.833 C 9.167 16.75 8.417 17.5 7.5 17.5 C 6.583 17.5 5.833 16.75 5.833 15.833 Z M 15 14.167 L 15 15 L 0 15 L 0 14.167 L 1.667 12.5 L 1.667 7.5 C 1.667 4.917 3.333 2.667 5.833 1.917 L 5.833 1.667 C 5.833 0.75 6.583 0 7.5 0 C 8.417 0 9.167 0.75 9.167 1.667 L 9.167 1.917 C 11.667 2.667 13.333 4.917 13.333 7.5 L 13.333 12.5 L 15 14.167 Z M 11.667 7.5 C 11.667 5.167 9.833 3.333 7.5 3.333 C 5.167 3.333 3.333 5.167 3.333 7.5 L 3.333 13.333 L 11.667 13.333 L 11.667 7.5 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2) matrix(1 0 0 1 2.500 1.667)\"/>"
    },
    "IconPlusProperty11rem": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 0.817 8.167 L 0 7.35 L 3.267 4.083 L 0 0.817 L 0.817 0 L 4.083 3.267 L 7.35 0 L 8.167 0.817 L 4.9 4.083 L 8.167 7.35 L 7.35 8.167 L 4.083 4.9 L 0.817 8.167 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1 1) matrix(0.707 0.707 -0.707 0.707 7.350 1.068)\"/>"
    },
    "IconPlusProperty1Plus": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 1.167 11.667 L 0 10.5 L 4.667 5.833 L 0 1.167 L 1.167 0 L 5.833 4.667 L 10.5 0 L 11.667 1.167 L 7 5.833 L 11.667 10.5 L 10.5 11.667 L 5.833 7 L 1.167 11.667 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2) matrix(0.707 0.707 -0.707 0.707 10.500 1.525)\"/>"
    },
    "IconResetProperty11rem": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 11.111 5.556 C 11.111 8.624 8.624 11.111 5.556 11.111 C 2.487 11.111 0 8.624 0 5.556 C 0 2.487 2.487 0 5.556 0 L 5.556 1.111 C 4.51 1.111 3.499 1.48 2.698 2.152 C 1.898 2.824 1.36 3.756 1.179 4.785 C 0.998 5.815 1.185 6.875 1.708 7.78 C 2.231 8.685 3.056 9.376 4.039 9.733 C 5.021 10.09 6.098 10.089 7.079 9.731 C 8.061 9.372 8.885 8.68 9.407 7.774 C 9.929 6.868 10.115 5.808 9.932 4.779 C 9.749 3.75 9.21 2.818 8.408 2.147 L 7.222 3.333 L 7.222 0 L 10.556 0 L 9.196 1.359 C 9.798 1.88 10.28 2.525 10.611 3.249 C 10.941 3.973 11.112 4.76 11.111 5.556 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1.333 1.333) matrix(1 0 0 1 1.111 1.111)\"/>"
    },
    "IconResetProperty1Reset": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 16.667 8.333 C 16.667 12.936 12.936 16.667 8.333 16.667 C 3.731 16.667 0 12.936 0 8.333 C 0 3.731 3.731 0 8.333 0 L 8.333 1.667 C 6.766 1.667 5.248 2.219 4.047 3.227 C 2.847 4.235 2.04 5.634 1.768 7.178 C 1.496 8.722 1.778 10.313 2.562 11.67 C 3.347 13.027 4.584 14.064 6.058 14.6 C 7.532 15.135 9.147 15.133 10.619 14.596 C 12.092 14.059 13.328 13.019 14.111 11.661 C 14.893 10.303 15.172 8.712 14.898 7.168 C 14.624 5.625 13.815 4.227 12.613 3.221 L 10.833 5 L 10.833 0 L 15.833 0 L 13.794 2.039 C 14.697 2.821 15.42 3.787 15.916 4.873 C 16.412 5.959 16.668 7.14 16.667 8.333 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2) matrix(1 0 0 1 1.667 1.667)\"/>"
    },
    "IconSearch": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 13.833 15 L 8.583 9.75 C 8.167 10.083 7.688 10.347 7.146 10.542 C 6.604 10.736 6.028 10.833 5.417 10.833 C 3.903 10.833 2.622 10.309 1.573 9.26 C 0.525 8.211 0.001 6.93 0 5.417 C -0.001 3.903 0.524 2.622 1.573 1.573 C 2.623 0.524 3.904 0 5.417 0 C 6.929 0 8.211 0.524 9.261 1.573 C 10.311 2.622 10.835 3.903 10.833 5.417 C 10.833 6.028 10.736 6.604 10.542 7.146 C 10.347 7.687 10.083 8.167 9.75 8.583 L 15 13.833 L 13.833 15 Z M 5.417 9.167 C 6.458 9.167 7.344 8.802 8.073 8.073 C 8.803 7.344 9.167 6.459 9.167 5.417 C 9.166 4.374 8.802 3.489 8.073 2.761 C 7.345 2.033 6.459 1.668 5.417 1.667 C 4.374 1.666 3.489 2.03 2.761 2.761 C 2.033 3.491 1.668 4.377 1.667 5.417 C 1.665 6.457 2.03 7.342 2.761 8.073 C 3.492 8.804 4.377 9.169 5.417 9.167 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2) matrix(1 0 0 1 2.500 2.500)\"/>"
    },
    "IconShare": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 7.5 0 L 12.673 5.173 L 11.494 6.351 L 8.333 3.19 L 8.333 11.178 L 6.667 11.178 L 6.667 3.19 L 3.506 6.351 L 2.328 5.173 L 7.5 0 Z M 0 12.845 L 0 9.512 L 1.667 9.512 L 1.667 12.845 C 1.667 13.066 1.754 13.278 1.911 13.434 C 2.067 13.591 2.279 13.678 2.5 13.678 L 12.5 13.678 C 12.721 13.678 12.933 13.591 13.089 13.434 C 13.246 13.278 13.333 13.066 13.333 12.845 L 13.333 9.512 L 15 9.512 L 15 12.845 C 15 13.508 14.737 14.144 14.268 14.613 C 13.799 15.082 13.163 15.345 12.5 15.345 L 2.5 15.345 C 1.837 15.345 1.201 15.082 0.732 14.613 C 0.263 14.144 0 13.508 0 12.845 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2) matrix(1 0 0 1 2.500 2.155)\"/>"
    },
    "IconShow": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 5 2.5 L 5.833 2.5 L 5 2.5 Z M 2.5 0 L 2.5 -0.833 L 2.5 0 Z M 5 2.5 L 4.167 2.5 C 4.167 2.942 3.991 3.366 3.679 3.679 L 4.268 4.268 L 4.857 4.857 C 5.482 4.232 5.833 3.384 5.833 2.5 L 5 2.5 Z M 4.268 4.268 L 3.679 3.679 C 3.366 3.991 2.942 4.167 2.5 4.167 L 2.5 5 L 2.5 5.833 C 3.384 5.833 4.232 5.482 4.857 4.857 L 4.268 4.268 Z M 2.5 5 L 2.5 4.167 C 2.058 4.167 1.634 3.991 1.321 3.679 L 0.732 4.268 L 0.143 4.857 C 0.768 5.482 1.616 5.833 2.5 5.833 L 2.5 5 Z M 0.732 4.268 L 1.321 3.679 C 1.009 3.366 0.833 2.942 0.833 2.5 L 0 2.5 L -0.833 2.5 C -0.833 3.384 -0.482 4.232 0.143 4.857 L 0.732 4.268 Z M 0 2.5 L 0.833 2.5 C 0.833 2.058 1.009 1.634 1.321 1.321 L 0.732 0.732 L 0.143 0.143 C -0.482 0.768 -0.833 1.616 -0.833 2.5 L 0 2.5 Z M 0.732 0.732 L 1.321 1.321 C 1.634 1.009 2.058 0.833 2.5 0.833 L 2.5 0 L 2.5 -0.833 C 1.616 -0.833 0.768 -0.482 0.143 0.143 L 0.732 0.732 Z M 2.5 0 L 2.5 0.833 C 2.942 0.833 3.366 1.009 3.679 1.321 L 4.268 0.732 L 4.857 0.143 C 4.232 -0.482 3.384 -0.833 2.5 -0.833 L 2.5 0 Z M 4.268 0.732 L 3.679 1.321 C 3.991 1.634 4.167 2.058 4.167 2.5 L 5 2.5 L 5.833 2.5 C 5.833 1.616 5.482 0.768 4.857 0.143 L 4.268 0.732 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2) matrix(1 0 0 1 1.667 4.167) matrix(1 0 0 1 5.833 3.333)\"/><path d=\"M 0 5.833 L -0.776 5.53 C -0.852 5.725 -0.852 5.942 -0.776 6.136 L 0 5.833 Z M 16.667 5.833 L 17.443 6.136 C 17.519 5.942 17.519 5.725 17.443 5.53 L 16.667 5.833 Z M 0 5.833 L 0.776 6.136 C 1.997 3.01 4.823 0.833 8.333 0.833 L 8.333 0 L 8.333 -0.833 C 4.07 -0.833 0.669 1.829 -0.776 5.53 L 0 5.833 Z M 8.333 0 L 8.333 0.833 C 11.843 0.833 14.669 3.01 15.89 6.136 L 16.667 5.833 L 17.443 5.53 C 15.997 1.829 12.597 -0.833 8.333 -0.833 L 8.333 0 Z M 16.667 5.833 L 15.89 5.53 C 14.669 8.657 11.843 10.833 8.333 10.833 L 8.333 11.667 L 8.333 12.5 C 12.597 12.5 15.997 9.838 17.443 6.136 L 16.667 5.833 Z M 8.333 11.667 L 8.333 10.833 C 4.823 10.833 1.997 8.657 0.776 5.53 L 0 5.833 L -0.776 6.136 C 0.669 9.838 4.07 12.5 8.333 12.5 L 8.333 11.667 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2) matrix(1 0 0 1 1.667 4.167)\"/>"
    },
    "IconStars": {
      viewBox: "0 0 13 13",
      body: "<path d=\"M 3.25 8.667 L 5.417 7.015 L 7.583 8.667 L 6.771 5.985 L 8.937 4.442 L 6.283 4.442 L 5.417 1.625 L 4.55 4.442 L 1.896 4.442 L 4.062 5.985 L 3.25 8.667 Z M 5.417 10.833 C 4.667 10.833 3.963 10.691 3.304 10.407 C 2.645 10.122 2.072 9.736 1.584 9.249 C 1.097 8.761 0.711 8.188 0.427 7.529 C 0.142 6.87 0 6.166 0 5.417 C 0 4.667 0.142 3.963 0.427 3.304 C 0.711 2.645 1.097 2.072 1.584 1.584 C 2.072 1.097 2.645 0.711 3.304 0.427 C 3.963 0.142 4.667 0 5.417 0 C 6.166 0 6.87 0.142 7.529 0.427 C 8.188 0.711 8.761 1.097 9.249 1.584 C 9.736 2.072 10.122 2.645 10.407 3.304 C 10.691 3.963 10.833 4.667 10.833 5.417 C 10.833 6.166 10.691 6.87 10.407 7.529 C 10.122 8.188 9.736 8.761 9.249 9.249 C 8.761 9.736 8.188 10.122 7.529 10.407 C 6.87 10.691 6.166 10.833 5.417 10.833 Z M 5.417 9.75 C 6.626 9.75 7.651 9.33 8.491 8.491 C 9.33 7.651 9.75 6.626 9.75 5.417 C 9.75 4.207 9.33 3.182 8.491 2.343 C 7.651 1.503 6.626 1.083 5.417 1.083 C 4.207 1.083 3.182 1.503 2.343 2.343 C 1.503 3.182 1.083 4.207 1.083 5.417 C 1.083 6.626 1.503 7.651 2.343 8.491 C 3.182 9.33 4.207 9.75 5.417 9.75 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 1.083 1.083)\"/>"
    },
    "IconUser": {
      viewBox: "0 0 24 24",
      body: "<path d=\"M 6.667 0 C 7.551 0 8.399 0.351 9.024 0.976 C 9.649 1.601 10 2.449 10 3.333 C 10 4.217 9.649 5.065 9.024 5.69 C 8.399 6.315 7.551 6.667 6.667 6.667 C 5.783 6.667 4.935 6.315 4.31 5.69 C 3.685 5.065 3.333 4.217 3.333 3.333 C 3.333 2.449 3.685 1.601 4.31 0.976 C 4.935 0.351 5.783 0 6.667 0 Z M 6.667 1.667 C 6.225 1.667 5.801 1.842 5.488 2.155 C 5.176 2.467 5 2.891 5 3.333 C 5 3.775 5.176 4.199 5.488 4.512 C 5.801 4.824 6.225 5 6.667 5 C 7.109 5 7.533 4.824 7.845 4.512 C 8.158 4.199 8.333 3.775 8.333 3.333 C 8.333 2.891 8.158 2.467 7.845 2.155 C 7.533 1.842 7.109 1.667 6.667 1.667 Z M 6.667 7.5 C 8.892 7.5 13.333 8.608 13.333 10.833 L 13.333 13.333 L 0 13.333 L 0 10.833 C 0 8.608 4.442 7.5 6.667 7.5 Z M 6.667 9.083 C 4.192 9.083 1.583 10.3 1.583 10.833 L 1.583 11.75 L 11.75 11.75 L 11.75 10.833 C 11.75 10.3 9.142 9.083 6.667 9.083 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2 2) matrix(1 0 0 1 3.333 3.333)\"/>"
    },
    "IconVideos": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 4.063 7.854 L 7.854 5.417 L 4.063 2.979 L 4.063 7.854 Z M 5.417 10.833 C 4.667 10.833 3.963 10.691 3.304 10.407 C 2.645 10.122 2.072 9.736 1.584 9.249 C 1.097 8.761 0.711 8.188 0.427 7.529 C 0.142 6.87 0 6.166 0 5.417 C 0 4.667 0.142 3.963 0.427 3.304 C 0.711 2.645 1.097 2.072 1.584 1.584 C 2.072 1.097 2.645 0.711 3.304 0.427 C 3.963 0.142 4.667 0 5.417 0 C 6.166 0 6.87 0.142 7.529 0.427 C 8.188 0.711 8.761 1.097 9.249 1.584 C 9.736 2.072 10.122 2.645 10.407 3.304 C 10.691 3.963 10.833 4.667 10.833 5.417 C 10.833 6.166 10.691 6.87 10.407 7.529 C 10.122 8.188 9.736 8.761 9.249 9.249 C 8.761 9.736 8.188 10.122 7.529 10.407 C 6.87 10.691 6.166 10.833 5.417 10.833 Z M 5.417 9.75 C 6.626 9.75 7.651 9.33 8.491 8.491 C 9.33 7.651 9.75 6.626 9.75 5.417 C 9.75 4.207 9.33 3.182 8.491 2.343 C 7.651 1.503 6.626 1.083 5.417 1.083 C 4.207 1.083 3.182 1.503 2.343 2.343 C 1.503 3.182 1.083 4.207 1.083 5.417 C 1.083 6.626 1.503 7.651 2.343 8.491 C 3.182 9.33 4.207 9.75 5.417 9.75 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 2.583 2.583)\"/>"
    },
    "IconWorld": {
      viewBox: "0 0 16 16",
      body: "<path d=\"M 5 0 C 2.243 0 0 2.243 0 5 C 0 7.757 2.243 10 5 10 C 7.757 10 10 7.757 10 5 C 10 2.243 7.757 0 5 0 Z M 8.965 4.5 L 7.583 4.5 C 7.521 3.406 7.215 2.339 6.688 1.378 C 7.3 1.664 7.83 2.101 8.228 2.646 C 8.626 3.192 8.88 3.83 8.965 4.5 Z M 5.265 1.013 C 5.782 1.695 6.478 2.904 6.578 4.5 L 3.515 4.5 C 3.584 3.202 4.012 1.986 4.74 1.013 C 4.826 1.008 4.912 1 5 1 C 5.089 1 5.177 1.008 5.265 1.013 Z M 3.344 1.364 C 2.852 2.309 2.568 3.381 2.515 4.5 L 1.034 4.5 C 1.121 3.824 1.378 3.181 1.782 2.632 C 2.186 2.083 2.724 1.647 3.344 1.364 Z M 1.034 5.5 L 2.522 5.5 C 2.59 6.689 2.854 7.739 3.299 8.615 C 2.691 8.328 2.164 7.892 1.768 7.348 C 1.372 6.803 1.12 6.168 1.034 5.5 Z M 4.725 8.986 C 4.024 8.137 3.611 6.948 3.521 5.5 L 6.577 5.5 C 6.473 6.886 6.018 8.098 5.275 8.986 C 5.184 8.992 5.094 9 5 9 C 4.907 9 4.816 8.992 4.725 8.986 Z M 6.731 8.601 C 7.208 7.704 7.5 6.65 7.576 5.5 L 8.965 5.5 C 8.881 6.162 8.632 6.793 8.242 7.334 C 7.852 7.876 7.332 8.311 6.731 8.601 Z\" fill=\"currentColor\" fill-rule=\"nonzero\" transform=\"matrix(1 0 0 1 3 3)\"/>"
    }
  };
} catch {}
Object.assign(__ds_scope, { __ds_default_assets_icons_icon_data_imae2q });
})(); } catch (e) { __ds_ns.__errors.push({ path: "assets/icons/icon-data.js", error: String((e && e.message) || e) }); }

__ds_scope.__ds_default_assets_icons_icon_data_imae2q$nab192 = __ds_scope.__ds_default_assets_icons_icon_data_imae2q;

// assets/icons/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Icon({
  name,
  size,
  ...rest
}) {
  const d = __ds_scope.__ds_default_assets_icons_icon_data_imae2q$nab192[name];
  if (!d) return null;
  return /*#__PURE__*/React.createElement("svg", _extends({
    width: size,
    height: size,
    viewBox: d.viewBox,
    fill: "none"
    // body strings are emitter-controlled <path> markup — geometry,
    // numeric fills and transforms only; no .fig-authored text reaches them.
    ,
    dangerouslySetInnerHTML: {
      __html: d.body
    }
  }, rest));
}
Object.assign(__ds_scope, { Icon, __ds_default_assets_icons_Icon_2pj96j: Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "assets/icons/Icon.jsx", error: String((e && e.message) || e) }); }

// components/brand/AimeeLogo.jsx
try { (() => {
/**
 * Aimee logo lockup — the assistant's wordmark: "Aimee" (Lato Black) + a blue
 * "AI" badge. Use in chat headers, launchers, and entry points.
 */
function AimeeLogo({
  size = 24,
  tone = "ink",
  style = {}
}) {
  const word = tone === "white" ? "var(--ff-white)" : "var(--ff-text-primary)";
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: `${Math.round(size * 0.33)}px`,
      fontFamily: "var(--ff-font)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: `${size}px`,
      fontWeight: "var(--ff-weight-black)",
      color: word,
      lineHeight: 1
    }
  }, "Aimee"), /*#__PURE__*/React.createElement("span", {
    style: {
      background: "var(--ff-blue)",
      color: "var(--ff-white)",
      fontSize: `${Math.round(size * 0.58)}px`,
      fontWeight: "var(--ff-weight-bold)",
      padding: "2px 8px",
      borderRadius: "6px",
      lineHeight: 1.2
    }
  }, "AI"));
}
Object.assign(__ds_scope, { AimeeLogo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/AimeeLogo.jsx", error: String((e && e.message) || e) }); }

// components/brand/Logo.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Financial Finesse logo. The mark ships two ways in the Figma file:
 *  - "icon"     the circular F glyph (top nav, favicons)
 *  - "wordmark" the full FINESSE lockup
 * Colour follows CSS `color` — pass "navy" (default, in-product) or "white"
 * (on the dark navy nav). Any CSS colour also works via the `color` style.
 *
 * NOTE: the source export lost its gradient class bindings, so this renders
 * the brand mark as a solid monochrome silhouette (navy/white), which matches
 * how the app tokenises the logo (--surfaces-color-logo = primary-blue-3).
 */
const ICON_VB = "0 0 72 72";
const MARK_VB = "0 0 705.97 200.43";
const ICON_BODY = "<g id=\"ICON\"><path d=\"M32.26,33.64C25.45,51.76,9,54.53,6.74,55.37c-1.09.42-.53.79,0,.73C7.55,56,8.49,56,8.82,56c1-.05,1.16-.06,1.79.7s3.21,3.51,3.21,3.51c15-4.13,20-17.7,22.87-26.68ZM61.05,15c-4.29,1.69-15.31,6.55-19.49,16.35,4.8-.07,9.75.15,11.4.17,2.64,0,3.47,1.24-.31,1.29-4.08.29-11.63.6-11.63.6-1.64,4.25-7,24.17-27.2,27.74-2.27.41-1.06,1-.12,1,.5,0,1.09,0,1.52-.06a1.81,1.81,0,0,1,1.22.44,30.63,30.63,0,0,0,18.9,6.38c15,.22,24.19-10,25.62-11.55a32.65,32.65,0,0,0,8-20.76,33.89,33.89,0,0,0-6.39-19.93c-.31-.52-.81-1,0-1.31.49-.2.68-.46.22-.58A4.2,4.2,0,0,0,61.05,15ZM53.56,8.15C37.87,13.83,34.09,28.42,33,31.49c1.18-.07,3-.08,4.3-.1,2.12-4,6-13.43,23-17.35a43.12,43.12,0,0,0-4.57-4.16c-.39-.31-1.07-1,.06-1.44.89-.35.35-.66-.21-.66A6.28,6.28,0,0,0,53.56,8.15ZM35.88,3.08h-.94c-11.11.3-18.76,5.28-24.75,12.15s-6.86,15.94-7,18.35a32.81,32.81,0,0,0,5,20.16C24.15,47,28,34.43,28.62,32.45c-1.69,0-5.44.4-6.38.45-.61,0-2.25.21-3.09-.41-1.11-.8.39-1.05,2.05-1.39,1-.2,8.44-.94,8.44-.94C30.35,28,34.16,11.66,52.2,7.45c0,0-5.72-4.34-16.12-4.37Z\"></path><path d=\"M32.26,33.64C25.45,51.76,9,54.53,6.74,55.37c-1.09.42-.53.79,0,.73C7.55,56,8.49,56,8.82,56c1-.05,1.16-.06,1.79.7s3.21,3.51,3.21,3.51c15-4.13,20-17.7,22.87-26.68ZM61.05,15c-4.29,1.69-15.31,6.55-19.49,16.35,4.8-.07,9.75.15,11.4.17,2.64,0,3.47,1.24-.31,1.29-4.08.29-11.63.6-11.63.6-1.64,4.25-7,24.17-27.2,27.74-2.27.41-1.06,1-.12,1,.5,0,1.09,0,1.52-.06a1.81,1.81,0,0,1,1.22.44,30.63,30.63,0,0,0,18.9,6.38c15,.22,24.19-10,25.62-11.55a32.65,32.65,0,0,0,8-20.76,33.89,33.89,0,0,0-6.39-19.93c-.31-.52-.81-1,0-1.31.49-.2.68-.46.22-.58A4.2,4.2,0,0,0,61.05,15ZM53.56,8.15C37.87,13.83,34.09,28.42,33,31.49c1.18-.07,3-.08,4.3-.1,2.12-4,6-13.43,23-17.35a43.12,43.12,0,0,0-4.57-4.16c-.39-.31-1.07-1,.06-1.44.89-.35.35-.66-.21-.66A6.28,6.28,0,0,0,53.56,8.15ZM35.88,3.08h-.94c-11.11.3-18.76,5.28-24.75,12.15s-6.86,15.94-7,18.35a32.81,32.81,0,0,0,5,20.16C24.15,47,28,34.43,28.62,32.45c-1.69,0-5.44.4-6.38.45-.61,0-2.25.21-3.09-.41-1.11-.8.39-1.05,2.05-1.39,1-.2,8.44-.94,8.44-.94C30.35,28,34.16,11.66,52.2,7.45c0,0-5.72-4.34-16.12-4.37Z\"></path></g>";
const MARK_BODY = "<polygon points=\"689.27 88.36 629.32 88.36 629.32 169.4 689.84 169.4 689.84 156.67 643.52 156.67 643.52 134.9 684.07 134.9 684.07 122.17 643.52 122.17 643.52 101.09 689.27 101.09 689.27 88.36\"></polygon><path d=\"M570.71,109.55c0-5.44,4.86-9.73,13.2-9.73,7.41,0,14.7,2.9,22,8.34l7.65-10.77a44.92,44.92,0,0,0-29.4-10.19c-16.09,0-27.66,9.5-27.66,23.62,0,15.05,9.72,20.14,27,24.31,15,3.47,18.28,6.6,18.28,12.5,0,6.25-5.55,10.3-14.35,10.3-10.07,0-17.82-3.81-25.58-10.53l-8.56,10.19a49.9,49.9,0,0,0,33.8,13c17,0,28.92-9,28.92-24.31,0-13.54-8.91-19.68-26-23.85-15.51-3.7-19.22-6.48-19.22-12.84\"></path><path d=\"M500.14,109.55c0-5.44,4.86-9.73,13.19-9.73,7.41,0,14.7,2.9,22,8.34L543,97.39a44.88,44.88,0,0,0-29.4-10.19c-16.08,0-27.65,9.5-27.65,23.62,0,15.05,9.71,20.14,27,24.31,15,3.47,18.29,6.6,18.29,12.5,0,6.25-5.56,10.3-14.35,10.3-10.08,0-17.83-3.81-25.59-10.53l-8.55,10.19a49.89,49.89,0,0,0,33.79,13c17,0,28.93-9,28.93-24.31,0-13.54-8.91-19.68-26-23.85-15.51-3.7-19.21-6.48-19.21-12.84M472.09,88.36H412v81h60.65V156.67H426.26V134.9h40.62V122.17H426.26V101.09h45.83Zm-89.62,56-43.4-56H325.88v81h14V111.74l44.68,57.66h11.92v-81h-14Zm-86.78,25h14.24v-81H295.69ZM280,88.36H219.66v81h14.23v-33h40.87v-13H233.89V101.33H280Z\"></path><path d=\"M555.78,73.34h29.65V66.58H563.21V31.07h-7.43ZM530.39,56.56H515.84l7.24-16.92Zm-3.74-25.8h-6.89l-18.6,42.58h7.61l4.35-10.21h20l4.29,10.21h7.85ZM483.13,73.34h7.43V31.07h-7.43ZM472.9,66.58l-4.77-4.83c-3.63,3.38-6.95,5.49-12.14,5.49-8.09,0-13.95-6.77-13.95-15.09s5.86-15,13.95-15c4.84,0,8.45,2.11,11.84,5.25l4.77-5.5a22.07,22.07,0,0,0-16.55-6.58c-12.8,0-21.8,9.85-21.8,21.92s9.18,21.81,21.5,21.81c7.91,0,12.75-2.9,17.15-7.49m-112.15-10H346.2l7.25-16.92ZM357,30.76h-6.88l-18.6,42.58h7.61l4.35-10.21h20l4.29,10.21h7.85ZM313.38,60.3,290.73,31.07h-6.88V73.34h7.31V43.26l23.31,30.08h6.22V31.07h-7.31Zm-49.58,13h7.43V31.07H263.8ZM251.12,31.07H219.66V73.34h7.43V56.13h21.32V49.37H227.09V37.83h24Z\"></path><polygon points=\"415.98 60.3 393.33 31.07 386.44 31.07 386.44 73.34 393.75 73.34 393.75 43.26 417.06 73.34 423.29 73.34 423.29 31.07 415.98 31.07 415.98 60.3\"></polygon><path d=\"M88.8,94.34c-17,45.12-58,52-63.54,54.1-2.72,1-1.33,2,0,1.83,2-.2,4.39-.32,5.21-.36,2.49-.12,2.88-.15,4.45,1.74s8,8.74,8,8.74c37.29-10.27,49.92-44.06,57-66.42ZM160.48,48c-10.68,4.2-38.12,16.31-48.53,40.7,11.94-.17,24.28.38,28.37.43,6.58.09,8.66,3.08-.77,3.19-10.15.74-29,1.5-29,1.5-4.07,10.59-17.46,60.19-67.72,69.09-5.65,1-2.64,2.44-.29,2.44,1.25,0,2.7-.08,3.78-.16a4.5,4.5,0,0,1,3,1.1c4.71,3.87,21,15.56,47.06,15.87,37.3.57,60.25-24.8,63.8-28.75a81.33,81.33,0,0,0,19.82-51.68C180.46,73,165,53.42,164.17,52.1s-2-2.4,0-3.24c1.23-.5,1.7-1.15.54-1.44A10.33,10.33,0,0,0,160.48,48ZM141.83,30.86C102.77,45,93.36,81.35,90.63,89c2.93-.19,7.48-.2,10.72-.25,5.26-10.06,15-33.45,57.13-43.21-2-2.63-10.4-9.6-11.38-10.35s-2.66-2.46.15-3.58c2.23-.89.87-1.66-.51-1.65A16.66,16.66,0,0,0,141.83,30.86Zm-44-12.62-2.34,0C67.8,19,48.77,31.43,33.85,48.53S16.77,88.21,16.37,94.21A81.7,81.7,0,0,0,29,144.4c39.64-16.76,49.12-48.11,50.78-53-4.2.08-13.55,1-15.89,1.1-1.52.08-5.6.53-7.7-1-2.75-2,1-2.62,5.11-3.47,2.44-.5,21-2.33,21-2.33C84,80.35,93.52,39.62,138.44,29.14c0,0-14.25-10.82-40.15-10.9Z\"></path><path d=\"M88.8,94.34c-17,45.12-58,52-63.54,54.1-2.72,1-1.33,2,0,1.83,2-.2,4.39-.32,5.21-.36,2.49-.12,2.88-.15,4.45,1.74s8,8.74,8,8.74c37.29-10.27,49.92-44.06,57-66.42ZM160.48,48c-10.68,4.2-38.12,16.31-48.53,40.7,11.94-.17,24.28.38,28.37.43,6.58.09,8.66,3.08-.77,3.19-10.15.74-29,1.5-29,1.5-4.07,10.59-17.46,60.19-67.72,69.09-5.65,1-2.64,2.44-.29,2.44,1.25,0,2.7-.08,3.78-.16a4.5,4.5,0,0,1,3,1.1c4.71,3.87,21,15.56,47.06,15.87,37.3.57,60.25-24.8,63.8-28.75a81.33,81.33,0,0,0,19.82-51.68C180.46,73,165,53.42,164.17,52.1s-2-2.4,0-3.24c1.23-.5,1.7-1.15.54-1.44A10.33,10.33,0,0,0,160.48,48ZM141.83,30.86C102.77,45,93.36,81.35,90.63,89c2.93-.19,7.48-.2,10.72-.25,5.26-10.06,15-33.45,57.13-43.21-2-2.63-10.4-9.6-11.38-10.35s-2.66-2.46.15-3.58c2.23-.89.87-1.66-.51-1.65A16.66,16.66,0,0,0,141.83,30.86Zm-44-12.62-2.34,0C67.8,19,48.77,31.43,33.85,48.53S16.77,88.21,16.37,94.21A81.7,81.7,0,0,0,29,144.4c39.64-16.76,49.12-48.11,50.78-53-4.2.08-13.55,1-15.89,1.1-1.52.08-5.6.53-7.7-1-2.75-2,1-2.62,5.11-3.47,2.44-.5,21-2.33,21-2.33C84,80.35,93.52,39.62,138.44,29.14c0,0-14.25-10.82-40.15-10.9Z\"></path>";
function Logo({
  variant = "wordmark",
  tone = "navy",
  height,
  style = {},
  ...rest
}) {
  const isIcon = variant === "icon";
  const vb = isIcon ? ICON_VB : MARK_VB;
  const body = isIcon ? ICON_BODY : MARK_BODY;
  const h = height != null ? height : isIcon ? 36 : 28;
  const color = tone === "white" ? "var(--ff-white)" : tone === "navy" ? "var(--ff-navy)" : tone;
  const ratio = isIcon ? 1 : 705.97 / 200.43;
  return /*#__PURE__*/React.createElement("svg", _extends({
    viewBox: vb,
    height: h,
    width: h * ratio,
    role: "img",
    "aria-label": "Financial Finesse",
    style: {
      color,
      display: "block",
      ...style
    },
    fill: "currentColor"
  }, rest, {
    dangerouslySetInnerHTML: {
      __html: body
    }
  }));
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Logo.jsx", error: String((e && e.message) || e) }); }

// components/buttons/AccentButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Accent button — the circular icon-only action from the Figma "accent button" set.
 * 40px circle, blue #007CAB fill, white glyph. Used for scroll-to-top / send / quick actions.
 */
function AccentButton({
  icon = "IconArrowUp",
  size = 40,
  disabled = false,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: disabled,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: `${size}px`,
      height: `${size}px`,
      padding: 0,
      border: "none",
      borderRadius: "50%",
      backgroundColor: "var(--ff-blue)",
      color: "var(--ff-white)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.4 : 1,
      transition: "background-color .15s ease, transform .05s ease",
      WebkitTapHighlightColor: "transparent",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: Math.round(size * 0.6)
  }));
}
Object.assign(__ds_scope, { AccentButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/buttons/AccentButton.jsx", error: String((e && e.message) || e) }); }

// components/buttons/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Financial Finesse Button.
 * Pill-shaped (radius 32 → fully rounded). Label is Lato SemiBold 16/1.5.
 * Variants copy the Figma button sets verbatim:
 *  - primary   navy #063853 fill, white label
 *  - secondary muted #F4F7FE fill, 1px #D6DCEA border, ink label
 *  - tertiary  no fill, ink label → blue on hover (text/link button)
 *  - nav       white fill, deep-blue label (used on light rails)
 */
function Button({
  children,
  variant = "primary",
  size = "regular",
  icon,
  iconPosition = "leading",
  iconOnly = false,
  disabled = false,
  style = {},
  ...rest
}) {
  const pad = size === "small" ? "6px 16px" : iconOnly ? "8px" : "8px 24px";
  const base = {
    display: "inline-flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: "8px",
    border: "1px solid transparent",
    borderRadius: "var(--ff-radius-pill)",
    padding: iconOnly ? "8px" : pad,
    fontFamily: "var(--ff-font)",
    fontWeight: "var(--ff-weight-bold)",
    fontSize: size === "small" ? "14px" : "16px",
    lineHeight: 1.5,
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.4 : 1,
    whiteSpace: "nowrap",
    transition: "background-color .15s ease, color .15s ease, border-color .15s ease, transform .05s ease",
    WebkitTapHighlightColor: "transparent"
  };
  const variants = {
    primary: {
      backgroundColor: "var(--ff-navy)",
      color: "var(--ff-text-inverse)",
      borderColor: "var(--ff-navy)"
    },
    secondary: {
      backgroundColor: "var(--ff-surface-muted)",
      color: "var(--ff-text-primary)",
      borderColor: "var(--ff-border)"
    },
    tertiary: {
      backgroundColor: "transparent",
      color: "var(--ff-text-primary)",
      borderColor: "transparent"
    },
    nav: {
      backgroundColor: "var(--ff-white)",
      color: "var(--ff-blue-dark)",
      borderColor: "var(--ff-white)"
    }
  };
  const glyph = icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: size === "small" ? 18 : 24,
    style: {
      flexShrink: 0
    }
  }) : null;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: disabled,
    style: {
      ...base,
      ...variants[variant],
      ...style
    }
  }, rest), iconOnly ? glyph : /*#__PURE__*/React.createElement(React.Fragment, null, iconPosition === "leading" && glyph, children && /*#__PURE__*/React.createElement("span", null, children), iconPosition === "trailing" && glyph));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/buttons/Button.jsx", error: String((e && e.message) || e) }); }

// components/buttons/NavButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * NavButton — the "nav button" family, a thin preset of <Button variant="nav">.
 * See Button for the full prop set (size, icon, iconPosition, iconOnly).
 */
function NavButton(props) {
  return /*#__PURE__*/React.createElement(__ds_scope.Button, _extends({
    variant: "nav"
  }, props));
}
Object.assign(__ds_scope, { NavButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/buttons/NavButton.jsx", error: String((e && e.message) || e) }); }

// components/buttons/PrimaryButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * PrimaryButton — the "primary button" family, a thin preset of <Button variant="primary">.
 * See Button for the full prop set (size, icon, iconPosition, iconOnly).
 */
function PrimaryButton(props) {
  return /*#__PURE__*/React.createElement(__ds_scope.Button, _extends({
    variant: "primary"
  }, props));
}
Object.assign(__ds_scope, { PrimaryButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/buttons/PrimaryButton.jsx", error: String((e && e.message) || e) }); }

// components/buttons/SecondaryButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * SecondaryButton — the "secondary button" family, a thin preset of <Button variant="secondary">.
 * See Button for the full prop set (size, icon, iconPosition, iconOnly).
 */
function SecondaryButton(props) {
  return /*#__PURE__*/React.createElement(__ds_scope.Button, _extends({
    variant: "secondary"
  }, props));
}
Object.assign(__ds_scope, { SecondaryButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/buttons/SecondaryButton.jsx", error: String((e && e.message) || e) }); }

// components/buttons/TertiaryButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * TertiaryButton — the "tertiary button" family, a thin preset of <Button variant="tertiary">.
 * See Button for the full prop set (size, icon, iconPosition, iconOnly).
 */
function TertiaryButton(props) {
  return /*#__PURE__*/React.createElement(__ds_scope.Button, _extends({
    variant: "tertiary"
  }, props));
}
Object.assign(__ds_scope, { TertiaryButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/buttons/TertiaryButton.jsx", error: String((e && e.message) || e) }); }

// components/content/Accordion.jsx
try { (() => {
/**
 * Accordion — divider-separated expandable rows. Header is 16px Lato Bold
 * with a chevron that rotates when open. Rows are padded 16px vertically.
 */
function Accordion({
  items = [],
  style = {}
}) {
  const [open, setOpen] = React.useState(items.findIndex(i => i.defaultOpen));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--ff-font)",
      ...style
    }
  }, items.map((item, i) => {
    const isOpen = open === i;
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        borderBottom: "1px solid var(--ff-border)"
      }
    }, /*#__PURE__*/React.createElement("button", {
      type: "button",
      onClick: () => setOpen(isOpen ? -1 : i),
      style: {
        width: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: "16px",
        padding: "16px 0",
        border: "none",
        background: "transparent",
        cursor: "pointer",
        textAlign: "left",
        fontSize: "16px",
        fontWeight: "var(--ff-weight-bold)",
        color: "var(--ff-text-primary)",
        fontFamily: "var(--ff-font)"
      }
    }, /*#__PURE__*/React.createElement("span", null, item.title), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: "IconChevronDownSize1rem",
      size: 20,
      style: {
        transition: "transform .2s ease",
        transform: isOpen ? "rotate(180deg)" : "none",
        color: "var(--ff-text-secondary)",
        flexShrink: 0
      }
    })), isOpen && /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "0 0 16px",
        fontSize: "16px",
        lineHeight: 1.5,
        color: "var(--ff-text-secondary)"
      }
    }, item.content));
  }));
}
Object.assign(__ds_scope, { Accordion });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Accordion.jsx", error: String((e && e.message) || e) }); }

// components/content/Avatar.jsx
try { (() => {
/**
 * Avatar — circular user/coach image or initials. Two sizes from the Figma
 * set (small 32, regular 40). Optional white ring (used on stacked coach rows).
 */
function Avatar({
  src,
  name = "",
  size = "regular",
  ring = false,
  style = {}
}) {
  const px = typeof size === "number" ? size : size === "small" ? 32 : 40;
  const initials = name.split(" ").map(w => w[0]).filter(Boolean).slice(0, 2).join("").toUpperCase();
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: `${px}px`,
      height: `${px}px`,
      borderRadius: "50%",
      overflow: "hidden",
      flexShrink: 0,
      backgroundColor: "var(--ff-navy)",
      color: "var(--ff-white)",
      fontFamily: "var(--ff-font)",
      fontWeight: "var(--ff-weight-bold)",
      fontSize: `${Math.round(px * 0.36)}px`,
      border: ring ? "2px solid var(--ff-white)" : "none",
      boxShadow: ring ? "0 0 0 1px var(--ff-border)" : "none",
      ...style
    }
  }, src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover"
    }
  }) : initials);
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/content/Chip.jsx
try { (() => {
/**
 * Chip — filter / selectable pill. Default: white fill, ink label.
 * Selected: navy #063853 fill, white label. 16px Lato. Padding 4px 8px.
 */
function Chip({
  children,
  selected = false,
  onClick,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClick,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "4px",
      padding: "6px 14px",
      border: selected ? "1px solid var(--ff-navy)" : "1px solid var(--ff-border)",
      borderRadius: "var(--ff-radius-pill)",
      backgroundColor: selected ? "var(--ff-navy)" : "var(--ff-white)",
      color: selected ? "var(--ff-white)" : "var(--ff-text-primary)",
      fontFamily: "var(--ff-font)",
      fontSize: "16px",
      fontWeight: "var(--ff-weight-bold)",
      lineHeight: 1.2,
      cursor: "pointer",
      whiteSpace: "nowrap",
      transition: "background-color .15s ease, color .15s ease, border-color .15s ease",
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Chip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Chip.jsx", error: String((e && e.message) || e) }); }

// components/content/ChipStructure.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Chip structure — the base pill shell that `Chip` and `ContentChips` are
 * built on (Figma "chip structure"). A rounded-pill flex row with slots for a
 * leading icon, a label, and a trailing element. Use it to compose custom
 * chips; reach for `Chip` / `ContentChips` for the standard ones.
 */
function ChipStructure({
  children,
  leading,
  trailing,
  bg = "var(--ff-white)",
  color = "var(--ff-text-primary)",
  border,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "4px",
      padding: "4px 8px",
      borderRadius: "var(--ff-radius-pill)",
      background: bg,
      color,
      border: border || "1px solid transparent",
      fontFamily: "var(--ff-font)",
      fontSize: "16px",
      fontWeight: "var(--ff-weight-bold)",
      lineHeight: 1.2,
      whiteSpace: "nowrap",
      ...style
    }
  }, rest), leading, children, trailing);
}
Object.assign(__ds_scope, { ChipStructure });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/ChipStructure.jsx", error: String((e && e.message) || e) }); }

// components/content/ContentChips.jsx
try { (() => {
/**
 * Category chip — content-type pill with a tinted fill matching the FF
 * content taxonomy. Each category maps to a surface tint + icon from the
 * Figma "content chips" set.
 */
const CATEGORIES = {
  articles: {
    label: "Articles",
    bg: "var(--ff-cat-articles)",
    icon: "IconArticles"
  },
  "bite-sized": {
    label: "Bite-Sized",
    bg: "var(--ff-cat-bite-sized)",
    icon: "IconBiteSize"
  },
  calculators: {
    label: "Calculators",
    bg: "var(--ff-cat-calculators)",
    icon: "IconCalculator"
  },
  expert: {
    label: "Expert Insights",
    bg: "var(--ff-cat-expert)",
    icon: "IconChatBubble"
  },
  infographics: {
    label: "Infographics",
    bg: "var(--ff-cat-infographics)",
    icon: "IconInfographic"
  },
  "life-events": {
    label: "Life Events",
    bg: "var(--ff-cat-life-events)",
    icon: "IconLifeEventsProperty1DefaultSize1rem"
  },
  videos: {
    label: "Videos",
    bg: "var(--ff-cat-videos)",
    icon: "IconVideos"
  }
};
function ContentChips({
  category = "articles",
  label,
  style = {}
}) {
  const c = ContentChips.categories[category] || ContentChips.categories.articles;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "6px",
      padding: "6px 12px",
      borderRadius: "var(--ff-radius-pill)",
      backgroundColor: c.bg,
      color: "var(--ff-text-primary)",
      fontFamily: "var(--ff-font)",
      fontWeight: "var(--ff-weight-bold)",
      fontSize: "13px",
      lineHeight: 1.2,
      whiteSpace: "nowrap",
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: c.icon,
    size: 16
  }), label || c.label);
}

// Content-taxonomy tint/icon map — exposed as a static, not a bundle component.
ContentChips.categories = CATEGORIES;
Object.assign(__ds_scope, { ContentChips });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/ContentChips.jsx", error: String((e && e.message) || e) }); }

// components/content/ContentTags.jsx
try { (() => {
/**
 * Content tags — the tag-shaped (vs chip-shaped) content-type label from the
 * Figma "content tags" set. Same taxonomy tint + icon as `ContentChips`, at
 * tag scale (12px). Use in dense lists and card footers.
 */
function ContentTags({
  category = "articles",
  label,
  style = {}
}) {
  const c = __ds_scope.ContentChips.categories[category] || __ds_scope.ContentChips.categories.articles;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "4px",
      padding: "4px 8px",
      borderRadius: "var(--ff-radius-pill)",
      background: c.bg,
      color: "var(--ff-text-primary)",
      fontFamily: "var(--ff-font)",
      fontWeight: "var(--ff-weight-bold)",
      fontSize: "12px",
      lineHeight: 1.2,
      whiteSpace: "nowrap",
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: c.icon,
    size: 14
  }), label || c.label);
}
Object.assign(__ds_scope, { ContentTags });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/ContentTags.jsx", error: String((e && e.message) || e) }); }

// components/content/ImagePlaceholder.jsx
try { (() => {
/**
 * Image placeholder — the Figma "image" component: a neutral fill box with a
 * chosen aspect ratio and radius, standing in for photography until real
 * imagery is dropped in. Matches the source placeholder fill rgb(217,217,217).
 */
function ImagePlaceholder({
  ratio = "16/10",
  radius = "var(--ff-radius-md)",
  src,
  alt = "",
  icon = "IconInfographic",
  width = "100%",
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: typeof width === "number" ? `${width}px` : width,
      aspectRatio: ratio.replace("/", " / "),
      borderRadius: radius,
      overflow: "hidden",
      background: "rgb(217,217,217)",
      border: "1px solid var(--ff-border)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: "var(--ff-white)",
      ...style
    }
  }, src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: alt,
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover"
    }
  }) : /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 32
  }));
}
Object.assign(__ds_scope, { ImagePlaceholder });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/ImagePlaceholder.jsx", error: String((e && e.message) || e) }); }

// components/content/Tag.jsx
try { (() => {
/**
 * Tag — small pill label. Default is muted #F4F7FE fill / ink text;
 * inverse is deep-blue #00507C fill / white text (e.g. the "FEATURED" flag
 * and "BENEFITS UPDATES" eyebrow). 12px Lato Bold.
 */
function Tag({
  children,
  inverse = false,
  icon,
  uppercase = false,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "4px",
      padding: "4px 8px",
      borderRadius: "var(--ff-radius-pill)",
      backgroundColor: inverse ? "var(--ff-blue-dark)" : "var(--ff-surface-muted)",
      color: inverse ? "var(--ff-white)" : "var(--ff-text-primary)",
      fontFamily: "var(--ff-font)",
      fontWeight: "var(--ff-weight-bold)",
      fontSize: "12px",
      lineHeight: 1.2,
      letterSpacing: uppercase ? ".06em" : 0,
      textTransform: uppercase ? "uppercase" : "none",
      whiteSpace: "nowrap",
      ...style
    }
  }, icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 14
  }), children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Tag.jsx", error: String((e && e.message) || e) }); }

// components/content/ContentThumbnailCard.jsx
try { (() => {
/**
 * Content thumbnail card — the primary content unit across the Hub
 * ("Curated for you", search results). Rounded 16 image with optional
 * FEATURED flag + bookmark, then a white body with title and category chip.
 */
function ContentThumbnailCard({
  title,
  image,
  category,
  featured = false,
  bookmarked = false,
  onBookmark,
  minutes,
  width = 320,
  style = {},
  onClick
}) {
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    style: {
      width: typeof width === "number" ? `${width}px` : width,
      borderRadius: "var(--ff-radius-md)",
      overflow: "hidden",
      border: "1px solid var(--ff-border)",
      backgroundColor: "var(--ff-white)",
      cursor: onClick ? "pointer" : "default",
      display: "flex",
      flexDirection: "column",
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      aspectRatio: "16 / 10",
      backgroundColor: "rgb(217,217,217)"
    }
  }, image && /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: "",
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover",
      display: "block"
    }
  }), featured && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: "16px",
      left: "16px"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Tag, {
    inverse: true,
    uppercase: true
  }, "Featured")), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: e => {
      e.stopPropagation();
      onBookmark && onBookmark(!bookmarked);
    },
    style: {
      position: "absolute",
      top: "12px",
      right: "12px",
      width: "32px",
      height: "32px",
      border: "none",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      background: "transparent",
      cursor: "pointer",
      color: bookmarked ? "var(--ff-navy)" : "var(--ff-white)"
    },
    "aria-label": "Bookmark"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "IconBookmarkDefault",
    size: 24
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "16px",
      display: "flex",
      flexDirection: "column",
      gap: "12px",
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontFamily: "var(--ff-font)",
      fontWeight: "var(--ff-weight-bold)",
      fontSize: featured ? "18px" : "16px",
      lineHeight: 1.36,
      color: "var(--ff-text-primary)"
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      marginTop: "auto"
    }
  }, category && /*#__PURE__*/React.createElement(__ds_scope.ContentChips, {
    category: category
  }), minutes != null && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--ff-font)",
      fontSize: "12px",
      color: "var(--ff-text-secondary)"
    }
  }, minutes, " min"))));
}
Object.assign(__ds_scope, { ContentThumbnailCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/ContentThumbnailCard.jsx", error: String((e && e.message) || e) }); }

// components/content/TagStructure.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Tag structure — the base label shell that `Tag` is built on (Figma "tag
 * strucutre"). A compact rounded-pill flex row with leading/trailing slots and
 * a 12px bold label. Compose custom tags; use `Tag` for the standard ones.
 */
function TagStructure({
  children,
  leading,
  trailing,
  bg = "var(--ff-surface-muted)",
  color = "var(--ff-text-primary)",
  uppercase = false,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "4px",
      padding: "4px 8px",
      borderRadius: "var(--ff-radius-pill)",
      background: bg,
      color,
      fontFamily: "var(--ff-font)",
      fontSize: "12px",
      fontWeight: "var(--ff-weight-bold)",
      lineHeight: 1.2,
      whiteSpace: "nowrap",
      letterSpacing: uppercase ? ".06em" : 0,
      textTransform: uppercase ? "uppercase" : "none",
      ...style
    }
  }, rest), leading, children, trailing);
}
Object.assign(__ds_scope, { TagStructure });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/TagStructure.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Checkbox — 20px rounded square. Checked state fills blue #007CAB with a
 * white check glyph; unchecked is a #D6DCEA outline.
 */
function Checkbox({
  checked = false,
  onChange,
  label,
  disabled = false,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "8px",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.4 : 1,
      fontFamily: "var(--ff-font)",
      fontSize: "14px",
      color: "var(--ff-text-primary)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    onClick: () => !disabled && onChange && onChange(!checked),
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: "20px",
      height: "20px",
      borderRadius: "4px",
      border: checked ? "1px solid var(--ff-blue)" : "1px solid var(--ff-border)",
      backgroundColor: checked ? "var(--ff-blue)" : "var(--ff-white)",
      color: "var(--ff-white)",
      flexShrink: 0,
      transition: "background-color .12s ease, border-color .12s ease"
    }
  }, checked && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "IconCheck",
    size: 14
  })), label && /*#__PURE__*/React.createElement("span", null, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Text input — white pill field, 1px #D6DCEA border, optional leading icon
 * and trailing action button. Placeholder is Lato 14 / #565656.
 */
function Input({
  icon,
  button,
  onButtonClick,
  style = {},
  containerStyle = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "16px",
      padding: "8px 8px 8px 16px",
      backgroundColor: "var(--ff-white)",
      border: "1px solid var(--ff-border)",
      borderRadius: "var(--ff-radius-lg)",
      ...containerStyle
    }
  }, icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 24,
    style: {
      color: "var(--ff-text-secondary)",
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("input", _extends({
    style: {
      flex: 1,
      minWidth: 0,
      border: "none",
      outline: "none",
      background: "transparent",
      fontFamily: "var(--ff-font)",
      fontSize: "14px",
      color: "var(--ff-text-primary)",
      ...style
    }
  }, rest)), button && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onButtonClick,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: "40px",
      height: "40px",
      border: "none",
      borderRadius: "50%",
      backgroundColor: "var(--ff-blue)",
      color: "var(--ff-white)",
      cursor: "pointer",
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: typeof button === "string" ? button : "IconArrowRightSize1rem",
    size: 22
  })));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Toggle.jsx
try { (() => {
/**
 * Toggle switch — 32×20 track. Off: #D6DCEA track / dark knob. On: #007CAB
 * track / white knob. Knob is a 12px circle.
 */
function Toggle({
  on = false,
  onChange,
  disabled = false,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    role: "switch",
    "aria-checked": on,
    disabled: disabled,
    onClick: () => !disabled && onChange && onChange(!on),
    style: {
      display: "inline-flex",
      alignItems: "center",
      width: "32px",
      height: "20px",
      padding: "0 4px",
      border: "none",
      borderRadius: "16px",
      backgroundColor: on ? "var(--ff-blue)" : "var(--ff-border)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.4 : 1,
      transition: "background-color .18s ease",
      justifyContent: on ? "flex-end" : "flex-start",
      boxSizing: "border-box",
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: "12px",
      height: "12px",
      borderRadius: "50%",
      backgroundColor: on ? "var(--ff-white)" : "var(--ff-ink)",
      transition: "background-color .18s ease"
    }
  }));
}
Object.assign(__ds_scope, { Toggle });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Toggle.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconAimee.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconAimee — named wrapper around the shared FF icon set (glyph "IconAimeeProperty11rem").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconAimee({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconAimeeProperty11rem",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconAimee });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconAimee.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconAlarm.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconAlarm — named wrapper around the shared FF icon set (glyph "IconAlarm").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconAlarm({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconAlarm",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconAlarm });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconAlarm.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconArrowDown.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconArrowDown — named wrapper around the shared FF icon set (glyph "IconArrowDownSize1rem").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconArrowDown({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconArrowDownSize1rem",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconArrowDown });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconArrowDown.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconArrowLeft.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconArrowLeft — named wrapper around the shared FF icon set (glyph "IconArrowLeft").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconArrowLeft({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconArrowLeft",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconArrowLeft });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconArrowLeft.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconArrowRight.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconArrowRight — named wrapper around the shared FF icon set (glyph "IconArrowRightSize1rem").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconArrowRight({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconArrowRightSize1rem",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconArrowRight });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconArrowRight.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconArrowUp.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconArrowUp — named wrapper around the shared FF icon set (glyph "IconArrowUp").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconArrowUp({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconArrowUp",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconArrowUp });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconArrowUp.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconArticles.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconArticles — named wrapper around the shared FF icon set (glyph "IconArticles").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconArticles({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconArticles",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconArticles });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconArticles.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconBiteSize.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconBiteSize — named wrapper around the shared FF icon set (glyph "IconBiteSize").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconBiteSize({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconBiteSize",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconBiteSize });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconBiteSize.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconBook.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconBook — named wrapper around the shared FF icon set (glyph "IconBookProperty1DefaultSize1rem").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconBook({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconBookProperty1DefaultSize1rem",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconBook });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconBook.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconBookmark.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconBookmark — named wrapper around the shared FF icon set (glyph "IconBookmarkDefault").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconBookmark({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconBookmarkDefault",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconBookmark });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconBookmark.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconBulb.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconBulb — named wrapper around the shared FF icon set (glyph "IconBulb").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconBulb({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconBulb",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconBulb });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconBulb.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconCalculator.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconCalculator — named wrapper around the shared FF icon set (glyph "IconCalculator").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconCalculator({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconCalculator",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconCalculator });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconCalculator.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconCalendar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconCalendar — named wrapper around the shared FF icon set (glyph "IconCalendarProperty1DefaultSize1rem").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconCalendar({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconCalendarProperty1DefaultSize1rem",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconCalendar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconCalendar.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconCalendarCheck.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconCalendarCheck — named wrapper around the shared FF icon set (glyph "IconCalendarCheck").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconCalendarCheck({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconCalendarCheck",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconCalendarCheck });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconCalendarCheck.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconCall.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconCall — named wrapper around the shared FF icon set (glyph "IconCall").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconCall({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconCall",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconCall });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconCall.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconChatBubble.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconChatBubble — named wrapper around the shared FF icon set (glyph "IconChatBubble").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconChatBubble({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconChatBubble",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconChatBubble });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconChatBubble.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconCheck.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconCheck — named wrapper around the shared FF icon set (glyph "IconCheck").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconCheck({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconCheck",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconCheck });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconCheck.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconChevronDown.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconChevronDown — named wrapper around the shared FF icon set (glyph "IconChevronDownSize1rem").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconChevronDown({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconChevronDownSize1rem",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconChevronDown });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconChevronDown.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconChevronLeft.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconChevronLeft — named wrapper around the shared FF icon set (glyph "IconChevronLeftSize1rem").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconChevronLeft({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconChevronLeftSize1rem",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconChevronLeft });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconChevronLeft.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconChevronRight.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconChevronRight — named wrapper around the shared FF icon set (glyph "IconChevronRightSize1rem").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconChevronRight({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconChevronRightSize1rem",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconChevronRight });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconChevronRight.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconChevronUp.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconChevronUp — named wrapper around the shared FF icon set (glyph "IconChevronUpSize1rem").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconChevronUp({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconChevronUpSize1rem",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconChevronUp });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconChevronUp.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconChipPlaceholder.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconChipPlaceholder — named wrapper around the shared FF icon set (glyph "IconInfographic").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconChipPlaceholder({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconInfographic",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconChipPlaceholder });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconChipPlaceholder.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconClipboard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconClipboard — named wrapper around the shared FF icon set (glyph "IconClipboardProperty1DefaultSize1rem").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconClipboard({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconClipboardProperty1DefaultSize1rem",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconClipboard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconClipboard.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconClose.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconClose — named wrapper around the shared FF icon set (glyph "IconCloseSize1rem").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconClose({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconCloseSize1rem",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconClose });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconClose.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconCopy.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconCopy — named wrapper around the shared FF icon set (glyph "IconCopy").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconCopy({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconCopy",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconCopy });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconCopy.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconEdit.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconEdit — named wrapper around the shared FF icon set (glyph "IconEdit").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconEdit({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconEdit",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconEdit });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconEdit.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconExpand.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconExpand — named wrapper around the shared FF icon set (glyph "IconExpand").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconExpand({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconExpand",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconExpand });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconExpand.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconFilter.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconFilter — named wrapper around the shared FF icon set (glyph "IconFilter").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconFilter({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconFilter",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconFilter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconFilter.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconHelp.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconHelp — named wrapper around the shared FF icon set (glyph "IconHelp").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconHelp({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconHelp",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconHelp });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconHelp.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconHome.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconHome — named wrapper around the shared FF icon set (glyph "IconHomeStateHomeSize1rem").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconHome({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconHomeStateHomeSize1rem",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconHome });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconHome.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconInfo.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconInfo — named wrapper around the shared FF icon set (glyph "IconInfo").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconInfo({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconInfo",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconInfo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconInfo.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconInfographic.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconInfographic — named wrapper around the shared FF icon set (glyph "IconInfographic").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconInfographic({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconInfographic",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconInfographic });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconInfographic.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconLifeEvents.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconLifeEvents — named wrapper around the shared FF icon set (glyph "IconLifeEventsProperty1DefaultSize1rem").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconLifeEvents({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconLifeEventsProperty1DefaultSize1rem",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconLifeEvents });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconLifeEvents.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconLogOut.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconLogOut — named wrapper around the shared FF icon set (glyph "IconLogOut").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconLogOut({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconLogOut",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconLogOut });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconLogOut.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconMenu.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconMenu — named wrapper around the shared FF icon set (glyph "IconMenu").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconMenu({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconMenu",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconMenu });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconMenu.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconMenuDots.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconMenuDots — named wrapper around the shared FF icon set (glyph "IconMenuDots").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconMenuDots({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconMenuDots",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconMenuDots });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconMenuDots.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconMenuOpen.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconMenuOpen — named wrapper around the shared FF icon set (glyph "IconMenuOpen").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconMenuOpen({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconMenuOpen",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconMenuOpen });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconMenuOpen.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconNotification.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconNotification — named wrapper around the shared FF icon set (glyph "IconNotificationProperty1Bell").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconNotification({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconNotificationProperty1Bell",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconNotification });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconNotification.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconPlus.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconPlus — named wrapper around the shared FF icon set (glyph "IconPlusProperty1Plus").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconPlus({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconPlusProperty1Plus",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconPlus });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconPlus.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconReset.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconReset — named wrapper around the shared FF icon set (glyph "IconResetProperty1Reset").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconReset({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconResetProperty1Reset",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconReset });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconReset.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconSearch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconSearch — named wrapper around the shared FF icon set (glyph "IconSearch").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconSearch({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconSearch",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconSearch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconSearch.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconShare.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconShare — named wrapper around the shared FF icon set (glyph "IconShare").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconShare({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconShare",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconShare });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconShare.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconShow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconShow — named wrapper around the shared FF icon set (glyph "IconShow").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconShow({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconShow",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconShow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconShow.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconStars.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconStars — named wrapper around the shared FF icon set (glyph "IconStars").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconStars({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconStars",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconStars });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconStars.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconUser.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconUser — named wrapper around the shared FF icon set (glyph "IconUser").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconUser({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconUser",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconUser });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconUser.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconVideos.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconVideos — named wrapper around the shared FF icon set (glyph "IconVideos").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconVideos({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconVideos",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconVideos });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconVideos.jsx", error: String((e && e.message) || e) }); }

// components/glyphs/IconWorld.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconWorld — named wrapper around the shared FF icon set (glyph "IconWorld").
 * Renders with currentColor; set CSS `color` to recolor, `size` to resize.
 */
function IconWorld({
  size = 24,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Icon, _extends({
    name: "IconWorld",
    size: size
  }, rest));
}
Object.assign(__ds_scope, { IconWorld });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glyphs/IconWorld.jsx", error: String((e && e.message) || e) }); }

// components/hub/Aimee.jsx
try { (() => {
/**
 * Aimee — the assistant's presence avatar (Figma "Aimee", state: 3). A white
 * circle with a blue ring and the Aimee glyph; the state ring communicates
 * availability: idle (steady blue ring), listening (blue fill), thinking
 * (animated pulse). Pair with `AimeeLauncher` for a floating entry point.
 */
function Aimee({
  state = "idle",
  size = 48,
  style = {}
}) {
  const listening = state === "listening";
  const thinking = state === "thinking";
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: `${size}px`,
      height: `${size}px`,
      borderRadius: "50%",
      background: listening ? "var(--ff-blue)" : "var(--ff-white)",
      border: "2px solid var(--ff-blue)",
      color: listening ? "var(--ff-white)" : "var(--ff-blue)",
      boxShadow: "var(--ff-shadow-card)",
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "IconAimeeProperty11rem",
    size: Math.round(size * 0.5)
  }), thinking && /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      inset: -2,
      borderRadius: "50%",
      border: "2px solid var(--ff-blue)",
      opacity: 0.5,
      animation: "ff-aimee-pulse 1.4s ease-out infinite"
    }
  }), /*#__PURE__*/React.createElement("style", {
    dangerouslySetInnerHTML: {
      __html: "@keyframes ff-aimee-pulse{0%{transform:scale(1);opacity:.5}100%{transform:scale(1.35);opacity:0}}"
    }
  }));
}
Object.assign(__ds_scope, { Aimee });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hub/Aimee.jsx", error: String((e && e.message) || e) }); }

// components/hub/AimeeWidget.jsx
try { (() => {
/**
 * Aimee — the Hub's AI financial guide. A white chat panel with a header
 * ("Aimee" wordmark + blue "AI" badge, menu / expand / minimize controls), a
 * centred greeting, optional quick-reply pills, a pill composer, and the
 * standing "Aimee can get things wrong" disclaimer.
 */
function AimeeWidget({
  userName = "Josh",
  greeting,
  children,
  onSend,
  onExpand,
  onMinimize,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      width: "380px",
      height: "560px",
      background: "var(--ff-white)",
      border: "1px solid var(--ff-border)",
      borderRadius: "var(--ff-radius-md)",
      overflow: "hidden",
      boxShadow: "var(--ff-shadow-card)",
      fontFamily: "var(--ff-font)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "16px 20px"
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Menu",
    style: iconBtn
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "IconMenu",
    size: 22
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "8px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "24px",
      fontWeight: "var(--ff-weight-black)",
      color: "var(--ff-text-primary)"
    }
  }, "Aimee"), /*#__PURE__*/React.createElement("span", {
    style: {
      background: "var(--ff-blue)",
      color: "var(--ff-white)",
      fontSize: "14px",
      fontWeight: "var(--ff-weight-bold)",
      padding: "2px 8px",
      borderRadius: "6px"
    }
  }, "AI")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "12px"
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Expand",
    onClick: onExpand,
    style: iconBtn
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "IconExpand",
    size: 20
  })), /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Minimize",
    onClick: onMinimize,
    style: iconBtn
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 16,
      height: 2,
      background: "var(--ff-ink)",
      display: "block"
    }
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      alignItems: "center",
      gap: "16px",
      padding: "20px",
      textAlign: "center"
    }
  }, children ? children : /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: "20px",
      lineHeight: 1.35,
      fontWeight: "var(--ff-weight-bold)",
      color: "var(--ff-blue-dark)"
    }
  }, greeting || /*#__PURE__*/React.createElement(React.Fragment, null, "Hi, ", userName, ".", /*#__PURE__*/React.createElement("br", null), "What can I help you with today?"))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "12px 16px 8px"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Input, {
    placeholder: "Ask Aimee anything",
    button: "IconArrowUp",
    onButtonClick: onSend,
    containerStyle: {
      borderRadius: "var(--ff-radius-md)"
    }
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      padding: "0 16px 14px",
      textAlign: "center",
      fontSize: "12px",
      color: "var(--ff-text-secondary)"
    }
  }, "Aimee can get things wrong. Double check answers."));
}
const iconBtn = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  border: "none",
  background: "transparent",
  cursor: "pointer",
  color: "var(--ff-ink)",
  padding: 0
};

/** Floating launcher button for Aimee (white circle, blue ring, optional unread dot). */
function AimeeLauncher({
  unread = false,
  onClick,
  size = 56,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClick,
    "aria-label": "Open Aimee",
    style: {
      position: "relative",
      width: `${size}px`,
      height: `${size}px`,
      borderRadius: "50%",
      background: "var(--ff-white)",
      border: "2px solid var(--ff-blue)",
      cursor: "pointer",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      boxShadow: "var(--ff-shadow-card)",
      color: "var(--ff-blue)",
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "IconAimeeProperty11rem",
    size: Math.round(size * 0.5)
  }), unread && /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: 0,
      right: 0,
      width: "12px",
      height: "12px",
      borderRadius: "50%",
      background: "var(--ff-accent-red)"
    }
  }));
}
Object.assign(__ds_scope, { AimeeWidget, AimeeLauncher });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hub/AimeeWidget.jsx", error: String((e && e.message) || e) }); }

// components/hub/Beak.jsx
try { (() => {
/**
 * Beak — the small directional triangle used on `Tooltip` (Figma "Beak"). A
 * pure-CSS triangle in navy by default; point it with `direction`.
 */
function Beak({
  direction = "down",
  size = 7,
  color = "var(--ff-navy)",
  style = {}
}) {
  const borders = {
    down: {
      borderWidth: `${size}px ${size}px 0`,
      borderColor: `${color} transparent transparent`
    },
    up: {
      borderWidth: `0 ${size}px ${size}px`,
      borderColor: `transparent transparent ${color}`
    },
    left: {
      borderWidth: `${size}px ${size}px ${size}px 0`,
      borderColor: `transparent ${color} transparent transparent`
    },
    right: {
      borderWidth: `${size}px 0 ${size}px ${size}px`,
      borderColor: `transparent transparent transparent ${color}`
    }
  }[direction];
  return /*#__PURE__*/React.createElement("span", {
    style: {
      width: 0,
      height: 0,
      borderStyle: "solid",
      display: "inline-block",
      ...borders,
      ...style
    }
  });
}
Object.assign(__ds_scope, { Beak });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hub/Beak.jsx", error: String((e && e.message) || e) }); }

// components/hub/BeakWrapper.jsx
try { (() => {
/**
 * Beak wrapper — positions a `Beak` against the edge of a floating surface
 * (Figma "Beak Wrapper"). Absolutely anchors the beak on the chosen side.
 */
function BeakWrapper({
  direction = "down",
  offset = "50%",
  color,
  size,
  style = {}
}) {
  const pos = {
    down: {
      top: "100%",
      left: offset,
      transform: "translateX(-50%)"
    },
    up: {
      bottom: "100%",
      left: offset,
      transform: "translateX(-50%)"
    },
    left: {
      right: "100%",
      top: offset,
      transform: "translateY(-50%)"
    },
    right: {
      left: "100%",
      top: offset,
      transform: "translateY(-50%)"
    }
  }[direction];
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      ...pos,
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Beak, {
    direction: direction,
    color: color,
    size: size
  }));
}
Object.assign(__ds_scope, { BeakWrapper });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hub/BeakWrapper.jsx", error: String((e && e.message) || e) }); }

// components/hub/Benefit.jsx
try { (() => {
/**
 * Benefit — a linked employee-benefit tile: icon in a tinted rounded square,
 * a bold label, short description, and a trailing chevron.
 */
function Benefit({
  icon = "IconWorld",
  title,
  detail,
  tint = "var(--ff-cat-bite-sized)",
  onClick,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClick,
    style: {
      width: "100%",
      display: "flex",
      gap: "16px",
      alignItems: "center",
      padding: "16px",
      border: "1px solid var(--ff-border)",
      borderRadius: "var(--ff-radius-md)",
      background: "var(--ff-white)",
      cursor: "pointer",
      textAlign: "left",
      fontFamily: "var(--ff-font)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: "48px",
      height: "48px",
      flexShrink: 0,
      borderRadius: "12px",
      background: tint,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      color: "var(--ff-navy)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 24
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      display: "flex",
      flexDirection: "column",
      gap: "2px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "16px",
      fontWeight: "var(--ff-weight-bold)",
      color: "var(--ff-text-primary)"
    }
  }, title), detail && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "14px",
      color: "var(--ff-text-secondary)",
      lineHeight: 1.4
    }
  }, detail)), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "IconChevronRightSize1rem",
    size: 20,
    style: {
      color: "var(--ff-text-secondary)",
      flexShrink: 0
    }
  }));
}
Object.assign(__ds_scope, { Benefit });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hub/Benefit.jsx", error: String((e && e.message) || e) }); }

// components/hub/ChatQuickReply.jsx
try { (() => {
/**
 * Chat quick reply — a suggested response pill in the Aimee chat.
 * Default: white fill, 1px border. Selected: deep-blue #00507C fill, white
 * text. Padding 16×32, 16px Lato.
 */
function ChatQuickReply({
  children,
  selected = false,
  onClick,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClick,
    style: {
      padding: "12px 24px",
      borderRadius: "var(--ff-radius-pill)",
      border: selected ? "1px solid var(--ff-blue-dark)" : "1px solid var(--ff-border)",
      backgroundColor: selected ? "var(--ff-blue-dark)" : "var(--ff-white)",
      color: selected ? "var(--ff-white)" : "var(--ff-text-primary)",
      fontFamily: "var(--ff-font)",
      fontSize: "16px",
      fontWeight: "var(--ff-weight-bold)",
      cursor: "pointer",
      whiteSpace: "nowrap",
      transition: "background-color .15s ease, color .15s ease, border-color .15s ease",
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { ChatQuickReply });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hub/ChatQuickReply.jsx", error: String((e && e.message) || e) }); }

// components/hub/EventsCards.jsx
try { (() => {
/**
 * Event card — a webinar / live-event listing. Two layouts:
 *  - "card" (default): rounded-16 image header (optional FEATURED flag) over a
 *    white body with title and icon meta rows (type · date · time).
 *  - "compact": a horizontal row with a DEC/20 date block, title, and meta.
 */
function EventsCards({
  title,
  type = "Webinar",
  date,
  time,
  image,
  featured = false,
  layout = "card",
  width,
  onClick,
  style = {}
}) {
  const meta = /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "6px",
      color: "var(--ff-text-secondary)",
      fontSize: "14px"
    }
  }, type && /*#__PURE__*/React.createElement("span", {
    style: metaRow
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "IconStars",
    size: 18
  }), type), date && layout === "card" && /*#__PURE__*/React.createElement("span", {
    style: metaRow
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "IconCalendarCheck",
    size: 18
  }), date), time && /*#__PURE__*/React.createElement("span", {
    style: metaRow
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "IconAlarm",
    size: 18
  }), time));
  if (layout === "compact") {
    const [mon, day] = splitDate(date);
    return /*#__PURE__*/React.createElement("button", {
      type: "button",
      onClick: onClick,
      style: {
        width: width || "100%",
        display: "flex",
        gap: "16px",
        alignItems: "center",
        padding: "16px",
        border: "1px solid var(--ff-border)",
        borderRadius: "var(--ff-radius-md)",
        background: "var(--ff-white)",
        cursor: "pointer",
        textAlign: "left",
        fontFamily: "var(--ff-font)",
        ...style
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        flexShrink: 0,
        width: "64px",
        height: "64px",
        borderRadius: "8px",
        border: "1px solid var(--ff-border)",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        background: "var(--ff-surface-muted)"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: "11px",
        fontWeight: "var(--ff-weight-bold)",
        letterSpacing: ".08em",
        color: "var(--ff-ink-soft)",
        textTransform: "uppercase"
      }
    }, mon), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: "24px",
        fontWeight: "var(--ff-weight-black)",
        color: "var(--ff-ink)",
        lineHeight: 1
      }
    }, day)), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        display: "flex",
        flexDirection: "column",
        gap: "8px"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: "18px",
        fontWeight: "var(--ff-weight-bold)",
        color: "var(--ff-ink)"
      }
    }, title), meta));
  }
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    style: {
      width: width || "280px",
      borderRadius: "var(--ff-radius-md)",
      overflow: "hidden",
      border: "1px solid var(--ff-border)",
      background: "var(--ff-white)",
      cursor: onClick ? "pointer" : "default",
      fontFamily: "var(--ff-font)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      aspectRatio: "16 / 9",
      background: "rgb(168,168,168)"
    }
  }, image && /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: "",
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover",
      display: "block"
    }
  }), featured && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: "16px",
      left: "16px"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Tag, {
    inverse: true,
    uppercase: true
  }, "Featured"))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "16px",
      display: "flex",
      flexDirection: "column",
      gap: "12px"
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontSize: "18px",
      fontWeight: "var(--ff-weight-bold)",
      color: "var(--ff-ink)",
      lineHeight: 1.3
    }
  }, title), meta));
}
const metaRow = {
  display: "flex",
  alignItems: "center",
  gap: "8px"
};
function splitDate(d) {
  if (!d) return ["", ""];
  const m = String(d).match(/([A-Za-z]{3,})\.?\s*(\d{1,2})/);
  if (m) return [m[1].slice(0, 3).toUpperCase(), m[2]];
  return ["", d];
}
Object.assign(__ds_scope, { EventsCards });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hub/EventsCards.jsx", error: String((e && e.message) || e) }); }

// components/hub/HomeSummaryCard.jsx
try { (() => {
/**
 * Home summary card — the "Your Progress" / "My financial wellness score"
 * panel from the left rail. A navy LEVEL pill, a bold title, body copy, and a
 * "See your score" text link with a bordered chevron.
 */
function HomeSummaryCard({
  level = 5,
  title,
  body,
  linkLabel = "See your score",
  onLink,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--ff-white)",
      border: "1px solid var(--ff-border)",
      borderRadius: "var(--ff-radius-md)",
      boxShadow: "var(--ff-shadow-card)",
      padding: "24px",
      display: "flex",
      flexDirection: "column",
      gap: "16px",
      fontFamily: "var(--ff-font)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      alignSelf: "flex-start",
      background: "var(--ff-navy)",
      color: "var(--ff-white)",
      fontSize: "13px",
      fontWeight: "var(--ff-weight-bold)",
      padding: "6px 16px",
      borderRadius: "var(--ff-radius-pill)",
      letterSpacing: ".04em",
      textTransform: "uppercase"
    }
  }, "Level ", level), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontSize: "22px",
      fontWeight: "var(--ff-weight-bold)",
      color: "var(--ff-ink)",
      lineHeight: 1.25
    }
  }, title), body && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: "16px",
      lineHeight: 1.5,
      color: "var(--ff-ink-soft)"
    }
  }, body), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onLink,
    style: {
      alignSelf: "flex-start",
      display: "inline-flex",
      alignItems: "center",
      gap: "10px",
      border: "none",
      background: "transparent",
      cursor: "pointer",
      padding: 0,
      fontFamily: "var(--ff-font)",
      fontSize: "16px",
      fontWeight: "var(--ff-weight-bold)",
      color: "var(--ff-ink)"
    }
  }, linkLabel, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: "28px",
      height: "28px",
      border: "1px solid var(--ff-border)",
      borderRadius: "6px",
      color: "var(--ff-ink)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "IconChevronRightSize1rem",
    size: 18
  }))));
}
Object.assign(__ds_scope, { HomeSummaryCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hub/HomeSummaryCard.jsx", error: String((e && e.message) || e) }); }

// components/hub/LifeEventCard.jsx
try { (() => {
/**
 * Life event card — entry point to a guided life-event journey (New Job,
 * Baby, Buying a Home…). Rounded-16 image/illustration header over a white
 * body with a 16px bold label and chevron.
 */
function LifeEventCard({
  label,
  image,
  icon = "IconLifeEventsProperty1DefaultSize1rem",
  width = 240,
  onClick,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClick,
    style: {
      width: typeof width === "number" ? `${width}px` : width,
      padding: 0,
      border: "1px solid var(--ff-border)",
      borderRadius: "var(--ff-radius-md)",
      overflow: "hidden",
      background: "var(--ff-white)",
      cursor: "pointer",
      textAlign: "left",
      fontFamily: "var(--ff-font)",
      display: "flex",
      flexDirection: "column",
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      aspectRatio: "16 / 9",
      backgroundColor: "var(--ff-cat-life-events)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: "var(--ff-accent-orange)"
    }
  }, image ? /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: "",
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover"
    }
  }) : /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 40
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "16px",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: "8px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "16px",
      fontWeight: "var(--ff-weight-bold)",
      color: "var(--ff-text-primary)"
    }
  }, label), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "IconChevronRightSize1rem",
    size: 20,
    style: {
      color: "var(--ff-text-secondary)"
    }
  })));
}
Object.assign(__ds_scope, { LifeEventCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hub/LifeEventCard.jsx", error: String((e && e.message) || e) }); }

// components/hub/MilestoneBadge.jsx
try { (() => {
/**
 * Milestone badge — gamification tile (64px rounded square, radius 10).
 * Locked: flat #D6DCEA. Unlocked: white tile with a 2px green #8BC35F ring
 * and a coloured glyph. (Source badges use bespoke illustrations; this
 * substitutes an icon glyph — swap in artwork via the `art` prop.)
 */
function MilestoneBadge({
  icon = "IconStars",
  locked = false,
  size = 64,
  art,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: `${size}px`,
      height: `${size}px`,
      borderRadius: "10px",
      backgroundColor: locked ? "var(--ff-border)" : "var(--ff-white)",
      boxShadow: locked ? "inset 0 0 0 3px var(--ff-border)" : "inset 0 0 0 2px var(--ff-accent-green)",
      color: locked ? "var(--ff-grey-3)" : "var(--ff-accent-orange)",
      ...style
    }
  }, art ? art : /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: Math.round(size * 0.5)
  }));
}
Object.assign(__ds_scope, { MilestoneBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hub/MilestoneBadge.jsx", error: String((e && e.message) || e) }); }

// components/hub/BadgeCard.jsx
try { (() => {
/**
 * Badge card — an achievement/milestone card: a MilestoneBadge tile beside a
 * bold title and supporting copy. Optional "level tag" pill.
 */
function BadgeCard({
  icon = "IconStars",
  locked = false,
  title,
  detail,
  levelTag,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "16px",
      alignItems: "center",
      padding: "16px",
      border: "1px solid var(--ff-border)",
      borderRadius: "var(--ff-radius-md)",
      background: "var(--ff-white)",
      fontFamily: "var(--ff-font)",
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.MilestoneBadge, {
    icon: icon,
    locked: locked,
    size: 64
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: "flex",
      flexDirection: "column",
      gap: "4px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "8px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "16px",
      fontWeight: "var(--ff-weight-bold)",
      color: "var(--ff-text-primary)"
    }
  }, title), levelTag && /*#__PURE__*/React.createElement("span", {
    style: {
      background: "var(--ff-navy)",
      color: "var(--ff-white)",
      fontSize: "11px",
      fontWeight: "var(--ff-weight-bold)",
      padding: "2px 8px",
      borderRadius: "var(--ff-radius-pill)",
      letterSpacing: ".04em",
      textTransform: "uppercase"
    }
  }, levelTag)), detail && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "14px",
      color: "var(--ff-text-secondary)",
      lineHeight: 1.4
    }
  }, detail)));
}
Object.assign(__ds_scope, { BadgeCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hub/BadgeCard.jsx", error: String((e && e.message) || e) }); }

// components/hub/MyFinancialWellnessScore.jsx
try { (() => {
/**
 * My financial wellness score — the score panel from the Hub (Figma "My
 * financial wellness score"). An eyebrow + "ABOUT MY SCORE" link above a
 * bordered score card: a large N/10 value, a level Tag, the current level
 * title, a divider, and a "HOW DO I COMPARE?" link.
 * Values copied verbatim: eyebrow 14/700 (+.02em), score 48/700, links 12/700
 * deep-blue, card radius 16, fill #F4F7FE, 1px #D6DCEA border.
 */
function MyFinancialWellnessScore({
  score = "5.65/10",
  level = 5,
  levelTitle = "Setting the Stage for Success",
  cardFill = "var(--ff-surface-muted)",
  onAbout,
  onCompare,
  style = {}
}) {
  const link = {
    display: "inline-flex",
    alignItems: "center",
    gap: "4px",
    border: "none",
    background: "transparent",
    cursor: "pointer",
    padding: 0,
    fontFamily: "var(--ff-font)",
    fontSize: "12px",
    fontWeight: "var(--ff-weight-bold)",
    color: "var(--ff-blue-dark)",
    letterSpacing: ".02em"
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "16px",
      alignItems: "flex-start",
      width: "247px",
      fontFamily: "var(--ff-font)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "flex-start",
      gap: "2px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "14px",
      fontWeight: "var(--ff-weight-bold)",
      letterSpacing: ".02em",
      color: "var(--ff-ink)"
    }
  }, "financial wellness score"), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onAbout,
    style: link
  }, "ABOUT MY SCORE ", /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "IconChevronRightSize1rem",
    size: 20,
    style: {
      color: "var(--ff-blue-dark)"
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      alignSelf: "stretch",
      borderRadius: "var(--ff-radius-md)",
      boxShadow: "inset 0 0 0 1px var(--ff-border)",
      background: cardFill,
      padding: "16px 16px 8px",
      display: "flex",
      flexDirection: "column",
      gap: "16px",
      boxSizing: "border-box"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "48px",
      fontWeight: "var(--ff-weight-bold)",
      lineHeight: 1,
      color: "var(--ff-ink)"
    }
  }, score), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "8px"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Tag, null, "Level ", level), levelTitle && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "12px",
      fontWeight: "var(--ff-weight-bold)",
      color: "var(--ff-ink)"
    }
  }, levelTitle)), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: "1px solid var(--ff-border)",
      paddingTop: "8px"
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onCompare,
    style: {
      ...link,
      width: "100%",
      justifyContent: "space-between"
    }
  }, "HOW DO I COMPARE? ", /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "IconChevronRightSize1rem",
    size: 20,
    style: {
      color: "var(--ff-blue-dark)"
    }
  })))));
}
Object.assign(__ds_scope, { MyFinancialWellnessScore });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hub/MyFinancialWellnessScore.jsx", error: String((e && e.message) || e) }); }

// components/hub/Notif.jsx
try { (() => {
/**
 * Notification list item — icon in a tinted circle, title + supporting text,
 * timestamp, and an optional unread dot. Rows stack inside a card.
 */
function Notif({
  icon = "IconBulb",
  title,
  detail,
  time,
  unread = false,
  tint = "var(--ff-cat-bite-sized)",
  onClick,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClick,
    style: {
      width: "100%",
      display: "flex",
      gap: "12px",
      alignItems: "flex-start",
      padding: "16px",
      border: "none",
      borderBottom: "1px solid var(--ff-border)",
      background: unread ? "var(--ff-surface-muted)" : "var(--ff-white)",
      cursor: "pointer",
      textAlign: "left",
      fontFamily: "var(--ff-font)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: "40px",
      height: "40px",
      flexShrink: 0,
      borderRadius: "50%",
      background: tint,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      color: "var(--ff-navy)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 20
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      display: "flex",
      flexDirection: "column",
      gap: "2px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "14px",
      fontWeight: "var(--ff-weight-bold)",
      color: "var(--ff-text-primary)"
    }
  }, title), detail && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "14px",
      color: "var(--ff-text-secondary)",
      lineHeight: 1.4
    }
  }, detail), time && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "12px",
      color: "var(--ff-grey-3)"
    }
  }, time)), unread && /*#__PURE__*/React.createElement("span", {
    style: {
      width: "8px",
      height: "8px",
      borderRadius: "50%",
      background: "var(--ff-blue)",
      marginTop: "6px",
      flexShrink: 0
    }
  }));
}
Object.assign(__ds_scope, { Notif });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hub/Notif.jsx", error: String((e && e.message) || e) }); }

// components/hub/NotifList.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Notif list — the notification list container (Figma "notif list"). Stacks
 * `Notif` rows inside a bordered, rounded card. Pass `items` (array of Notif
 * props) or arbitrary `children`.
 */
function NotifList({
  items,
  children,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      border: "1px solid var(--ff-border)",
      borderRadius: "var(--ff-radius-md)",
      overflow: "hidden",
      background: "var(--ff-white)",
      ...style
    }
  }, items ? items.map((it, i) => /*#__PURE__*/React.createElement(__ds_scope.Notif, _extends({
    key: i
  }, it))) : children);
}
Object.assign(__ds_scope, { NotifList });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hub/NotifList.jsx", error: String((e && e.message) || e) }); }

// components/hub/ProgressLevel.jsx
try { (() => {
/**
 * Progress level — the gamification header from the left rail:
 * "YOUR PROGRESS" label + a navy "LEVEL n" pill + expand chevron, with an
 * optional progress bar toward the next level.
 */
function ProgressLevel({
  level = 5,
  label = "Your Progress",
  progress,
  expanded = false,
  onToggle,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      border: "1px solid var(--ff-border)",
      borderRadius: "var(--ff-radius-md)",
      background: "var(--ff-white)",
      padding: "16px 20px",
      fontFamily: "var(--ff-font)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "12px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontSize: "14px",
      fontWeight: "var(--ff-weight-bold)",
      letterSpacing: ".06em",
      textTransform: "uppercase",
      color: "var(--ff-text-primary)"
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      background: "var(--ff-navy)",
      color: "var(--ff-white)",
      fontSize: "13px",
      fontWeight: "var(--ff-weight-bold)",
      padding: "4px 12px",
      borderRadius: "var(--ff-radius-pill)",
      letterSpacing: ".04em",
      textTransform: "uppercase"
    }
  }, "Level ", level), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onToggle,
    "aria-label": "Toggle",
    style: {
      border: "none",
      background: "transparent",
      cursor: "pointer",
      color: "var(--ff-text-secondary)",
      display: "inline-flex"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "IconChevronDownSize1rem",
    size: 20,
    style: {
      transform: expanded ? "rotate(180deg)" : "none",
      transition: "transform .2s ease"
    }
  }))), progress != null && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "12px",
      height: "8px",
      borderRadius: "var(--ff-radius-pill)",
      background: "var(--ff-surface-muted)",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: `${Math.max(0, Math.min(100, progress))}%`,
      height: "100%",
      background: "var(--ff-accent-green)",
      borderRadius: "var(--ff-radius-pill)"
    }
  })));
}
Object.assign(__ds_scope, { ProgressLevel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hub/ProgressLevel.jsx", error: String((e && e.message) || e) }); }

// components/hub/SmallMilestoneBadge.jsx
try { (() => {
/**
 * Small milestone badge — the compact (32px) form of `MilestoneBadge`, from
 * the Figma "Small Milsetone Badge" set. Used inline in rows and lists.
 */
function SmallMilestoneBadge({
  icon = "IconStars",
  locked = false,
  art,
  style = {}
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.MilestoneBadge, {
    icon: icon,
    locked: locked,
    art: art,
    size: 32,
    style: style
  });
}
Object.assign(__ds_scope, { SmallMilestoneBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hub/SmallMilestoneBadge.jsx", error: String((e && e.message) || e) }); }

// components/hub/SmallMilsetoneBadge.jsx
try { (() => {
/**
 * SmallMilsetoneBadge — alias matching the source file's (misspelled) family
 * name "Small Milsetone Badge". Prefer `SmallMilestoneBadge` (correct spelling)
 * in new code; this exists so the kit's exact vocabulary resolves.
 */
function SmallMilsetoneBadge(props) {
  return /*#__PURE__*/React.createElement(__ds_scope.SmallMilestoneBadge, props);
}
Object.assign(__ds_scope, { SmallMilsetoneBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hub/SmallMilsetoneBadge.jsx", error: String((e && e.message) || e) }); }

// components/hub/StatusIndicator.jsx
try { (() => {
/**
 * Status indicator — a small colored dot for live/step states.
 * active = blue #007CAB, inactive = grey border, complete = green.
 */
const INDICATOR = {
  active: {
    fill: "var(--ff-blue)",
    ring: "var(--ff-blue)"
  },
  inactive: {
    fill: "transparent",
    ring: "var(--ff-status-assigned-dot)"
  },
  complete: {
    fill: "var(--ff-accent-green)",
    ring: "var(--ff-accent-green)"
  }
};
function StatusIndicator({
  state = "active",
  size = 10,
  label,
  style = {}
}) {
  const s = StatusIndicator.states[state] || StatusIndicator.states.active;
  const dot = /*#__PURE__*/React.createElement("span", {
    style: {
      width: `${size}px`,
      height: `${size}px`,
      borderRadius: "50%",
      background: s.fill,
      boxShadow: `inset 0 0 0 2px ${s.ring}`,
      display: "inline-block",
      flexShrink: 0
    }
  });
  if (!label) return dot;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "8px",
      fontFamily: "var(--ff-font)",
      fontSize: "14px",
      color: "var(--ff-text-primary)",
      ...style
    }
  }, dot, label);
}

// State→color map — exposed as a static, not a bundle component.
StatusIndicator.states = INDICATOR;
Object.assign(__ds_scope, { StatusIndicator });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hub/StatusIndicator.jsx", error: String((e && e.message) || e) }); }

// components/hub/StatusPill.jsx
try { (() => {
/**
 * Status pill — action-plan status indicator. A coloured dot + label in a
 * tinted pill. Maps the Figma "status dropdown" states.
 */
const STATUSES = {
  assigned: {
    label: "Assigned",
    bg: "var(--ff-status-assigned-bg)",
    dot: "var(--ff-status-assigned-dot)"
  },
  "in-progress": {
    label: "In Progress",
    bg: "var(--ff-status-progress-bg)",
    dot: "var(--ff-status-progress-dot)"
  },
  completed: {
    label: "Completed",
    bg: "var(--ff-status-completed-bg)",
    dot: "var(--ff-status-completed-dot)"
  }
};
function StatusPill({
  status = "assigned",
  label,
  style = {}
}) {
  const s = StatusPill.statuses[status] || StatusPill.statuses.assigned;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "6px",
      padding: "4px 12px 4px 10px",
      borderRadius: "var(--ff-radius-pill)",
      backgroundColor: s.bg,
      fontFamily: "var(--ff-font)",
      fontSize: "12px",
      fontWeight: "var(--ff-weight-bold)",
      color: "var(--ff-text-primary)",
      whiteSpace: "nowrap",
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: "8px",
      height: "8px",
      borderRadius: "50%",
      backgroundColor: s.dot
    }
  }), label || s.label);
}

// Action-plan status map — exposed as a static, not a bundle component.
StatusPill.statuses = STATUSES;
Object.assign(__ds_scope, { StatusPill });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hub/StatusPill.jsx", error: String((e && e.message) || e) }); }

// components/hub/ActionItem.jsx
try { (() => {
/**
 * Action item — a row in "Here are your top priorities" / My Action Plan.
 * Title on the left, a StatusPill and chevron on the right, divided by a
 * hairline border. The whole row is clickable.
 */
function ActionItem({
  title,
  status = "assigned",
  onClick,
  last = false,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClick,
    style: {
      width: "100%",
      display: "flex",
      alignItems: "center",
      gap: "16px",
      padding: "20px 20px 20px 24px",
      background: "var(--ff-surface)",
      border: "none",
      borderBottom: last ? "none" : "1px solid var(--ff-border)",
      cursor: "pointer",
      textAlign: "left",
      fontFamily: "var(--ff-font)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontSize: "18px",
      color: "var(--ff-text-primary)",
      lineHeight: 1.4
    }
  }, title), /*#__PURE__*/React.createElement(__ds_scope.StatusPill, {
    status: status
  }), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "IconChevronRightSize1rem",
    size: 20,
    style: {
      color: "var(--ff-text-secondary)",
      flexShrink: 0
    }
  }));
}
Object.assign(__ds_scope, { ActionItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hub/ActionItem.jsx", error: String((e && e.message) || e) }); }

// components/hub/StatusDropdown.jsx
try { (() => {
/**
 * Status dropdown — the interactive form of StatusPill (Figma "status
 * dropdown"). Shows the current action-plan status as a pill with a chevron;
 * click to pick a new status. Wraps `StatusPill` for the trigger + options.
 */
function StatusDropdown({
  status = "assigned",
  onChange,
  style = {}
}) {
  const [open, setOpen] = React.useState(false);
  const options = ["assigned", "in-progress", "completed"];
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      display: "inline-flex",
      fontFamily: "var(--ff-font)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => setOpen(o => !o),
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "4px",
      border: "none",
      background: "transparent",
      cursor: "pointer",
      padding: 0
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.StatusPill, {
    status: status
  }), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "IconChevronDownSize1rem",
    size: 18,
    style: {
      color: "var(--ff-text-secondary)",
      transform: open ? "rotate(180deg)" : "none",
      transition: "transform .18s ease"
    }
  })), open && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: "calc(100% + 6px)",
      left: 0,
      zIndex: 20,
      background: "var(--ff-white)",
      border: "1px solid var(--ff-border)",
      borderRadius: "12px",
      boxShadow: "var(--ff-shadow-pop)",
      padding: "6px",
      display: "flex",
      flexDirection: "column",
      gap: "4px"
    }
  }, options.map(o => /*#__PURE__*/React.createElement("button", {
    key: o,
    type: "button",
    onClick: () => {
      onChange && onChange(o);
      setOpen(false);
    },
    style: {
      border: "none",
      background: o === status ? "var(--ff-surface-muted)" : "transparent",
      borderRadius: "8px",
      padding: "4px",
      cursor: "pointer",
      textAlign: "left"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.StatusPill, {
    status: o
  })))));
}
Object.assign(__ds_scope, { StatusDropdown });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hub/StatusDropdown.jsx", error: String((e && e.message) || e) }); }

// components/hub/Tooltip.jsx
try { (() => {
/**
 * Tooltip — navy popover with white text and a directional beak. Wrap any
 * trigger; the bubble shows on hover/focus. Positions: top / bottom / left / right.
 */
function Tooltip({
  children,
  content,
  position = "top",
  style = {}
}) {
  const [show, setShow] = React.useState(false);
  const beakSize = 7;
  const bubble = {
    position: "absolute",
    zIndex: 20,
    whiteSpace: "nowrap",
    backgroundColor: "var(--ff-navy)",
    color: "var(--ff-white)",
    fontFamily: "var(--ff-font)",
    fontSize: "13px",
    lineHeight: 1.4,
    padding: "8px 12px",
    borderRadius: "8px",
    boxShadow: "var(--ff-shadow-pop)"
  };
  const pos = {
    top: {
      bottom: "calc(100% + 10px)",
      left: "50%",
      transform: "translateX(-50%)"
    },
    bottom: {
      top: "calc(100% + 10px)",
      left: "50%",
      transform: "translateX(-50%)"
    },
    left: {
      right: "calc(100% + 10px)",
      top: "50%",
      transform: "translateY(-50%)"
    },
    right: {
      left: "calc(100% + 10px)",
      top: "50%",
      transform: "translateY(-50%)"
    }
  }[position];
  const beak = {
    top: {
      top: "100%",
      left: "50%",
      marginLeft: -beakSize,
      borderWidth: `${beakSize}px ${beakSize}px 0`,
      borderColor: "var(--ff-navy) transparent transparent"
    },
    bottom: {
      bottom: "100%",
      left: "50%",
      marginLeft: -beakSize,
      borderWidth: `0 ${beakSize}px ${beakSize}px`,
      borderColor: "transparent transparent var(--ff-navy)"
    },
    left: {
      left: "100%",
      top: "50%",
      marginTop: -beakSize,
      borderWidth: `${beakSize}px 0 ${beakSize}px ${beakSize}px`,
      borderColor: "transparent transparent transparent var(--ff-navy)"
    },
    right: {
      right: "100%",
      top: "50%",
      marginTop: -beakSize,
      borderWidth: `${beakSize}px ${beakSize}px ${beakSize}px 0`,
      borderColor: "transparent var(--ff-navy) transparent transparent"
    }
  }[position];
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      display: "inline-flex",
      ...style
    },
    onMouseEnter: () => setShow(true),
    onMouseLeave: () => setShow(false),
    onFocus: () => setShow(true),
    onBlur: () => setShow(false)
  }, children, show && /*#__PURE__*/React.createElement("span", {
    style: {
      ...bubble,
      ...pos
    }
  }, content, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      width: 0,
      height: 0,
      borderStyle: "solid",
      ...beak
    }
  })));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hub/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/media/Image11LandscapeNone.jsx
try { (() => {
// figma node: 3:1484 image/1:1/landscape/none
function Image11LandscapeNone(_p = {}) {
  const props = _p;
  return /*#__PURE__*/React.createElement("div", {
    className: "fig-asset-51658499216ab72a " + (props.className || ''),
    style: {
      width: 240,
      height: 240,
      overflow: "hidden",
      display: "flex",
      flexDirection: "column",
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      height: 240,
      overflow: "hidden",
      display: "flex",
      flexDirection: "column",
      alignItems: "flex-start",
      flexWrap: "nowrap",
      flexShrink: 0,
      alignSelf: "stretch"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      transform: "matrix(0.707,-0.707,0.707,0.707,-0.001,70.296)",
      transformOrigin: "0 0",
      width: 99.412,
      height: 240,
      display: "flex",
      flexDirection: "row",
      alignItems: "flex-start",
      flexWrap: "nowrap"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      transform: "matrix(0.910,0.414,-0.414,0.910,99.412,10.779)",
      transformOrigin: "0 0",
      width: 0,
      height: 240,
      display: "flex",
      flexDirection: "row",
      alignItems: "center",
      flexWrap: "nowrap"
    }
  }))));
}
Object.assign(__ds_scope, { Image11LandscapeNone, __ds_default_components_media_Image11LandscapeNone_wyyeuh: Image11LandscapeNone });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/media/Image11LandscapeNone.jsx", error: String((e && e.message) || e) }); }

// components/media/Image21LandscapeNone.jsx
try { (() => {
// figma node: 3:1442 image/2:1/landscape/none
function Image21LandscapeNone(_p = {}) {
  const props = _p;
  return /*#__PURE__*/React.createElement("div", {
    className: "fig-asset-2c4a0db16ad1e059 " + (props.className || ''),
    style: {
      width: 480,
      height: 240,
      overflow: "hidden",
      display: "flex",
      flexDirection: "column",
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      height: 240,
      overflow: "hidden",
      display: "flex",
      flexDirection: "column",
      alignItems: "flex-start",
      flexWrap: "nowrap",
      flexShrink: 0,
      alignSelf: "stretch"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      transform: "matrix(0.866,-0.500,0.500,0.866,32.154,240)",
      transformOrigin: "0 0",
      width: 480,
      height: 0,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      flexWrap: "nowrap"
    }
  })));
}
Object.assign(__ds_scope, { Image21LandscapeNone, __ds_default_components_media_Image21LandscapeNone_78si96: Image21LandscapeNone });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/media/Image21LandscapeNone.jsx", error: String((e && e.message) || e) }); }

// components/misc/Frame1000004665.jsx
try { (() => {
// figma node: 2141:3883 Frame 1000004665
function Frame1000004665(_p = {}) {
  const props = _p;
  return /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: "fit-content",
      display: "flex",
      flexDirection: "row",
      gap: 20,
      padding: "10px 0px 10px 0px",
      justifyContent: "flex-end",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      display: "flex",
      flexDirection: "row",
      gap: 15,
      alignItems: "center",
      flexWrap: "nowrap",
      flexShrink: 0,
      alignSelf: "stretch"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      borderRadius: 50,
      backgroundColor: "rgb(244,247,254)",
      display: "flex",
      flexDirection: "row",
      gap: 15,
      padding: "12px 27px 12px 27px",
      justifyContent: "center",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      flexShrink: 0,
      alignSelf: "stretch"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Lato, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 500,
      fontSize: 16,
      whiteSpace: "nowrap",
      lineHeight: "22px",
      color: "rgb(56,56,56)",
      flexShrink: 0,
      alignSelf: "stretch"
    }
  }, props.text1 ?? "I’m experiencing a financial crisis right now"), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      width: 22,
      borderRadius: "50%",
      boxShadow: "inset 0 0 0 1px rgb(56,56,56)",
      flexShrink: 0,
      alignSelf: "stretch"
    }
  }))));
}
Object.assign(__ds_scope, { Frame1000004665, __ds_default_components_misc_Frame1000004665_j5oaeu: Frame1000004665 });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/misc/Frame1000004665.jsx", error: String((e && e.message) || e) }); }

// components/misc/Frame1000004752.jsx
try { (() => {
// figma node: 2141:3870 Frame 1000004752
function Frame1000004752(_p = {}) {
  const props = _p;
  return /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: "fit-content",
      display: "flex",
      flexDirection: "row",
      gap: 8,
      justifyContent: "flex-end",
      alignItems: "center",
      flexWrap: "nowrap",
      position: "relative",
      color: "rgb(0,124,171)",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      width: 20,
      overflow: "hidden",
      flexShrink: 0,
      alignSelf: "stretch"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 20,
      height: 20,
      clipPath: "inset(0px 0px 0px 0px)"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: 13.167,
    height: 13.167,
    viewBox: "0 0 13.167 13.167",
    fill: "none",
    style: {
      position: "absolute",
      left: 3.417,
      top: 3.417,
      width: 13.167,
      height: 13.167
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 1.083 12.083 L 2.01 12.083 L 10.207 3.886 L 9.28 2.96 L 1.083 11.157 L 1.083 12.083 Z M 0 13.167 L 0 10.7 L 10.367 0.317 C 10.479 0.203 10.6 0.121 10.729 0.073 C 10.858 0.024 10.993 0 11.135 0 C 11.277 0 11.412 0.023 11.541 0.068 C 11.67 0.114 11.794 0.194 11.915 0.309 L 12.849 1.236 C 12.965 1.356 13.047 1.481 13.095 1.611 C 13.143 1.74 13.167 1.873 13.167 2.01 C 13.167 2.156 13.141 2.295 13.091 2.428 C 13.04 2.561 12.96 2.682 12.849 2.792 L 2.466 13.167 L 0 13.167 Z M 9.735 3.431 L 9.28 2.96 L 10.207 3.886 L 9.735 3.431 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })))), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Lato, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 700,
      fontSize: 16,
      whiteSpace: "nowrap",
      lineHeight: "22px",
      color: "rgb(0,124,171)",
      flexShrink: 0,
      alignSelf: "stretch"
    }
  }, props.text1 ?? "Change answer"));
}
Object.assign(__ds_scope, { Frame1000004752, __ds_default_components_misc_Frame1000004752_j5ob83: Frame1000004752 });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/misc/Frame1000004752.jsx", error: String((e && e.message) || e) }); }

// components/misc/Frame2087327407.jsx
try { (() => {
// figma node: 5140:25462 Frame 2087327407
function Frame2087327407(_p = {}) {
  const props = _p;
  return /*#__PURE__*/React.createElement("div", {
    className: "fig-asset-9dc05ac98875a7dc-105902e9 " + (props.className || ''),
    style: {
      width: 250,
      height: 300,
      borderRadius: 16,
      display: "flex",
      flexDirection: "column",
      gap: 4,
      padding: "216px 27px 24px 25px",
      justifyContent: "flex-end",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      height: 80,
      overflow: "hidden",
      flexShrink: 0,
      alignSelf: "stretch"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 198,
      height: 60,
      fontFamily: "Lato, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 700,
      fontSize: 28,
      lineHeight: 1.2999999523162842,
      color: "var(--colors-neutrals-white)"
    }
  }, props.text1 ?? "Starting Strong in Your New Role"), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      left: 0,
      top: 64,
      width: 198,
      height: 16,
      fontFamily: "Lato, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 700,
      fontSize: 24,
      lineHeight: 1.2400000095367432,
      color: "var(--colors-neutrals-white)"
    }
  }, props.text2 ?? "Got the job")));
}
Object.assign(__ds_scope, { Frame2087327407, __ds_default_components_misc_Frame2087327407_1kx06w8: Frame2087327407 });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/misc/Frame2087327407.jsx", error: String((e && e.message) || e) }); }

// components/misc/Frame36070.jsx
try { (() => {
// figma node: 2141:3877 Frame 36070
function Frame36070(_p = {}) {
  const props = _p;
  return /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: 952,
      display: "flex",
      flexDirection: "row",
      gap: 20,
      padding: "15px 0px 15px 0px",
      alignItems: "flex-start",
      flexWrap: "nowrap",
      boxSizing: "border-box",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      width: 30.203,
      overflow: "hidden",
      flexShrink: 0,
      alignSelf: "stretch"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 30.203,
      height: 30.203,
      borderRadius: "50%",
      backgroundColor: "rgb(255,255,255)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "fig-asset-5f993b3f27d1fed4",
    style: {
      position: "absolute",
      left: 3.236,
      top: 3.236,
      width: 23.869,
      height: 23.731
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      width: 446,
      display: "flex",
      flexDirection: "row",
      gap: 15,
      alignItems: "center",
      flexWrap: "nowrap",
      flexShrink: 0,
      alignSelf: "stretch"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      width: 477,
      fontFamily: "Lato, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 500,
      fontSize: 16,
      lineHeight: "22px",
      color: "rgb(56,56,56)",
      flexShrink: 0
    }
  }, props.text1 ?? "What has happened that requires you to revisit your plan?")));
}
Object.assign(__ds_scope, { Frame36070, __ds_default_components_misc_Frame36070_963qtc: Frame36070 });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/misc/Frame36070.jsx", error: String((e && e.message) || e) }); }

// components/misc/Group6829.jsx
try { (() => {
// figma node: 5832:15347 Group 6829
function Group6829(_p = {}) {
  const props = _p;
  return /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: 800.002,
      height: 131,
      position: "relative",
      color: "rgb(235,238,244)",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 800,
      height: 131,
      borderRadius: 12,
      backgroundColor: "rgb(255,255,255)",
      borderTop: "1px solid rgb(235,238,244)",
      borderRight: "1px solid rgb(235,238,244)",
      borderBottom: "1px solid rgb(235,238,244)",
      borderLeft: "1px solid rgb(235,238,244)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 24,
      top: 64,
      width: 753,
      height: 52,
      borderRadius: 50,
      backgroundColor: "rgb(255,255,255)",
      boxShadow: "inset 0 0 0 1px rgb(214,220,234)",
      display: "flex",
      flexDirection: "row",
      gap: 20,
      padding: "14px 20px 14px 20px",
      alignItems: "center",
      flexWrap: "nowrap",
      boxSizing: "border-box"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "\"la-solid-900\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 18,
      textAlign: "center",
      lineHeight: "100%",
      color: "rgb(214,220,234)",
      flexShrink: 0,
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? ""), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Lato, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 15,
      lineHeight: "24px",
      color: "rgb(129,129,165)",
      flexGrow: 1,
      alignSelf: "stretch"
    }
  }, props.text2 ?? "Type your financial or benefit question or topic")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 800.002,
      height: 1,
      border: "1px dashed currentColor",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      overflow: "hidden",
      fontSize: 10,
      opacity: 0.45
    }
  }, "Line 10"));
}
Object.assign(__ds_scope, { Group6829, __ds_default_components_misc_Group6829_xims7v: Group6829 });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/misc/Group6829.jsx", error: String((e && e.message) || e) }); }

// components/misc/Component2.jsx
try { (() => {
// figma node: 5832:15369 Component 2
function Component2(_p = {}) {
  const props = _p;
  return /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: 800.002,
      height: 131,
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Group6829, {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 800.002,
      height: 131
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 17,
      top: 12,
      width: 152.727,
      height: 24,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 23.972,
      height: 24,
      border: "1px dashed currentColor",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      overflow: "hidden",
      fontSize: 10,
      opacity: 0.45
    }
  }, "Vector"), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 6.417,
      top: 4.325,
      width: 11.134,
      height: 15.525,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: 11.134,
    height: 13.586,
    viewBox: "0 0 11.134 13.586",
    fill: "none",
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 11.134,
      height: 13.586,
      color: "rgb(255,255,255)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 10.609 8.405 C 10.966 7.657 11.224 6.707 11.105 5.355 C 10.825 2.117 8.307 0.995 6.832 0.615 C 6.677 0.576 6.506 0.54 6.323 0.515 C 6.248 0.219 5.98 0 5.662 0 C 5.343 0 5.092 0.205 5.009 0.488 C 3.777 0.604 2.385 1.152 1.397 2.579 C 1.331 2.557 1.262 2.546 1.19 2.546 C 0.814 2.546 0.506 2.851 0.506 3.23 C 0.506 3.446 0.606 3.638 0.761 3.762 C 0.232 5.017 0.116 6.25 0.407 7.447 C 0.169 7.552 0 7.793 0 8.07 C 0 8.447 0.304 8.754 0.683 8.754 C 0.753 8.754 0.819 8.743 0.88 8.724 C 1.09 9.142 1.35 9.555 1.663 9.962 C 2.416 10.943 2.369 11.458 2.319 12.004 C 2.302 12.201 2.283 12.406 2.302 12.63 C 2.371 13.392 2.908 13.586 3.204 13.586 C 3.215 13.586 3.229 13.586 3.24 13.586 L 8.072 13.586 C 8.191 13.586 8.29 13.489 8.29 13.367 C 8.29 13.245 8.194 13.148 8.072 13.148 L 3.229 13.148 C 3.157 13.148 2.784 13.134 2.734 12.589 C 2.717 12.406 2.734 12.229 2.751 12.043 C 2.803 11.467 2.861 10.81 2.006 9.696 C 1.693 9.292 1.439 8.879 1.237 8.464 C 1.259 8.43 1.281 8.394 1.298 8.358 L 4.975 9.345 C 4.989 9.644 5.194 9.89 5.471 9.968 L 5.471 12.195 C 5.471 12.314 5.568 12.414 5.689 12.414 L 7.892 12.414 C 8.938 12.414 9.112 11.616 9.24 11.032 C 9.275 10.866 9.311 10.71 9.358 10.572 C 9.477 10.237 9.688 9.918 9.931 9.55 C 9.995 9.569 10.061 9.58 10.131 9.58 C 10.507 9.58 10.814 9.275 10.814 8.896 C 10.814 8.702 10.734 8.53 10.606 8.405 L 10.609 8.405 Z M 6.287 9.037 C 6.268 8.995 6.245 8.957 6.221 8.921 L 8.398 5.707 C 8.456 5.724 8.517 5.732 8.581 5.732 C 8.595 5.732 8.609 5.732 8.622 5.732 L 9.691 8.38 C 9.583 8.475 9.502 8.599 9.469 8.743 L 6.287 9.043 L 6.287 9.037 Z M 1.342 7.885 L 4.001 5.965 C 4.112 6.045 4.248 6.092 4.397 6.092 L 5.277 8.746 C 5.208 8.793 5.147 8.854 5.097 8.926 L 1.35 7.921 C 1.35 7.921 1.345 7.896 1.342 7.885 Z M 5.543 1.352 C 5.581 1.357 5.62 1.363 5.662 1.363 C 5.673 1.363 5.681 1.363 5.692 1.363 L 8.03 4.649 C 7.978 4.721 7.942 4.801 7.92 4.89 L 5.025 5.139 C 4.97 5.009 4.873 4.901 4.754 4.829 L 5.543 1.355 L 5.543 1.352 Z M 5.872 8.66 C 5.817 8.644 5.758 8.633 5.698 8.63 L 4.809 5.954 C 4.934 5.859 5.025 5.726 5.061 5.569 L 7.956 5.319 C 7.978 5.369 8.005 5.416 8.039 5.46 L 5.872 8.66 Z M 10.219 8.217 C 10.191 8.214 10.164 8.211 10.136 8.211 C 10.122 8.211 10.108 8.211 10.095 8.211 L 9.026 5.563 C 9.173 5.438 9.264 5.253 9.264 5.045 C 9.264 4.915 9.228 4.793 9.165 4.69 L 10.15 3.524 C 10.421 4.039 10.609 4.654 10.673 5.388 C 10.781 6.646 10.551 7.516 10.219 8.214 L 10.219 8.217 Z M 9.915 3.131 L 8.833 4.413 C 8.755 4.383 8.669 4.366 8.581 4.366 C 8.512 4.366 8.445 4.377 8.382 4.397 L 6.107 1.2 C 6.185 1.13 6.248 1.047 6.29 0.95 C 6.445 0.972 6.591 1.003 6.724 1.036 C 7.662 1.277 9.051 1.84 9.915 3.131 Z M 5.022 0.92 C 5.05 0.997 5.094 1.069 5.147 1.13 L 4.331 4.729 C 4.195 4.743 4.07 4.796 3.971 4.876 L 1.818 3.493 C 1.854 3.41 1.873 3.319 1.873 3.225 C 1.873 3.078 1.826 2.945 1.749 2.834 C 2.643 1.538 3.904 1.033 5.022 0.92 Z M 1.171 3.909 C 1.171 3.909 1.184 3.909 1.19 3.909 C 1.312 3.909 1.425 3.876 1.522 3.82 L 3.736 5.242 C 3.722 5.294 3.714 5.35 3.714 5.408 C 3.714 5.48 3.725 5.546 3.744 5.61 L 1.096 7.524 C 1.024 7.469 0.941 7.427 0.85 7.405 C 0.559 6.269 0.664 5.1 1.168 3.909 L 1.171 3.909 Z M 8.954 10.428 C 8.896 10.591 8.858 10.769 8.822 10.94 C 8.681 11.586 8.562 11.979 7.897 11.979 L 5.913 11.979 L 5.913 9.949 C 6.118 9.868 6.276 9.691 6.328 9.472 L 9.513 9.173 C 9.533 9.217 9.558 9.259 9.585 9.295 C 9.585 9.297 9.58 9.303 9.577 9.306 C 9.328 9.683 9.093 10.04 8.957 10.425 L 8.954 10.428 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 3.680,
    height: 1.380,
    viewBox: "0 0 3.680 1.380",
    fill: "none",
    style: {
      position: "absolute",
      left: 3.819,
      top: 14.146,
      width: 3.68,
      height: 1.38,
      color: "rgb(255,255,255)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 3.464 0 L 0.219 0 C 0.1 0 0 0.097 0 0.219 C 0 0.341 0.097 0.438 0.219 0.438 L 0.722 0.438 C 0.819 0.972 1.289 1.38 1.851 1.38 C 2.413 1.38 2.883 0.972 2.98 0.438 L 3.462 0.438 C 3.581 0.438 3.68 0.341 3.68 0.219 C 3.68 0.097 3.583 0 3.462 0 L 3.464 0 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 31.305,
      top: 5.898,
      width: 121.428,
      height: 12.204,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0.233,
      width: 113.979,
      height: 11.971,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: 8.382,
    height: 11.511,
    viewBox: "0 0 8.382 11.511",
    fill: "none",
    style: {
      position: "absolute",
      left: 0,
      top: 0.427,
      width: 8.382,
      height: 11.511,
      color: "rgb(35,35,35)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 9.721 L 0.783 8.793 C 1.948 9.849 3.066 10.375 4.616 10.375 C 6.165 10.375 7.106 9.577 7.106 8.472 L 7.106 8.439 C 7.106 7.4 6.547 6.81 4.201 6.314 C 1.63 5.754 0.448 4.923 0.448 3.086 L 0.448 3.053 C 0.448 1.294 1.998 0 4.12 0 C 5.747 0 6.915 0.463 8.047 1.374 L 7.314 2.349 C 6.276 1.502 5.238 1.136 4.09 1.136 C 2.637 1.136 1.71 1.934 1.71 2.942 L 1.71 2.975 C 1.71 4.031 2.286 4.621 4.743 5.15 C 7.233 5.693 8.382 6.605 8.382 8.314 L 8.382 8.347 C 8.382 10.264 6.785 11.511 4.566 11.511 C 2.795 11.511 1.342 10.921 0 9.721 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 12.516,
    height: 8.439,
    viewBox: "0 0 12.516 8.439",
    fill: "none",
    style: {
      position: "absolute",
      left: 10.745,
      top: 3.341,
      width: 12.516,
      height: 8.439,
      color: "rgb(35,35,35)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 0.175 L 1.229 0.175 L 1.229 1.565 C 1.771 0.751 2.507 0 3.893 0 C 5.28 0 6.096 0.72 6.544 1.646 C 7.134 0.734 8.014 0 9.45 0 C 11.351 0 12.516 1.28 12.516 3.324 L 12.516 8.439 L 11.287 8.439 L 11.287 3.613 C 11.287 2.014 10.49 1.119 9.148 1.119 C 7.903 1.119 6.865 2.047 6.865 3.676 L 6.865 8.439 L 5.653 8.439 L 5.653 3.579 C 5.653 2.028 4.84 1.116 3.531 1.116 C 2.222 1.116 1.231 2.202 1.231 3.721 L 1.231 8.436 L 0.003 8.436 L 0.003 0.172 L 0 0.175 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 8.332,
    height: 8.616,
    viewBox: "0 0 8.332 8.616",
    fill: "none",
    style: {
      position: "absolute",
      left: 25.4,
      top: 3.338,
      width: 8.332,
      height: 8.616,
      color: "rgb(35,35,35)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 4.333 L 0 4.3 C 0 1.599 1.965 0 3.943 0 C 5.476 0 6.467 0.831 7.103 1.759 L 7.103 0.177 L 8.332 0.177 L 8.332 8.441 L 7.103 8.441 L 7.103 6.779 C 6.434 7.771 5.46 8.616 3.943 8.616 C 1.965 8.616 0 7.051 0 4.333 Z M 7.153 4.316 L 7.153 4.283 C 7.153 2.38 5.7 1.103 4.167 1.103 C 2.634 1.103 1.262 2.286 1.262 4.283 L 1.262 4.316 C 1.262 6.267 2.604 7.513 4.167 7.513 C 5.731 7.513 7.153 6.22 7.153 4.316 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 4.599,
    height: 8.408,
    viewBox: "0 0 4.599 8.408",
    fill: "none",
    style: {
      position: "absolute",
      left: 36.479,
      top: 3.369,
      width: 4.599,
      height: 8.408,
      color: "rgb(35,35,35)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0.003 0.147 L 1.231 0.147 L 1.231 2.305 C 1.837 0.931 3.036 -0.061 4.599 0.003 L 4.599 1.33 L 4.502 1.33 C 2.698 1.33 1.229 2.624 1.229 5.117 L 1.229 8.408 L 0 8.408 L 0 0.144 L 0.003 0.147 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 4.995,
    height: 10.899,
    viewBox: "0 0 4.995 10.899",
    fill: "none",
    style: {
      position: "absolute",
      left: 42.229,
      top: 1.022,
      width: 4.995,
      height: 10.899,
      color: "rgb(35,35,35)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 1.148 8.566 L 1.148 3.579 L 0 3.579 L 0 2.493 L 1.148 2.493 L 1.148 0 L 2.377 0 L 2.377 2.493 L 4.995 2.493 L 4.995 3.579 L 2.377 3.579 L 2.377 8.405 C 2.377 9.411 2.936 9.78 3.766 9.78 C 4.181 9.78 4.533 9.699 4.964 9.491 L 4.964 10.547 C 4.533 10.771 4.07 10.899 3.478 10.899 C 2.153 10.899 1.148 10.242 1.148 8.566 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 9.500,
    height: 11.192,
    viewBox: "0 0 9.500 11.192",
    fill: "none",
    style: {
      position: "absolute",
      left: 49.366,
      top: 0.59,
      width: 9.5,
      height: 11.192,
      color: "rgb(35,35,35)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 0 L 5.188 0 C 6.467 0 7.471 0.352 8.111 0.992 C 8.622 1.504 8.877 2.128 8.877 2.895 L 8.877 2.928 C 8.877 4.192 8.207 4.895 7.408 5.341 C 8.7 5.837 9.5 6.588 9.5 8.09 L 9.5 8.123 C 9.5 10.167 7.839 11.192 5.316 11.192 L 0 11.192 L 0 0 Z M 6.434 3.308 C 6.434 2.574 5.858 2.158 4.82 2.158 L 2.394 2.158 L 2.394 4.524 L 4.66 4.524 C 5.745 4.524 6.431 4.172 6.431 3.341 L 6.431 3.308 L 6.434 3.308 Z M 5.235 6.569 L 2.394 6.569 L 2.394 9.029 L 5.316 9.029 C 6.4 9.029 7.056 8.646 7.056 7.815 L 7.056 7.782 C 7.056 7.031 6.497 6.569 5.235 6.569 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 8.398,
    height: 8.921,
    viewBox: "0 0 8.398 8.921",
    fill: "none",
    style: {
      position: "absolute",
      left: 60.221,
      top: 3.05,
      width: 8.398,
      height: 8.921,
      color: "rgb(35,35,35)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 4.494 L 0 4.46 C 0 2.014 1.741 0 4.231 0 C 7.089 0 8.398 2.222 8.398 4.652 C 8.398 4.843 8.382 5.067 8.365 5.291 L 2.41 5.291 C 2.651 6.394 3.415 6.97 4.502 6.97 C 5.316 6.97 5.908 6.715 6.578 6.092 L 7.967 7.322 C 7.17 8.314 6.019 8.921 4.472 8.921 C 1.901 8.921 0.003 7.114 0.003 4.494 L 0 4.494 Z M 6.035 3.773 C 5.891 2.687 5.252 1.95 4.231 1.95 C 3.21 1.95 2.571 2.671 2.38 3.773 L 6.035 3.773 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 7.839,
    height: 8.727,
    viewBox: "0 0 7.839 8.727",
    fill: "none",
    style: {
      position: "absolute",
      left: 70.424,
      top: 3.05,
      width: 7.839,
      height: 8.727,
      color: "rgb(35,35,35)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 0.161 L 2.427 0.161 L 2.427 1.374 C 2.986 0.654 3.705 0 4.934 0 C 6.768 0 7.839 1.213 7.839 3.18 L 7.839 8.727 L 5.413 8.727 L 5.413 3.948 C 5.413 2.798 4.87 2.205 3.943 2.205 C 3.016 2.205 2.427 2.795 2.427 3.948 L 2.427 8.727 L 0 8.727 L 0 0.161 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 8.398,
    height: 8.921,
    viewBox: "0 0 8.398 8.921",
    fill: "none",
    style: {
      position: "absolute",
      left: 79.954,
      top: 3.05,
      width: 8.398,
      height: 8.921,
      color: "rgb(35,35,35)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 4.494 L 0 4.46 C 0 2.014 1.741 0 4.231 0 C 7.089 0 8.398 2.222 8.398 4.652 C 8.398 4.843 8.382 5.067 8.365 5.291 L 2.41 5.291 C 2.651 6.394 3.415 6.97 4.502 6.97 C 5.316 6.97 5.908 6.715 6.578 6.092 L 7.967 7.322 C 7.17 8.314 6.019 8.921 4.472 8.921 C 1.901 8.921 0.003 7.114 0.003 4.494 L 0 4.494 Z M 6.035 3.773 C 5.891 2.687 5.252 1.95 4.231 1.95 C 3.21 1.95 2.571 2.671 2.38 3.773 L 6.035 3.773 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 9.289,
    height: 11.780,
    viewBox: "0 0 9.289 11.780",
    fill: "none",
    style: {
      position: "absolute",
      left: 89.567,
      top: 0,
      width: 9.289,
      height: 11.78,
      color: "rgb(35,35,35)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 1.004 5.289 L 0 5.289 L 0 3.291 L 1.004 3.291 L 1.004 2.748 C 1.004 1.806 1.245 1.119 1.691 0.67 C 2.139 0.222 2.792 0 3.655 0 C 4.422 0 4.934 0.097 5.379 0.241 L 5.379 2.255 C 5.028 2.128 4.693 2.047 4.278 2.047 C 3.719 2.047 3.401 2.335 3.401 2.975 L 3.401 3.311 L 5.366 3.311 L 5.366 5.291 L 3.434 5.291 L 3.434 11.78 L 1.007 11.78 L 1.007 5.291 L 1.004 5.289 Z M 6.735 0.111 L 9.289 0.111 L 9.289 2.269 L 6.735 2.269 L 6.735 0.111 Z M 6.802 3.211 L 9.228 3.211 L 9.228 11.777 L 6.802 11.777 L 6.802 3.211 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 5.460,
    height: 10.899,
    viewBox: "0 0 5.460 10.899",
    fill: "none",
    style: {
      position: "absolute",
      left: 100.456,
      top: 1.025,
      width: 5.46,
      height: 10.899,
      color: "rgb(35,35,35)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 1.021 8.325 L 1.021 4.266 L 0 4.266 L 0 2.189 L 1.021 2.189 L 1.021 0 L 3.448 0 L 3.448 2.189 L 5.46 2.189 L 5.46 4.266 L 3.448 4.266 L 3.448 7.926 C 3.448 8.486 3.689 8.757 4.231 8.757 C 4.679 8.757 5.078 8.646 5.429 8.452 L 5.429 10.403 C 4.917 10.708 4.328 10.899 3.514 10.899 C 2.028 10.899 1.024 10.309 1.024 8.325 L 1.021 8.325 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 6.946,
    height: 8.857,
    viewBox: "0 0 6.946 8.857",
    fill: "none",
    style: {
      position: "absolute",
      left: 107.033,
      top: 3.078,
      width: 6.946,
      height: 8.857,
      color: "rgb(35,35,35)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 7.566 L 1.038 5.967 C 1.965 6.638 2.939 6.99 3.736 6.99 C 4.439 6.99 4.757 6.735 4.757 6.35 L 4.757 6.317 C 4.757 5.79 3.927 5.613 2.986 5.325 C 1.788 4.973 0.432 4.413 0.432 2.751 L 0.432 2.718 C 0.432 0.975 1.837 0 3.561 0 C 4.646 0 5.828 0.368 6.755 0.992 L 5.828 2.671 C 4.981 2.175 4.134 1.873 3.512 1.873 C 2.889 1.873 2.618 2.128 2.618 2.463 L 2.618 2.496 C 2.618 2.975 3.431 3.2 4.358 3.518 C 5.556 3.917 6.946 4.494 6.946 6.059 L 6.946 6.092 C 6.946 7.995 5.526 8.857 3.672 8.857 C 2.474 8.857 1.135 8.458 0 7.563 L 0 7.566 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  }))), /*#__PURE__*/React.createElement("svg", {
    width: 6.423,
    height: 3.158,
    viewBox: "0 0 6.423 3.158",
    fill: "none",
    style: {
      position: "absolute",
      left: 115.005,
      top: 0,
      width: 6.423,
      height: 3.158,
      color: "rgb(35,35,35)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0.941 0.634 L 0 0.634 L 0 0 L 2.601 0 L 2.601 0.634 L 1.66 0.634 L 1.66 3.155 L 0.944 3.155 L 0.944 0.634 L 0.941 0.634 Z M 3.265 0 L 4.023 0 L 4.854 1.333 L 5.684 0 L 6.423 0 L 6.423 3.158 L 5.747 3.158 L 5.747 1.025 L 4.876 2.41 L 4.815 2.41 L 3.943 1.025 L 3.943 3.158 L 3.268 3.158 L 3.268 0 L 3.265 0 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 662,
      top: 10,
      width: 127.857,
      height: 28
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 660,
      top: 12,
      width: 130,
      height: 29,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 49.528,
      top: 4.365,
      width: 71.528,
      height: 20.27,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 71.52815246582031,
      height: 20.269943237304688,
      clipPath: "inset(0px 0px 0px 0px)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 71.528,
      height: 20.27,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 71.528,
      height: 20.27,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: 6.129,
    height: 8.194,
    viewBox: "0 0 6.129 8.194",
    fill: "none",
    style: {
      position: "absolute",
      left: 63.776,
      top: 8.939,
      width: 6.129,
      height: 8.194,
      color: "rgb(18,132,175)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 6.076 0 L 0 0 L 0 8.194 L 6.129 8.194 L 6.129 6.913 L 1.441 6.913 L 1.441 4.705 L 5.539 4.705 L 5.539 3.424 L 1.441 3.424 L 1.441 1.294 L 6.076 1.294 L 6.076 0 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 71.528,
      height: 20.27,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 71.52815246582031,
      height: 20.269943237304688,
      clipPath: "inset(0px 0px 0px 0px)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 22.263,
      top: 3.082,
      width: 40.151,
      height: 14.182,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 40.151,
      height: 14.182,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: 6.364,
    height: 8.443,
    viewBox: "0 0 6.364 8.443",
    fill: "none",
    style: {
      position: "absolute",
      left: 33.787,
      top: 5.739,
      width: 6.364,
      height: 8.443,
      color: "rgb(18,132,175)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 1.781 2.261 C 1.781 1.712 2.279 1.281 3.117 1.281 C 3.955 1.281 4.61 1.569 5.343 2.118 L 6.116 1.033 C 5.278 0.34 4.217 -0.013 3.13 0 C 1.493 0 0.327 0.954 0.327 2.392 C 0.327 3.83 1.31 4.431 3.064 4.849 C 4.583 5.202 4.911 5.515 4.911 6.117 C 4.911 6.718 4.348 7.162 3.457 7.162 C 2.567 7.162 1.65 6.77 0.864 6.104 L 0 7.136 C 0.943 7.985 2.161 8.456 3.431 8.443 C 5.16 8.443 6.364 7.528 6.364 5.986 C 6.364 4.444 5.461 3.999 3.719 3.581 C 2.148 3.202 1.768 2.928 1.768 2.287 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 33.014,
    height: 8.443,
    viewBox: "0 0 33.014 8.443",
    fill: "none",
    style: {
      position: "absolute",
      left: 0,
      top: 5.739,
      width: 33.014,
      height: 8.443,
      color: "rgb(18,132,175)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 28.417 2.261 C 28.417 1.712 28.915 1.281 29.753 1.281 C 30.591 1.281 31.246 1.569 31.979 2.118 L 32.752 1.033 C 31.914 0.34 30.853 -0.013 29.779 0 C 28.142 0 26.977 0.954 26.977 2.392 C 26.977 3.83 27.959 4.431 29.714 4.849 C 31.233 5.202 31.573 5.515 31.573 6.117 C 31.573 6.718 31.01 7.162 30.12 7.162 C 29.229 7.162 28.313 6.77 27.527 6.104 L 26.663 7.136 C 27.606 7.985 28.823 8.456 30.081 8.443 C 31.809 8.443 33.014 7.528 33.014 5.986 C 33.014 4.444 32.11 3.999 30.382 3.581 C 28.81 3.202 28.431 2.928 28.431 2.287 Z M 25.576 0.118 L 19.499 0.118 L 19.499 8.312 L 25.641 8.312 L 25.641 7.018 L 20.94 7.018 L 20.94 4.823 L 25.052 4.823 L 25.052 3.529 L 20.94 3.529 L 20.94 1.399 L 25.576 1.399 L 25.576 0.105 L 25.576 0.118 Z M 16.5 5.79 L 12.1 0.118 L 10.765 0.118 L 10.765 8.312 L 12.179 8.312 L 12.179 2.483 L 16.71 8.312 L 17.915 8.312 L 17.915 0.118 L 16.5 0.118 L 16.5 5.79 Z M 7.7 8.312 L 9.141 8.312 L 9.141 0.118 L 7.7 0.118 L 7.7 8.312 Z M 6.116 0.118 L 0 0.118 L 0 8.312 L 1.441 8.312 L 1.441 4.98 L 5.579 4.98 L 5.579 3.673 L 1.441 3.673 L 1.441 1.438 L 6.116 1.438 L 6.116 0.118 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 37.074,
    height: 4.419,
    viewBox: "0 0 37.074 4.419",
    fill: "none",
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 37.074,
      height: 4.419,
      color: "rgb(0,82,145)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 34.062 4.341 L 37.074 4.341 L 37.074 3.661 L 34.821 3.661 L 34.821 0.067 L 34.062 0.067 L 34.062 4.341 Z M 31.482 2.642 L 30.002 2.642 L 30.735 0.93 L 31.482 2.642 Z M 31.102 0.028 L 30.408 0.028 L 28.522 4.328 L 29.295 4.328 L 29.74 3.308 L 31.77 3.308 L 32.202 4.341 L 33.001 4.341 L 31.115 0.028 L 31.102 0.028 Z M 26.702 4.328 L 27.448 4.328 L 27.448 0.067 L 26.702 0.067 L 26.702 4.328 Z M 25.654 3.648 L 25.17 3.165 C 24.803 3.504 24.463 3.727 23.939 3.727 C 23.114 3.727 22.524 3.047 22.524 2.197 C 22.524 1.348 23.114 0.681 23.939 0.681 C 24.764 0.681 24.79 0.891 25.144 1.217 L 25.628 0.668 C 25.183 0.224 24.58 -0.024 23.952 0.002 C 22.734 0.028 21.752 1.021 21.778 2.25 C 21.791 3.426 22.747 4.393 23.926 4.419 C 24.724 4.419 25.222 4.132 25.667 3.661 Z M 14.3 2.642 L 12.821 2.642 L 13.554 0.93 L 14.3 2.642 Z M 13.921 0.028 L 13.227 0.028 L 11.341 4.328 L 12.113 4.328 L 12.559 3.308 L 14.588 3.308 L 15.021 4.341 L 15.819 4.341 L 13.934 0.028 L 13.921 0.028 Z M 9.494 3.021 L 7.203 0.067 L 6.509 0.067 L 6.509 4.341 L 7.242 4.341 L 7.242 1.296 L 9.599 4.341 L 10.228 4.341 L 10.228 0.067 L 9.481 0.067 L 9.481 3.021 L 9.494 3.021 Z M 4.466 4.341 L 5.225 4.341 L 5.225 0.067 L 4.466 0.067 L 4.466 4.341 Z M 3.182 0.067 L 0 0.067 L 0 4.341 L 0.746 4.341 L 0.746 2.603 L 2.907 2.603 L 2.907 1.923 L 0.746 1.923 L 0.746 0.76 L 3.182 0.76 L 3.182 0.067 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 3.732,
    height: 4.274,
    viewBox: "0 0 3.732 4.274",
    fill: "none",
    style: {
      position: "absolute",
      left: 16.893,
      top: 0.067,
      width: 3.732,
      height: 4.274,
      color: "rgb(0,82,145)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 2.999 2.954 L 0.707 0 L 0 0 L 0 4.274 L 0.746 4.274 L 0.746 1.228 L 3.104 4.274 L 3.732 4.274 L 3.732 0 L 2.999 0 L 2.999 2.954 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })))))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 1.641,
      top: 1.856,
      width: 16.615,
      height: 16.585,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 16.614538192749023,
      height: 16.58528709411621,
      clipPath: "inset(0px 0px 0px 0px)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: -0.174,
      top: 0,
      width: 16.828,
      height: 16.637,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 16.828,
      height: 16.637,
      border: "1px dashed currentColor",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      overflow: "hidden",
      fontSize: 10,
      opacity: 0.45
    }
  }, "Vector")))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 1.641,
      top: 1.856,
      width: 16.615,
      height: 16.585,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 16.614538192749023,
      height: 16.58528709411621,
      clipPath: "inset(0px 0px 0px 0px)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: -0.174,
      top: 0,
      width: 16.828,
      height: 16.637,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 16.828,
      height: 16.637,
      border: "1px dashed currentColor",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      overflow: "hidden",
      fontSize: 10,
      opacity: 0.45
    }
  }, "Vector")))))))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 7.962,
      top: 11.644,
      width: 37.467,
      height: 6.103,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: 3.523,
    height: 4.783,
    viewBox: "0 0 3.523 4.783",
    fill: "none",
    style: {
      position: "absolute",
      left: 0,
      top: 0.209,
      width: 3.523,
      height: 4.783,
      color: "rgb(27,80,147)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 0 L 1.742 0 C 2.802 0 3.523 0.536 3.523 1.464 C 3.523 2.483 2.658 3.006 1.65 3.006 L 0.354 3.006 L 0.354 4.783 L 0 4.783 L 0 0 Z M 1.676 2.679 C 2.567 2.679 3.169 2.209 3.169 1.503 C 3.169 0.732 2.58 0.34 1.716 0.34 L 0.354 0.34 L 0.354 2.679 L 1.676 2.679 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 3.588,
    height: 3.659,
    viewBox: "0 0 3.588 3.659",
    fill: "none",
    style: {
      position: "absolute",
      left: 4.23,
      top: 1.425,
      width: 3.588,
      height: 3.659,
      color: "rgb(27,80,147)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 1.843 C 0 0.849 0.76 0 1.807 0 C 2.855 0 3.588 0.836 3.588 1.817 C 3.588 2.81 2.829 3.659 1.781 3.659 C 0.733 3.659 0 2.823 0 1.843 Z M 3.222 1.843 C 3.222 0.993 2.593 0.314 1.781 0.314 C 0.969 0.314 0.354 0.993 0.354 1.817 C 0.354 2.666 0.982 3.346 1.794 3.346 C 2.606 3.346 3.222 2.666 3.222 1.843 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 5.251,
    height: 3.529,
    viewBox: "0 0 5.251 3.529",
    fill: "none",
    style: {
      position: "absolute",
      left: 8.381,
      top: 1.49,
      width: 5.251,
      height: 3.529,
      color: "rgb(27,80,147)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 0.013 L 0.38 0.013 L 1.441 3.071 L 2.501 0 L 2.763 0 L 3.824 3.071 L 4.885 0.013 L 5.251 0.013 L 3.968 3.529 L 3.68 3.529 L 2.645 0.536 L 1.598 3.529 L 1.31 3.529 L 0.026 0.013 L 0 0.013 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 3.261,
    height: 3.646,
    viewBox: "0 0 3.261 3.646",
    fill: "none",
    style: {
      position: "absolute",
      left: 14.169,
      top: 1.425,
      width: 3.261,
      height: 3.646,
      color: "rgb(27,80,147)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 1.83 C 0 0.81 0.707 0 1.663 0 C 2.619 0 3.261 0.797 3.261 1.83 C 3.261 2.862 3.261 1.908 3.261 1.96 L 0.367 1.96 C 0.432 2.823 1.048 3.333 1.742 3.333 C 2.436 3.333 2.658 3.097 2.947 2.784 L 3.182 2.993 C 2.829 3.372 2.41 3.646 1.742 3.646 C 1.074 3.646 0.026 2.914 0.026 1.83 L 0 1.83 Z M 2.894 1.66 C 2.842 0.954 2.436 0.301 1.637 0.301 C 0.838 0.301 0.406 0.876 0.354 1.66 L 2.894 1.66 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 1.899,
    height: 3.530,
    viewBox: "0 0 1.899 3.530",
    fill: "none",
    style: {
      position: "absolute",
      left: 18.386,
      top: 1.45,
      width: 1.899,
      height: 3.53,
      color: "rgb(27,80,147)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0.013 0.053 L 0.354 0.053 L 0.354 1.047 C 0.629 0.419 1.205 -0.025 1.899 0.001 L 1.899 0.367 L 1.86 0.367 C 1.048 0.367 0.34 0.981 0.34 2.105 L 0.34 3.53 L 0 3.53 L 0 0.04 L 0.013 0.053 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 3.261,
    height: 3.646,
    viewBox: "0 0 3.261 3.646",
    fill: "none",
    style: {
      position: "absolute",
      left: 20.73,
      top: 1.425,
      width: 3.261,
      height: 3.646,
      color: "rgb(27,80,147)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 1.83 C 0 0.81 0.707 0 1.663 0 C 2.619 0 3.261 0.797 3.261 1.83 C 3.261 2.862 3.261 1.908 3.261 1.96 L 0.367 1.96 C 0.432 2.823 1.048 3.333 1.742 3.333 C 2.436 3.333 2.658 3.097 2.947 2.784 L 3.182 2.993 C 2.829 3.372 2.41 3.646 1.742 3.646 C 1.074 3.646 0.026 2.914 0.026 1.83 L 0 1.83 Z M 2.894 1.66 C 2.842 0.954 2.436 0.301 1.637 0.301 C 0.838 0.301 0.406 0.876 0.354 1.66 L 2.894 1.66 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 3.483,
    height: 5.071,
    viewBox: "0 0 3.483 5.071",
    fill: "none",
    style: {
      position: "absolute",
      left: 24.751,
      top: 0,
      width: 3.483,
      height: 5.071,
      color: "rgb(27,80,147)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 3.267 C 0 2.117 0.851 1.425 1.702 1.425 C 2.554 1.425 2.855 1.817 3.143 2.261 L 3.143 0 L 3.483 0 L 3.483 4.992 L 3.143 4.992 L 3.143 4.208 C 2.842 4.666 2.396 5.071 1.702 5.071 C 1.008 5.071 0 4.391 0 3.254 L 0 3.267 Z M 3.156 3.254 C 3.156 2.339 2.462 1.738 1.729 1.738 C 0.995 1.738 0.354 2.287 0.354 3.228 C 0.354 4.156 0.995 4.744 1.729 4.744 C 2.462 4.744 3.156 4.13 3.156 3.241 L 3.156 3.254 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 3.811,
    height: 4.783,
    viewBox: "0 0 3.811 4.783",
    fill: "none",
    style: {
      position: "absolute",
      left: 29.57,
      top: 0.209,
      width: 3.811,
      height: 4.783,
      color: "rgb(27,80,147)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 0 L 1.977 0 C 2.514 0 2.96 0.157 3.222 0.418 C 3.418 0.614 3.536 0.876 3.536 1.176 C 3.536 1.843 3.117 2.169 2.724 2.326 C 3.3 2.483 3.811 2.81 3.811 3.463 C 3.811 4.274 3.13 4.783 2.095 4.783 L 0.013 4.783 L 0.013 0 L 0 0 Z M 3.169 1.215 C 3.169 0.693 2.737 0.34 1.964 0.34 L 0.354 0.34 L 0.354 2.222 L 1.938 2.222 C 2.658 2.222 3.169 1.869 3.169 1.242 L 3.169 1.215 Z M 1.977 2.535 L 0.354 2.535 L 0.354 4.457 L 2.095 4.457 C 2.92 4.457 3.431 4.078 3.431 3.476 C 3.431 2.875 2.92 2.535 1.977 2.535 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 3.483,
    height: 4.600,
    viewBox: "0 0 3.483 4.600",
    fill: "none",
    style: {
      position: "absolute",
      left: 33.983,
      top: 1.503,
      width: 3.483,
      height: 4.6,
      color: "rgb(27,80,147)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 3.117 0 L 3.483 0 L 1.964 3.607 C 1.65 4.339 1.296 4.6 0.799 4.6 C 0.301 4.6 0.34 4.548 0.105 4.443 L 0.223 4.156 C 0.406 4.247 0.563 4.287 0.812 4.287 C 1.061 4.287 1.414 4.078 1.676 3.463 L 0 0 L 0.393 0 L 1.846 3.11 L 3.104 0 L 3.117 0 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 246,
      top: -87,
      width: 992.7,
      height: 221.9,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 378.2,
      top: 33.4,
      width: 546.2,
      height: 155.1,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 546.2000122070312,
      height: 155.10000610351562,
      clipPath: "inset(0px 0px 0px 0px)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 546.2,
      height: 155.1,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 546.2,
      height: 155.1,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: 46.800,
    height: 62.700,
    viewBox: "0 0 46.800 62.700",
    fill: "none",
    style: {
      position: "absolute",
      left: 487,
      top: 68.4,
      width: 46.8,
      height: 62.7,
      color: "rgb(18,132,175)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 46.4 0 L 0 0 L 0 62.7 L 46.8 62.7 L 46.8 52.9 L 11 52.9 L 11 36 L 42.3 36 L 42.3 26.2 L 11 26.2 L 11 9.9 L 46.4 9.9 L 46.4 0 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 546.2,
      height: 155.1,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 546.2000122070312,
      height: 155.10000610351562,
      clipPath: "inset(0px 0px 0px 0px)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 170,
      top: 23.586,
      width: 306.6,
      height: 108.516,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 306.6,
      height: 108.516,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: 48.600,
    height: 64.605,
    viewBox: "0 0 48.600 64.605",
    fill: "none",
    style: {
      position: "absolute",
      left: 258,
      top: 43.912,
      width: 48.6,
      height: 64.605,
      color: "rgb(18,132,175)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 13.6 17.303 C 13.6 13.103 17.4 9.803 23.8 9.803 C 30.2 9.803 35.2 12.003 40.8 16.203 L 46.7 7.903 C 40.3 2.603 32.2 -0.097 23.9 0.003 C 11.4 0.003 2.5 7.303 2.5 18.303 C 2.5 29.303 10 33.903 23.4 37.103 C 35 39.803 37.5 42.203 37.5 46.803 C 37.5 51.403 33.2 54.803 26.4 54.803 C 19.6 54.803 12.6 51.803 6.6 46.703 L 0 54.603 C 7.2 61.103 16.5 64.703 26.2 64.603 C 39.4 64.603 48.6 57.603 48.6 45.803 C 48.6 34.003 41.7 30.603 28.4 27.403 C 16.4 24.503 13.5 22.403 13.5 17.503 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 252.100,
    height: 64.605,
    viewBox: "0 0 252.100 64.605",
    fill: "none",
    style: {
      position: "absolute",
      left: 0,
      top: 43.912,
      width: 252.1,
      height: 64.605,
      color: "rgb(18,132,175)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 217 17.303 C 217 13.103 220.8 9.803 227.2 9.803 C 233.6 9.803 238.6 12.003 244.2 16.203 L 250.1 7.903 C 243.7 2.603 235.6 -0.097 227.4 0.003 C 214.9 0.003 206 7.303 206 18.303 C 206 29.303 213.5 33.903 226.9 37.103 C 238.5 39.803 241.1 42.203 241.1 46.803 C 241.1 51.403 236.8 54.803 230 54.803 C 223.2 54.803 216.2 51.803 210.2 46.703 L 203.6 54.603 C 210.8 61.103 220.1 64.703 229.7 64.603 C 242.9 64.603 252.1 57.603 252.1 45.803 C 252.1 34.003 245.2 30.603 232 27.403 C 220 24.503 217.1 22.403 217.1 17.503 Z M 195.3 0.903 L 148.9 0.903 L 148.9 63.603 L 195.8 63.603 L 195.8 53.703 L 159.9 53.703 L 159.9 36.903 L 191.3 36.903 L 191.3 27.003 L 159.9 27.003 L 159.9 10.703 L 195.3 10.703 L 195.3 0.803 L 195.3 0.903 Z M 126 44.303 L 92.4 0.903 L 82.2 0.903 L 82.2 63.603 L 93 63.603 L 93 19.003 L 127.6 63.603 L 136.8 63.603 L 136.8 0.903 L 126 0.903 L 126 44.303 Z M 58.8 63.603 L 69.8 63.603 L 69.8 0.903 L 58.8 0.903 L 58.8 63.603 Z M 46.7 0.903 L 0 0.903 L 0 63.603 L 11 63.603 L 11 38.103 L 42.6 38.103 L 42.6 28.103 L 11 28.103 L 11 11.003 L 46.7 11.003 L 46.7 1.003 L 46.7 0.903 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 283.100,
    height: 33.814,
    viewBox: "0 0 283.100 33.814",
    fill: "none",
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 283.1,
      height: 33.814,
      color: "rgb(0,82,145)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 260.1 33.214 L 283.1 33.214 L 283.1 28.014 L 265.9 28.014 L 265.9 0.514 L 260.1 0.514 L 260.1 33.214 Z M 240.4 20.214 L 229.1 20.214 L 234.7 7.114 L 240.4 20.214 Z M 237.5 0.214 L 232.2 0.214 L 217.8 33.114 L 223.7 33.114 L 227.1 25.314 L 242.6 25.314 L 245.9 33.214 L 252 33.214 L 237.6 0.214 L 237.5 0.214 Z M 203.9 33.114 L 209.6 33.114 L 209.6 0.514 L 203.9 0.514 L 203.9 33.114 Z M 195.9 27.914 L 192.2 24.214 C 189.4 26.814 186.8 28.514 182.8 28.514 C 176.5 28.514 172 23.314 172 16.814 C 172 10.314 176.5 5.214 182.8 5.214 C 189.1 5.214 189.3 6.814 192 9.314 L 195.7 5.114 C 192.3 1.714 187.7 -0.186 182.9 0.014 C 173.6 0.214 166.1 7.814 166.3 17.214 C 166.4 26.214 173.7 33.614 182.7 33.814 C 188.8 33.814 192.6 31.614 196 28.014 Z M 109.2 20.214 L 97.9 20.214 L 103.5 7.114 L 109.2 20.214 Z M 106.3 0.214 L 101 0.214 L 86.6 33.114 L 92.5 33.114 L 95.9 25.314 L 111.4 25.314 L 114.7 33.214 L 120.8 33.214 L 106.4 0.214 L 106.3 0.214 Z M 72.5 23.114 L 55 0.514 L 49.7 0.514 L 49.7 33.214 L 55.3 33.214 L 55.3 9.914 L 73.3 33.214 L 78.1 33.214 L 78.1 0.514 L 72.4 0.514 L 72.4 23.114 L 72.5 23.114 Z M 34.1 33.214 L 39.9 33.214 L 39.9 0.514 L 34.1 0.514 L 34.1 33.214 Z M 24.3 0.514 L 0 0.514 L 0 33.214 L 5.7 33.214 L 5.7 19.914 L 22.2 19.914 L 22.2 14.714 L 5.7 14.714 L 5.7 5.814 L 24.3 5.814 L 24.3 0.614 L 24.3 0.514 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 28.500,
    height: 32.700,
    viewBox: "0 0 28.500 32.700",
    fill: "none",
    style: {
      position: "absolute",
      left: 129,
      top: 0.514,
      width: 28.5,
      height: 32.7,
      color: "rgb(0,82,145)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 22.9 22.6 L 5.4 0 L 0 0 L 0 32.7 L 5.7 32.7 L 5.7 9.4 L 23.7 32.7 L 28.5 32.7 L 28.5 0 L 22.9 0 L 22.9 22.6 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })))))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 12.529,
      top: 14.2,
      width: 126.871,
      height: 126.906,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 126.87117767333984,
      height: 126.90603637695312,
      clipPath: "inset(0px 0px 0px 0px)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: -1.329,
      top: 0,
      width: 128.5,
      height: 127.3,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 128.5,
      height: 127.3,
      border: "1px dashed currentColor",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      overflow: "hidden",
      fontSize: 10,
      opacity: 0.45
    }
  }, "Vector")))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 12.529,
      top: 14.2,
      width: 126.871,
      height: 126.906,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 126.87117767333984,
      height: 126.90603637695312,
      clipPath: "inset(0px 0px 0px 0px)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: -1.329,
      top: 0,
      width: 128.5,
      height: 127.3,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 128.5,
      height: 127.3,
      border: "1px dashed currentColor",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      overflow: "hidden",
      fontSize: 10,
      opacity: 0.45
    }
  }, "Vector")))))))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 60.8,
      top: 89.1,
      width: 286.1,
      height: 46.7,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: 26.900,
    height: 36.600,
    viewBox: "0 0 26.900 36.600",
    fill: "none",
    style: {
      position: "absolute",
      left: 0,
      top: 1.6,
      width: 26.9,
      height: 36.6,
      color: "rgb(27,80,147)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 0 L 13.3 0 C 21.4 0 26.9 4.1 26.9 11.2 C 26.9 19 20.3 23 12.6 23 L 2.7 23 L 2.7 36.6 L 0 36.6 L 0 0 Z M 12.8 20.5 C 19.6 20.5 24.2 16.9 24.2 11.5 C 24.2 5.6 19.7 2.6 13.1 2.6 L 2.7 2.6 L 2.7 20.5 L 12.7 20.5 L 12.8 20.5 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 27.400,
    height: 28,
    viewBox: "0 0 27.400 28",
    fill: "none",
    style: {
      position: "absolute",
      left: 32.3,
      top: 10.9,
      width: 27.4,
      height: 28,
      color: "rgb(27,80,147)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 14.1 C 0 6.5 5.8 0 13.8 0 C 21.8 0 27.4 6.4 27.4 13.9 C 27.4 21.5 21.6 28 13.6 28 C 5.6 28 0 21.6 0 14.1 Z M 24.6 14.1 C 24.6 7.6 19.8 2.4 13.6 2.4 C 7.4 2.4 2.7 7.6 2.7 13.9 C 2.7 20.4 7.5 25.6 13.7 25.6 C 19.9 25.6 24.6 20.4 24.6 14.1 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 40.100,
    height: 27,
    viewBox: "0 0 40.100 27",
    fill: "none",
    style: {
      position: "absolute",
      left: 64,
      top: 11.4,
      width: 40.1,
      height: 27,
      color: "rgb(27,80,147)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 0.1 L 2.9 0.1 L 11 23.5 L 19.1 0 L 21.1 0 L 29.2 23.5 L 37.3 0.1 L 40.1 0.1 L 30.3 27 L 28.1 27 L 20.2 4.1 L 12.2 27 L 10 27 L 0.2 0.1 L 0 0.1 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 24.900,
    height: 27.900,
    viewBox: "0 0 24.900 27.900",
    fill: "none",
    style: {
      position: "absolute",
      left: 108.2,
      top: 10.9,
      width: 24.9,
      height: 27.9,
      color: "rgb(27,80,147)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 14 C 0 6.2 5.4 0 12.7 0 C 20 0 24.9 6.1 24.9 14 C 24.9 21.9 24.9 14.6 24.9 15 L 2.8 15 C 3.3 21.6 8 25.5 13.3 25.5 C 18.6 25.5 20.3 23.7 22.5 21.3 L 24.3 22.9 C 21.6 25.8 18.4 27.9 13.3 27.9 C 8.2 27.9 0.2 22.3 0.2 14 L 0 14 Z M 22.1 12.7 C 21.7 7.3 18.6 2.3 12.5 2.3 C 6.4 2.3 3.1 6.7 2.7 12.7 L 22.1 12.7 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 14.500,
    height: 27.008,
    viewBox: "0 0 14.500 27.008",
    fill: "none",
    style: {
      position: "absolute",
      left: 140.4,
      top: 11.092,
      width: 14.5,
      height: 27.008,
      color: "rgb(27,80,147)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0.1 0.408 L 2.7 0.408 L 2.7 8.008 C 4.8 3.208 9.2 -0.192 14.5 0.008 L 14.5 2.808 L 14.2 2.808 C 8 2.808 2.6 7.508 2.6 16.108 L 2.6 27.008 L 0 27.008 L 0 0.308 L 0.1 0.408 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 24.900,
    height: 27.900,
    viewBox: "0 0 24.900 27.900",
    fill: "none",
    style: {
      position: "absolute",
      left: 158.3,
      top: 10.9,
      width: 24.9,
      height: 27.9,
      color: "rgb(27,80,147)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 14 C 0 6.2 5.4 0 12.7 0 C 20 0 24.9 6.1 24.9 14 C 24.9 21.9 24.9 14.6 24.9 15 L 2.8 15 C 3.3 21.6 8 25.5 13.3 25.5 C 18.6 25.5 20.3 23.7 22.5 21.3 L 24.3 22.9 C 21.6 25.8 18.4 27.9 13.3 27.9 C 8.2 27.9 0.2 22.3 0.2 14 L 0 14 Z M 22.1 12.7 C 21.7 7.3 18.6 2.3 12.5 2.3 C 6.4 2.3 3.1 6.7 2.7 12.7 L 22.1 12.7 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 26.600,
    height: 38.800,
    viewBox: "0 0 26.600 38.800",
    fill: "none",
    style: {
      position: "absolute",
      left: 189,
      top: 0,
      width: 26.6,
      height: 38.8,
      color: "rgb(27,80,147)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 25 C 0 16.2 6.5 10.9 13 10.9 C 19.5 10.9 21.8 13.9 24 17.3 L 24 0 L 26.6 0 L 26.6 38.2 L 24 38.2 L 24 32.2 C 21.7 35.7 18.3 38.8 13 38.8 C 7.7 38.8 0 33.6 0 24.9 L 0 25 Z M 24.1 24.9 C 24.1 17.9 18.8 13.3 13.2 13.3 C 7.6 13.3 2.7 17.5 2.7 24.7 C 2.7 31.8 7.6 36.3 13.2 36.3 C 18.8 36.3 24.1 31.6 24.1 24.8 L 24.1 24.9 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 29.100,
    height: 36.600,
    viewBox: "0 0 29.100 36.600",
    fill: "none",
    style: {
      position: "absolute",
      left: 225.8,
      top: 1.6,
      width: 29.1,
      height: 36.6,
      color: "rgb(27,80,147)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 0 L 15.1 0 C 19.2 0 22.6 1.2 24.6 3.2 C 26.1 4.7 27 6.7 27 9 C 27 14.1 23.8 16.6 20.8 17.8 C 25.2 19 29.1 21.5 29.1 26.5 C 29.1 32.7 23.9 36.6 16 36.6 L 0.1 36.6 L 0.1 0 L 0 0 Z M 24.2 9.3 C 24.2 5.3 20.9 2.6 15 2.6 L 2.7 2.6 L 2.7 17 L 14.8 17 C 20.3 17 24.2 14.3 24.2 9.5 L 24.2 9.3 Z M 15.1 19.4 L 2.7 19.4 L 2.7 34.1 L 16 34.1 C 22.3 34.1 26.2 31.2 26.2 26.6 C 26.2 22 22.3 19.4 15.1 19.4 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })), /*#__PURE__*/React.createElement("svg", {
    width: 26.600,
    height: 35.200,
    viewBox: "0 0 26.600 35.200",
    fill: "none",
    style: {
      position: "absolute",
      left: 259.5,
      top: 11.5,
      width: 26.6,
      height: 35.2,
      color: "rgb(27,80,147)"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 23.8 0 L 26.6 0 L 15 27.6 C 12.6 33.2 9.9 35.2 6.1 35.2 C 2.3 35.2 2.6 34.8 0.8 34 L 1.7 31.8 C 3.1 32.5 4.3 32.8 6.2 32.8 C 8.1 32.8 10.8 31.2 12.8 26.5 L 0 0 L 3 0 L 14.1 23.8 L 23.7 0 L 23.8 0 Z",
    fill: "currentColor",
    fillRule: "evenodd"
  })))));
}
Object.assign(__ds_scope, { Component2, __ds_default_components_misc_Component2_1kwjkuy: Component2 });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/misc/Component2.jsx", error: String((e && e.message) || e) }); }

// components/misc/Group6832.jsx
try { (() => {
// figma node: 5832:15361 Group 6832
function Group6832(_p = {}) {
  const props = _p;
  return /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: 63,
      height: 18,
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      left: 22,
      top: 0,
      width: 41,
      height: 17,
      fontFamily: "Lato, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 900,
      fontSize: 14,
      lineHeight: "100%",
      color: "rgb(94,129,244)"
    }
  }, props.text1 ?? "Back"), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      width: 18,
      height: 18,
      fontFamily: "\"la-solid-900\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 18,
      textAlign: "center",
      whiteSpace: "nowrap",
      lineHeight: "100%",
      color: "rgb(94,129,244)"
    }
  }, props.text2 ?? ""));
}
Object.assign(__ds_scope, { Group6832, __ds_default_components_misc_Group6832_xims8l: Group6832 });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/misc/Group6832.jsx", error: String((e && e.message) || e) }); }

// components/misc/XYAsis.jsx
try { (() => {
// figma node: 2693:10138 XY-Asis (36 variants)
const __venc = v => String(v).replace(/[%|=]/g, encodeURIComponent);
const __vkey = p => "type=" + __venc(p.type) + '|' + "alignment=" + __venc(p.alignment) + '|' + "dash=" + __venc(p.dash) + '|' + "inverted=" + __venc(p.inverted) + '|' + "line=" + __venc(p.line);
function XYAsis(_p = {}) {
  const props = {
    ..._p,
    type: _p.type ?? "y-asis",
    alignment: _p.alignment ?? "bottom/left",
    dash: _p.dash ?? true,
    inverted: _p.inverted ?? true,
    line: _p.line ?? true
  };
  const __body0 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: "fit-content",
      height: 126,
      display: "flex",
      flexDirection: "column",
      gap: 16,
      justifyContent: "flex-end",
      alignItems: "flex-end",
      flexWrap: "nowrap",
      position: "relative",
      color: "rgb(225,228,237)",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: 1,
    viewBox: "-0.500 0 1 100",
    fill: "none",
    style: {
      position: "relative",
      width: 1,
      flexGrow: 1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0.5 0 C 0.5 -0.276 0.276 -0.5 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 L 0 0 L 0.5 0 Z M -0.5 100 C -0.5 100.276 -0.276 100.5 0 100.5 C 0.276 100.5 0.5 100.276 0.5 100 L 0 100 L -0.5 100 Z M 0 0 L -0.5 0 L -0.5 100 L 0 100 L 0.5 100 L 0.5 0 L 0 0 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      textAlign: "right",
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"));
  const __body1 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: 156,
      display: "flex",
      flexDirection: "row",
      gap: 16,
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      color: "rgb(225,228,237)",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      textAlign: "right",
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"), /*#__PURE__*/React.createElement("svg", {
    height: 1,
    viewBox: "0 -0.500 100 1",
    fill: "none",
    style: {
      position: "relative",
      height: 1,
      flexGrow: 1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 C -0.5 0.276 -0.276 0.5 0 0.5 L 0 0 L 0 -0.5 Z M 100 0.5 C 100.276 0.5 100.5 0.276 100.5 0 C 100.5 -0.276 100.276 -0.5 100 -0.5 L 100 0 L 100 0.5 Z M 0 0 L 0 0.5 L 100 0.5 L 100 0 L 100 -0.5 L 0 -0.5 L 0 0 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })));
  const __body2 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: 156,
      display: "flex",
      flexDirection: "row",
      gap: 16,
      alignItems: "center",
      flexWrap: "nowrap",
      position: "relative",
      color: "rgb(225,228,237)",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      textAlign: "right",
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"), /*#__PURE__*/React.createElement("svg", {
    height: 1,
    viewBox: "0 -0.500 100 1",
    fill: "none",
    style: {
      position: "relative",
      height: 1,
      flexGrow: 1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 C -0.5 0.276 -0.276 0.5 0 0.5 L 0 0 L 0 -0.5 Z M 100 0.5 C 100.276 0.5 100.5 0.276 100.5 0 C 100.5 -0.276 100.276 -0.5 100 -0.5 L 100 0 L 100 0.5 Z M 0 0 L 0 0.5 L 100 0.5 L 100 0 L 100 -0.5 L 0 -0.5 L 0 0 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })));
  const __body3 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: 156,
      display: "flex",
      flexDirection: "row",
      gap: 16,
      alignItems: "flex-end",
      flexWrap: "nowrap",
      position: "relative",
      color: "rgb(225,228,237)",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      textAlign: "right",
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"), /*#__PURE__*/React.createElement("svg", {
    height: 1,
    viewBox: "0 -0.500 100 1",
    fill: "none",
    style: {
      position: "relative",
      height: 1,
      flexGrow: 1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 C -0.5 0.276 -0.276 0.5 0 0.5 L 0 0 L 0 -0.5 Z M 100 0.5 C 100.276 0.5 100.5 0.276 100.5 0 C 100.5 -0.276 100.276 -0.5 100 -0.5 L 100 0 L 100 0.5 Z M 0 0 L 0 0.5 L 100 0.5 L 100 0 L 100 -0.5 L 0 -0.5 L 0 0 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })));
  const __body4 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: 156,
      display: "flex",
      flexDirection: "row",
      gap: 16,
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      textAlign: "right",
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      height: 1,
      flexGrow: 1,
      border: "1px dashed currentColor",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      overflow: "hidden",
      fontSize: 10,
      opacity: 0.45,
      width: 1
    }
  }, "Line"));
  const __body5 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: 156,
      display: "flex",
      flexDirection: "row",
      gap: 16,
      alignItems: "center",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      textAlign: "right",
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      height: 1,
      flexGrow: 1,
      border: "1px dashed currentColor",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      overflow: "hidden",
      fontSize: 10,
      opacity: 0.45,
      width: 1
    }
  }, "Line"));
  const __body6 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: 156,
      display: "flex",
      flexDirection: "row",
      gap: 16,
      alignItems: "flex-end",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      textAlign: "right",
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      height: 1,
      flexGrow: 1,
      border: "1px dashed currentColor",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      overflow: "hidden",
      fontSize: 10,
      opacity: 0.45,
      width: 1
    }
  }, "Line"));
  const __body7 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: 156,
      display: "flex",
      flexDirection: "row",
      gap: 16,
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      textAlign: "right",
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"), /*#__PURE__*/React.createElement("svg", {
    height: 1,
    viewBox: "0 -0.500 100 1",
    fill: "none",
    style: {
      position: "relative",
      height: 1,
      flexGrow: 1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 C -0.5 0.276 -0.276 0.5 0 0.5 L 0 0 L 0 -0.5 Z M 100 0.5 C 100.276 0.5 100.5 0.276 100.5 0 C 100.5 -0.276 100.276 -0.5 100 -0.5 L 100 0 L 100 0.5 Z M 2.02 0.5 C 2.296 0.5 2.52 0.276 2.52 0 C 2.52 -0.276 2.296 -0.5 2.02 -0.5 L 2.02 0 L 2.02 0.5 Z M 9.091 -0.5 C 8.815 -0.5 8.591 -0.276 8.591 0 C 8.591 0.276 8.815 0.5 9.091 0.5 L 9.091 0 L 9.091 -0.5 Z M 13.131 0.5 C 13.407 0.5 13.631 0.276 13.631 0 C 13.631 -0.276 13.407 -0.5 13.131 -0.5 L 13.131 0 L 13.131 0.5 Z M 20.202 -0.5 C 19.926 -0.5 19.702 -0.276 19.702 0 C 19.702 0.276 19.926 0.5 20.202 0.5 L 20.202 0 L 20.202 -0.5 Z M 24.242 0.5 C 24.519 0.5 24.742 0.276 24.742 0 C 24.742 -0.276 24.519 -0.5 24.242 -0.5 L 24.242 0 L 24.242 0.5 Z M 31.313 -0.5 C 31.037 -0.5 30.813 -0.276 30.813 0 C 30.813 0.276 31.037 0.5 31.313 0.5 L 31.313 0 L 31.313 -0.5 Z M 35.354 0.5 C 35.63 0.5 35.854 0.276 35.854 0 C 35.854 -0.276 35.63 -0.5 35.354 -0.5 L 35.354 0 L 35.354 0.5 Z M 42.424 -0.5 C 42.148 -0.5 41.924 -0.276 41.924 0 C 41.924 0.276 42.148 0.5 42.424 0.5 L 42.424 0 L 42.424 -0.5 Z M 46.465 0.5 C 46.741 0.5 46.965 0.276 46.965 0 C 46.965 -0.276 46.741 -0.5 46.465 -0.5 L 46.465 0 L 46.465 0.5 Z M 53.535 -0.5 C 53.259 -0.5 53.035 -0.276 53.035 0 C 53.035 0.276 53.259 0.5 53.535 0.5 L 53.535 0 L 53.535 -0.5 Z M 57.576 0.5 C 57.852 0.5 58.076 0.276 58.076 0 C 58.076 -0.276 57.852 -0.5 57.576 -0.5 L 57.576 0 L 57.576 0.5 Z M 64.646 -0.5 C 64.37 -0.5 64.146 -0.276 64.146 0 C 64.146 0.276 64.37 0.5 64.646 0.5 L 64.646 0 L 64.646 -0.5 Z M 68.687 0.5 C 68.963 0.5 69.187 0.276 69.187 0 C 69.187 -0.276 68.963 -0.5 68.687 -0.5 L 68.687 0 L 68.687 0.5 Z M 75.758 -0.5 C 75.481 -0.5 75.258 -0.276 75.258 0 C 75.258 0.276 75.481 0.5 75.758 0.5 L 75.758 0 L 75.758 -0.5 Z M 79.798 0.5 C 80.074 0.5 80.298 0.276 80.298 0 C 80.298 -0.276 80.074 -0.5 79.798 -0.5 L 79.798 0 L 79.798 0.5 Z M 86.869 -0.5 C 86.593 -0.5 86.369 -0.276 86.369 0 C 86.369 0.276 86.593 0.5 86.869 0.5 L 86.869 0 L 86.869 -0.5 Z M 90.909 0.5 C 91.185 0.5 91.409 0.276 91.409 0 C 91.409 -0.276 91.185 -0.5 90.909 -0.5 L 90.909 0 L 90.909 0.5 Z M 97.98 -0.5 C 97.704 -0.5 97.48 -0.276 97.48 0 C 97.48 0.276 97.704 0.5 97.98 0.5 L 97.98 0 L 97.98 -0.5 Z M 0 0 L 0 0.5 L 2.02 0.5 L 2.02 0 L 2.02 -0.5 L 0 -0.5 L 0 0 Z M 9.091 0 L 9.091 0.5 L 13.131 0.5 L 13.131 0 L 13.131 -0.5 L 9.091 -0.5 L 9.091 0 Z M 20.202 0 L 20.202 0.5 L 24.242 0.5 L 24.242 0 L 24.242 -0.5 L 20.202 -0.5 L 20.202 0 Z M 31.313 0 L 31.313 0.5 L 35.354 0.5 L 35.354 0 L 35.354 -0.5 L 31.313 -0.5 L 31.313 0 Z M 42.424 0 L 42.424 0.5 L 46.465 0.5 L 46.465 0 L 46.465 -0.5 L 42.424 -0.5 L 42.424 0 Z M 53.535 0 L 53.535 0.5 L 57.576 0.5 L 57.576 0 L 57.576 -0.5 L 53.535 -0.5 L 53.535 0 Z M 64.646 0 L 64.646 0.5 L 68.687 0.5 L 68.687 0 L 68.687 -0.5 L 64.646 -0.5 L 64.646 0 Z M 75.758 0 L 75.758 0.5 L 79.798 0.5 L 79.798 0 L 79.798 -0.5 L 75.758 -0.5 L 75.758 0 Z M 86.869 0 L 86.869 0.5 L 90.909 0.5 L 90.909 0 L 90.909 -0.5 L 86.869 -0.5 L 86.869 0 Z M 97.98 0 L 97.98 0.5 L 100 0.5 L 100 0 L 100 -0.5 L 97.98 -0.5 L 97.98 0 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })));
  const __body8 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: 156,
      display: "flex",
      flexDirection: "row",
      gap: 16,
      alignItems: "center",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      textAlign: "right",
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"), /*#__PURE__*/React.createElement("svg", {
    height: 1,
    viewBox: "0 -0.500 100 1",
    fill: "none",
    style: {
      position: "relative",
      height: 1,
      flexGrow: 1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 C -0.5 0.276 -0.276 0.5 0 0.5 L 0 0 L 0 -0.5 Z M 100 0.5 C 100.276 0.5 100.5 0.276 100.5 0 C 100.5 -0.276 100.276 -0.5 100 -0.5 L 100 0 L 100 0.5 Z M 2.02 0.5 C 2.296 0.5 2.52 0.276 2.52 0 C 2.52 -0.276 2.296 -0.5 2.02 -0.5 L 2.02 0 L 2.02 0.5 Z M 9.091 -0.5 C 8.815 -0.5 8.591 -0.276 8.591 0 C 8.591 0.276 8.815 0.5 9.091 0.5 L 9.091 0 L 9.091 -0.5 Z M 13.131 0.5 C 13.407 0.5 13.631 0.276 13.631 0 C 13.631 -0.276 13.407 -0.5 13.131 -0.5 L 13.131 0 L 13.131 0.5 Z M 20.202 -0.5 C 19.926 -0.5 19.702 -0.276 19.702 0 C 19.702 0.276 19.926 0.5 20.202 0.5 L 20.202 0 L 20.202 -0.5 Z M 24.242 0.5 C 24.519 0.5 24.742 0.276 24.742 0 C 24.742 -0.276 24.519 -0.5 24.242 -0.5 L 24.242 0 L 24.242 0.5 Z M 31.313 -0.5 C 31.037 -0.5 30.813 -0.276 30.813 0 C 30.813 0.276 31.037 0.5 31.313 0.5 L 31.313 0 L 31.313 -0.5 Z M 35.354 0.5 C 35.63 0.5 35.854 0.276 35.854 0 C 35.854 -0.276 35.63 -0.5 35.354 -0.5 L 35.354 0 L 35.354 0.5 Z M 42.424 -0.5 C 42.148 -0.5 41.924 -0.276 41.924 0 C 41.924 0.276 42.148 0.5 42.424 0.5 L 42.424 0 L 42.424 -0.5 Z M 46.465 0.5 C 46.741 0.5 46.965 0.276 46.965 0 C 46.965 -0.276 46.741 -0.5 46.465 -0.5 L 46.465 0 L 46.465 0.5 Z M 53.535 -0.5 C 53.259 -0.5 53.035 -0.276 53.035 0 C 53.035 0.276 53.259 0.5 53.535 0.5 L 53.535 0 L 53.535 -0.5 Z M 57.576 0.5 C 57.852 0.5 58.076 0.276 58.076 0 C 58.076 -0.276 57.852 -0.5 57.576 -0.5 L 57.576 0 L 57.576 0.5 Z M 64.646 -0.5 C 64.37 -0.5 64.146 -0.276 64.146 0 C 64.146 0.276 64.37 0.5 64.646 0.5 L 64.646 0 L 64.646 -0.5 Z M 68.687 0.5 C 68.963 0.5 69.187 0.276 69.187 0 C 69.187 -0.276 68.963 -0.5 68.687 -0.5 L 68.687 0 L 68.687 0.5 Z M 75.758 -0.5 C 75.481 -0.5 75.258 -0.276 75.258 0 C 75.258 0.276 75.481 0.5 75.758 0.5 L 75.758 0 L 75.758 -0.5 Z M 79.798 0.5 C 80.074 0.5 80.298 0.276 80.298 0 C 80.298 -0.276 80.074 -0.5 79.798 -0.5 L 79.798 0 L 79.798 0.5 Z M 86.869 -0.5 C 86.593 -0.5 86.369 -0.276 86.369 0 C 86.369 0.276 86.593 0.5 86.869 0.5 L 86.869 0 L 86.869 -0.5 Z M 90.909 0.5 C 91.185 0.5 91.409 0.276 91.409 0 C 91.409 -0.276 91.185 -0.5 90.909 -0.5 L 90.909 0 L 90.909 0.5 Z M 97.98 -0.5 C 97.704 -0.5 97.48 -0.276 97.48 0 C 97.48 0.276 97.704 0.5 97.98 0.5 L 97.98 0 L 97.98 -0.5 Z M 0 0 L 0 0.5 L 2.02 0.5 L 2.02 0 L 2.02 -0.5 L 0 -0.5 L 0 0 Z M 9.091 0 L 9.091 0.5 L 13.131 0.5 L 13.131 0 L 13.131 -0.5 L 9.091 -0.5 L 9.091 0 Z M 20.202 0 L 20.202 0.5 L 24.242 0.5 L 24.242 0 L 24.242 -0.5 L 20.202 -0.5 L 20.202 0 Z M 31.313 0 L 31.313 0.5 L 35.354 0.5 L 35.354 0 L 35.354 -0.5 L 31.313 -0.5 L 31.313 0 Z M 42.424 0 L 42.424 0.5 L 46.465 0.5 L 46.465 0 L 46.465 -0.5 L 42.424 -0.5 L 42.424 0 Z M 53.535 0 L 53.535 0.5 L 57.576 0.5 L 57.576 0 L 57.576 -0.5 L 53.535 -0.5 L 53.535 0 Z M 64.646 0 L 64.646 0.5 L 68.687 0.5 L 68.687 0 L 68.687 -0.5 L 64.646 -0.5 L 64.646 0 Z M 75.758 0 L 75.758 0.5 L 79.798 0.5 L 79.798 0 L 79.798 -0.5 L 75.758 -0.5 L 75.758 0 Z M 86.869 0 L 86.869 0.5 L 90.909 0.5 L 90.909 0 L 90.909 -0.5 L 86.869 -0.5 L 86.869 0 Z M 97.98 0 L 97.98 0.5 L 100 0.5 L 100 0 L 100 -0.5 L 97.98 -0.5 L 97.98 0 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })));
  const __body9 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: 156,
      display: "flex",
      flexDirection: "row",
      gap: 16,
      alignItems: "flex-end",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      textAlign: "right",
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"), /*#__PURE__*/React.createElement("svg", {
    height: 1,
    viewBox: "0 -0.500 100 1",
    fill: "none",
    style: {
      position: "relative",
      height: 1,
      flexGrow: 1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 C -0.5 0.276 -0.276 0.5 0 0.5 L 0 0 L 0 -0.5 Z M 100 0.5 C 100.276 0.5 100.5 0.276 100.5 0 C 100.5 -0.276 100.276 -0.5 100 -0.5 L 100 0 L 100 0.5 Z M 2.02 0.5 C 2.296 0.5 2.52 0.276 2.52 0 C 2.52 -0.276 2.296 -0.5 2.02 -0.5 L 2.02 0 L 2.02 0.5 Z M 9.091 -0.5 C 8.815 -0.5 8.591 -0.276 8.591 0 C 8.591 0.276 8.815 0.5 9.091 0.5 L 9.091 0 L 9.091 -0.5 Z M 13.131 0.5 C 13.407 0.5 13.631 0.276 13.631 0 C 13.631 -0.276 13.407 -0.5 13.131 -0.5 L 13.131 0 L 13.131 0.5 Z M 20.202 -0.5 C 19.926 -0.5 19.702 -0.276 19.702 0 C 19.702 0.276 19.926 0.5 20.202 0.5 L 20.202 0 L 20.202 -0.5 Z M 24.242 0.5 C 24.519 0.5 24.742 0.276 24.742 0 C 24.742 -0.276 24.519 -0.5 24.242 -0.5 L 24.242 0 L 24.242 0.5 Z M 31.313 -0.5 C 31.037 -0.5 30.813 -0.276 30.813 0 C 30.813 0.276 31.037 0.5 31.313 0.5 L 31.313 0 L 31.313 -0.5 Z M 35.354 0.5 C 35.63 0.5 35.854 0.276 35.854 0 C 35.854 -0.276 35.63 -0.5 35.354 -0.5 L 35.354 0 L 35.354 0.5 Z M 42.424 -0.5 C 42.148 -0.5 41.924 -0.276 41.924 0 C 41.924 0.276 42.148 0.5 42.424 0.5 L 42.424 0 L 42.424 -0.5 Z M 46.465 0.5 C 46.741 0.5 46.965 0.276 46.965 0 C 46.965 -0.276 46.741 -0.5 46.465 -0.5 L 46.465 0 L 46.465 0.5 Z M 53.535 -0.5 C 53.259 -0.5 53.035 -0.276 53.035 0 C 53.035 0.276 53.259 0.5 53.535 0.5 L 53.535 0 L 53.535 -0.5 Z M 57.576 0.5 C 57.852 0.5 58.076 0.276 58.076 0 C 58.076 -0.276 57.852 -0.5 57.576 -0.5 L 57.576 0 L 57.576 0.5 Z M 64.646 -0.5 C 64.37 -0.5 64.146 -0.276 64.146 0 C 64.146 0.276 64.37 0.5 64.646 0.5 L 64.646 0 L 64.646 -0.5 Z M 68.687 0.5 C 68.963 0.5 69.187 0.276 69.187 0 C 69.187 -0.276 68.963 -0.5 68.687 -0.5 L 68.687 0 L 68.687 0.5 Z M 75.758 -0.5 C 75.481 -0.5 75.258 -0.276 75.258 0 C 75.258 0.276 75.481 0.5 75.758 0.5 L 75.758 0 L 75.758 -0.5 Z M 79.798 0.5 C 80.074 0.5 80.298 0.276 80.298 0 C 80.298 -0.276 80.074 -0.5 79.798 -0.5 L 79.798 0 L 79.798 0.5 Z M 86.869 -0.5 C 86.593 -0.5 86.369 -0.276 86.369 0 C 86.369 0.276 86.593 0.5 86.869 0.5 L 86.869 0 L 86.869 -0.5 Z M 90.909 0.5 C 91.185 0.5 91.409 0.276 91.409 0 C 91.409 -0.276 91.185 -0.5 90.909 -0.5 L 90.909 0 L 90.909 0.5 Z M 97.98 -0.5 C 97.704 -0.5 97.48 -0.276 97.48 0 C 97.48 0.276 97.704 0.5 97.98 0.5 L 97.98 0 L 97.98 -0.5 Z M 0 0 L 0 0.5 L 2.02 0.5 L 2.02 0 L 2.02 -0.5 L 0 -0.5 L 0 0 Z M 9.091 0 L 9.091 0.5 L 13.131 0.5 L 13.131 0 L 13.131 -0.5 L 9.091 -0.5 L 9.091 0 Z M 20.202 0 L 20.202 0.5 L 24.242 0.5 L 24.242 0 L 24.242 -0.5 L 20.202 -0.5 L 20.202 0 Z M 31.313 0 L 31.313 0.5 L 35.354 0.5 L 35.354 0 L 35.354 -0.5 L 31.313 -0.5 L 31.313 0 Z M 42.424 0 L 42.424 0.5 L 46.465 0.5 L 46.465 0 L 46.465 -0.5 L 42.424 -0.5 L 42.424 0 Z M 53.535 0 L 53.535 0.5 L 57.576 0.5 L 57.576 0 L 57.576 -0.5 L 53.535 -0.5 L 53.535 0 Z M 64.646 0 L 64.646 0.5 L 68.687 0.5 L 68.687 0 L 68.687 -0.5 L 64.646 -0.5 L 64.646 0 Z M 75.758 0 L 75.758 0.5 L 79.798 0.5 L 79.798 0 L 79.798 -0.5 L 75.758 -0.5 L 75.758 0 Z M 86.869 0 L 86.869 0.5 L 90.909 0.5 L 90.909 0 L 90.909 -0.5 L 86.869 -0.5 L 86.869 0 Z M 97.98 0 L 97.98 0.5 L 100 0.5 L 100 0 L 100 -0.5 L 97.98 -0.5 L 97.98 0 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })));
  const __body10 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: "fit-content",
      height: 126,
      display: "flex",
      flexDirection: "column",
      gap: 16,
      justifyContent: "flex-end",
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      color: "rgb(225,228,237)",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: 1,
    viewBox: "-0.500 0 1 100",
    fill: "none",
    style: {
      position: "relative",
      width: 1,
      flexGrow: 1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0.5 0 C 0.5 -0.276 0.276 -0.5 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 L 0 0 L 0.5 0 Z M -0.5 100 C -0.5 100.276 -0.276 100.5 0 100.5 C 0.276 100.5 0.5 100.276 0.5 100 L 0 100 L -0.5 100 Z M 0 0 L -0.5 0 L -0.5 100 L 0 100 L 0.5 100 L 0.5 0 L 0 0 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"));
  const __body11 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: "fit-content",
      height: 126,
      display: "flex",
      flexDirection: "column",
      gap: 16,
      justifyContent: "flex-end",
      alignItems: "center",
      flexWrap: "nowrap",
      position: "relative",
      color: "rgb(225,228,237)",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: 1,
    viewBox: "-0.500 0 1 100",
    fill: "none",
    style: {
      position: "relative",
      width: 1,
      flexGrow: 1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0.5 0 C 0.5 -0.276 0.276 -0.5 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 L 0 0 L 0.5 0 Z M -0.5 100 C -0.5 100.276 -0.276 100.5 0 100.5 C 0.276 100.5 0.5 100.276 0.5 100 L 0 100 L -0.5 100 Z M 0 0 L -0.5 0 L -0.5 100 L 0 100 L 0.5 100 L 0.5 0 L 0 0 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      textAlign: "center",
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"));
  const __body12 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: "fit-content",
      height: 126,
      display: "flex",
      flexDirection: "column",
      gap: 16,
      justifyContent: "flex-end",
      alignItems: "flex-end",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      width: 1,
      flexGrow: 1,
      border: "1px dashed currentColor",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      overflow: "hidden",
      fontSize: 10,
      opacity: 0.45,
      height: 1
    }
  }, "Line"), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      textAlign: "right",
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"));
  const __body13 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: "fit-content",
      height: 126,
      display: "flex",
      flexDirection: "column",
      gap: 16,
      justifyContent: "flex-end",
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      width: 1,
      flexGrow: 1,
      border: "1px dashed currentColor",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      overflow: "hidden",
      fontSize: 10,
      opacity: 0.45,
      height: 1
    }
  }, "Line"), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"));
  const __body14 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: "fit-content",
      height: 126,
      display: "flex",
      flexDirection: "column",
      gap: 16,
      justifyContent: "flex-end",
      alignItems: "center",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      width: 1,
      flexGrow: 1,
      border: "1px dashed currentColor",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      overflow: "hidden",
      fontSize: 10,
      opacity: 0.45,
      height: 1
    }
  }, "Line"), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      textAlign: "center",
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"));
  const __body15 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: "fit-content",
      height: 126,
      display: "flex",
      flexDirection: "column",
      gap: 16,
      justifyContent: "flex-end",
      alignItems: "flex-end",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: 1,
    viewBox: "-0.500 0 1 100",
    fill: "none",
    style: {
      position: "relative",
      width: 1,
      flexGrow: 1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0.5 0 C 0.5 -0.276 0.276 -0.5 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 L 0 0 L 0.5 0 Z M -0.5 100 C -0.5 100.276 -0.276 100.5 0 100.5 C 0.276 100.5 0.5 100.276 0.5 100 L 0 100 L -0.5 100 Z M -0.5 2.02 C -0.5 2.296 -0.276 2.52 0 2.52 C 0.276 2.52 0.5 2.296 0.5 2.02 L 0 2.02 L -0.5 2.02 Z M 0.5 9.091 C 0.5 8.815 0.276 8.591 0 8.591 C -0.276 8.591 -0.5 8.815 -0.5 9.091 L 0 9.091 L 0.5 9.091 Z M -0.5 13.131 C -0.5 13.407 -0.276 13.631 0 13.631 C 0.276 13.631 0.5 13.407 0.5 13.131 L 0 13.131 L -0.5 13.131 Z M 0.5 20.202 C 0.5 19.926 0.276 19.702 0 19.702 C -0.276 19.702 -0.5 19.926 -0.5 20.202 L 0 20.202 L 0.5 20.202 Z M -0.5 24.242 C -0.5 24.519 -0.276 24.742 0 24.742 C 0.276 24.742 0.5 24.519 0.5 24.242 L 0 24.242 L -0.5 24.242 Z M 0.5 31.313 C 0.5 31.037 0.276 30.813 0 30.813 C -0.276 30.813 -0.5 31.037 -0.5 31.313 L 0 31.313 L 0.5 31.313 Z M -0.5 35.354 C -0.5 35.63 -0.276 35.854 0 35.854 C 0.276 35.854 0.5 35.63 0.5 35.354 L 0 35.354 L -0.5 35.354 Z M 0.5 42.424 C 0.5 42.148 0.276 41.924 0 41.924 C -0.276 41.924 -0.5 42.148 -0.5 42.424 L 0 42.424 L 0.5 42.424 Z M -0.5 46.465 C -0.5 46.741 -0.276 46.965 0 46.965 C 0.276 46.965 0.5 46.741 0.5 46.465 L 0 46.465 L -0.5 46.465 Z M 0.5 53.535 C 0.5 53.259 0.276 53.035 0 53.035 C -0.276 53.035 -0.5 53.259 -0.5 53.535 L 0 53.535 L 0.5 53.535 Z M -0.5 57.576 C -0.5 57.852 -0.276 58.076 0 58.076 C 0.276 58.076 0.5 57.852 0.5 57.576 L 0 57.576 L -0.5 57.576 Z M 0.5 64.646 C 0.5 64.37 0.276 64.146 0 64.146 C -0.276 64.146 -0.5 64.37 -0.5 64.646 L 0 64.646 L 0.5 64.646 Z M -0.5 68.687 C -0.5 68.963 -0.276 69.187 0 69.187 C 0.276 69.187 0.5 68.963 0.5 68.687 L 0 68.687 L -0.5 68.687 Z M 0.5 75.758 C 0.5 75.481 0.276 75.258 0 75.258 C -0.276 75.258 -0.5 75.481 -0.5 75.758 L 0 75.758 L 0.5 75.758 Z M -0.5 79.798 C -0.5 80.074 -0.276 80.298 0 80.298 C 0.276 80.298 0.5 80.074 0.5 79.798 L 0 79.798 L -0.5 79.798 Z M 0.5 86.869 C 0.5 86.593 0.276 86.369 0 86.369 C -0.276 86.369 -0.5 86.593 -0.5 86.869 L 0 86.869 L 0.5 86.869 Z M -0.5 90.909 C -0.5 91.185 -0.276 91.409 0 91.409 C 0.276 91.409 0.5 91.185 0.5 90.909 L 0 90.909 L -0.5 90.909 Z M 0.5 97.98 C 0.5 97.704 0.276 97.48 0 97.48 C -0.276 97.48 -0.5 97.704 -0.5 97.98 L 0 97.98 L 0.5 97.98 Z M 0 0 L -0.5 0 L -0.5 2.02 L 0 2.02 L 0.5 2.02 L 0.5 0 L 0 0 Z M 0 9.091 L -0.5 9.091 L -0.5 13.131 L 0 13.131 L 0.5 13.131 L 0.5 9.091 L 0 9.091 Z M 0 20.202 L -0.5 20.202 L -0.5 24.242 L 0 24.242 L 0.5 24.242 L 0.5 20.202 L 0 20.202 Z M 0 31.313 L -0.5 31.313 L -0.5 35.354 L 0 35.354 L 0.5 35.354 L 0.5 31.313 L 0 31.313 Z M 0 42.424 L -0.5 42.424 L -0.5 46.465 L 0 46.465 L 0.5 46.465 L 0.5 42.424 L 0 42.424 Z M 0 53.535 L -0.5 53.535 L -0.5 57.576 L 0 57.576 L 0.5 57.576 L 0.5 53.535 L 0 53.535 Z M 0 64.646 L -0.5 64.646 L -0.5 68.687 L 0 68.687 L 0.5 68.687 L 0.5 64.646 L 0 64.646 Z M 0 75.758 L -0.5 75.758 L -0.5 79.798 L 0 79.798 L 0.5 79.798 L 0.5 75.758 L 0 75.758 Z M 0 86.869 L -0.5 86.869 L -0.5 90.909 L 0 90.909 L 0.5 90.909 L 0.5 86.869 L 0 86.869 Z M 0 97.98 L -0.5 97.98 L -0.5 100 L 0 100 L 0.5 100 L 0.5 97.98 L 0 97.98 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      textAlign: "right",
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"));
  const __body16 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: "fit-content",
      height: 126,
      display: "flex",
      flexDirection: "column",
      gap: 16,
      justifyContent: "flex-end",
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: 1,
    viewBox: "-0.500 0 1 100",
    fill: "none",
    style: {
      position: "relative",
      width: 1,
      flexGrow: 1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0.5 0 C 0.5 -0.276 0.276 -0.5 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 L 0 0 L 0.5 0 Z M -0.5 100 C -0.5 100.276 -0.276 100.5 0 100.5 C 0.276 100.5 0.5 100.276 0.5 100 L 0 100 L -0.5 100 Z M -0.5 2.02 C -0.5 2.296 -0.276 2.52 0 2.52 C 0.276 2.52 0.5 2.296 0.5 2.02 L 0 2.02 L -0.5 2.02 Z M 0.5 9.091 C 0.5 8.815 0.276 8.591 0 8.591 C -0.276 8.591 -0.5 8.815 -0.5 9.091 L 0 9.091 L 0.5 9.091 Z M -0.5 13.131 C -0.5 13.407 -0.276 13.631 0 13.631 C 0.276 13.631 0.5 13.407 0.5 13.131 L 0 13.131 L -0.5 13.131 Z M 0.5 20.202 C 0.5 19.926 0.276 19.702 0 19.702 C -0.276 19.702 -0.5 19.926 -0.5 20.202 L 0 20.202 L 0.5 20.202 Z M -0.5 24.242 C -0.5 24.519 -0.276 24.742 0 24.742 C 0.276 24.742 0.5 24.519 0.5 24.242 L 0 24.242 L -0.5 24.242 Z M 0.5 31.313 C 0.5 31.037 0.276 30.813 0 30.813 C -0.276 30.813 -0.5 31.037 -0.5 31.313 L 0 31.313 L 0.5 31.313 Z M -0.5 35.354 C -0.5 35.63 -0.276 35.854 0 35.854 C 0.276 35.854 0.5 35.63 0.5 35.354 L 0 35.354 L -0.5 35.354 Z M 0.5 42.424 C 0.5 42.148 0.276 41.924 0 41.924 C -0.276 41.924 -0.5 42.148 -0.5 42.424 L 0 42.424 L 0.5 42.424 Z M -0.5 46.465 C -0.5 46.741 -0.276 46.965 0 46.965 C 0.276 46.965 0.5 46.741 0.5 46.465 L 0 46.465 L -0.5 46.465 Z M 0.5 53.535 C 0.5 53.259 0.276 53.035 0 53.035 C -0.276 53.035 -0.5 53.259 -0.5 53.535 L 0 53.535 L 0.5 53.535 Z M -0.5 57.576 C -0.5 57.852 -0.276 58.076 0 58.076 C 0.276 58.076 0.5 57.852 0.5 57.576 L 0 57.576 L -0.5 57.576 Z M 0.5 64.646 C 0.5 64.37 0.276 64.146 0 64.146 C -0.276 64.146 -0.5 64.37 -0.5 64.646 L 0 64.646 L 0.5 64.646 Z M -0.5 68.687 C -0.5 68.963 -0.276 69.187 0 69.187 C 0.276 69.187 0.5 68.963 0.5 68.687 L 0 68.687 L -0.5 68.687 Z M 0.5 75.758 C 0.5 75.481 0.276 75.258 0 75.258 C -0.276 75.258 -0.5 75.481 -0.5 75.758 L 0 75.758 L 0.5 75.758 Z M -0.5 79.798 C -0.5 80.074 -0.276 80.298 0 80.298 C 0.276 80.298 0.5 80.074 0.5 79.798 L 0 79.798 L -0.5 79.798 Z M 0.5 86.869 C 0.5 86.593 0.276 86.369 0 86.369 C -0.276 86.369 -0.5 86.593 -0.5 86.869 L 0 86.869 L 0.5 86.869 Z M -0.5 90.909 C -0.5 91.185 -0.276 91.409 0 91.409 C 0.276 91.409 0.5 91.185 0.5 90.909 L 0 90.909 L -0.5 90.909 Z M 0.5 97.98 C 0.5 97.704 0.276 97.48 0 97.48 C -0.276 97.48 -0.5 97.704 -0.5 97.98 L 0 97.98 L 0.5 97.98 Z M 0 0 L -0.5 0 L -0.5 2.02 L 0 2.02 L 0.5 2.02 L 0.5 0 L 0 0 Z M 0 9.091 L -0.5 9.091 L -0.5 13.131 L 0 13.131 L 0.5 13.131 L 0.5 9.091 L 0 9.091 Z M 0 20.202 L -0.5 20.202 L -0.5 24.242 L 0 24.242 L 0.5 24.242 L 0.5 20.202 L 0 20.202 Z M 0 31.313 L -0.5 31.313 L -0.5 35.354 L 0 35.354 L 0.5 35.354 L 0.5 31.313 L 0 31.313 Z M 0 42.424 L -0.5 42.424 L -0.5 46.465 L 0 46.465 L 0.5 46.465 L 0.5 42.424 L 0 42.424 Z M 0 53.535 L -0.5 53.535 L -0.5 57.576 L 0 57.576 L 0.5 57.576 L 0.5 53.535 L 0 53.535 Z M 0 64.646 L -0.5 64.646 L -0.5 68.687 L 0 68.687 L 0.5 68.687 L 0.5 64.646 L 0 64.646 Z M 0 75.758 L -0.5 75.758 L -0.5 79.798 L 0 79.798 L 0.5 79.798 L 0.5 75.758 L 0 75.758 Z M 0 86.869 L -0.5 86.869 L -0.5 90.909 L 0 90.909 L 0.5 90.909 L 0.5 86.869 L 0 86.869 Z M 0 97.98 L -0.5 97.98 L -0.5 100 L 0 100 L 0.5 100 L 0.5 97.98 L 0 97.98 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"));
  const __body17 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: "fit-content",
      height: 126,
      display: "flex",
      flexDirection: "column",
      gap: 16,
      justifyContent: "flex-end",
      alignItems: "center",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: 1,
    viewBox: "-0.500 0 1 100",
    fill: "none",
    style: {
      position: "relative",
      width: 1,
      flexGrow: 1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0.5 0 C 0.5 -0.276 0.276 -0.5 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 L 0 0 L 0.5 0 Z M -0.5 100 C -0.5 100.276 -0.276 100.5 0 100.5 C 0.276 100.5 0.5 100.276 0.5 100 L 0 100 L -0.5 100 Z M -0.5 2.02 C -0.5 2.296 -0.276 2.52 0 2.52 C 0.276 2.52 0.5 2.296 0.5 2.02 L 0 2.02 L -0.5 2.02 Z M 0.5 9.091 C 0.5 8.815 0.276 8.591 0 8.591 C -0.276 8.591 -0.5 8.815 -0.5 9.091 L 0 9.091 L 0.5 9.091 Z M -0.5 13.131 C -0.5 13.407 -0.276 13.631 0 13.631 C 0.276 13.631 0.5 13.407 0.5 13.131 L 0 13.131 L -0.5 13.131 Z M 0.5 20.202 C 0.5 19.926 0.276 19.702 0 19.702 C -0.276 19.702 -0.5 19.926 -0.5 20.202 L 0 20.202 L 0.5 20.202 Z M -0.5 24.242 C -0.5 24.519 -0.276 24.742 0 24.742 C 0.276 24.742 0.5 24.519 0.5 24.242 L 0 24.242 L -0.5 24.242 Z M 0.5 31.313 C 0.5 31.037 0.276 30.813 0 30.813 C -0.276 30.813 -0.5 31.037 -0.5 31.313 L 0 31.313 L 0.5 31.313 Z M -0.5 35.354 C -0.5 35.63 -0.276 35.854 0 35.854 C 0.276 35.854 0.5 35.63 0.5 35.354 L 0 35.354 L -0.5 35.354 Z M 0.5 42.424 C 0.5 42.148 0.276 41.924 0 41.924 C -0.276 41.924 -0.5 42.148 -0.5 42.424 L 0 42.424 L 0.5 42.424 Z M -0.5 46.465 C -0.5 46.741 -0.276 46.965 0 46.965 C 0.276 46.965 0.5 46.741 0.5 46.465 L 0 46.465 L -0.5 46.465 Z M 0.5 53.535 C 0.5 53.259 0.276 53.035 0 53.035 C -0.276 53.035 -0.5 53.259 -0.5 53.535 L 0 53.535 L 0.5 53.535 Z M -0.5 57.576 C -0.5 57.852 -0.276 58.076 0 58.076 C 0.276 58.076 0.5 57.852 0.5 57.576 L 0 57.576 L -0.5 57.576 Z M 0.5 64.646 C 0.5 64.37 0.276 64.146 0 64.146 C -0.276 64.146 -0.5 64.37 -0.5 64.646 L 0 64.646 L 0.5 64.646 Z M -0.5 68.687 C -0.5 68.963 -0.276 69.187 0 69.187 C 0.276 69.187 0.5 68.963 0.5 68.687 L 0 68.687 L -0.5 68.687 Z M 0.5 75.758 C 0.5 75.481 0.276 75.258 0 75.258 C -0.276 75.258 -0.5 75.481 -0.5 75.758 L 0 75.758 L 0.5 75.758 Z M -0.5 79.798 C -0.5 80.074 -0.276 80.298 0 80.298 C 0.276 80.298 0.5 80.074 0.5 79.798 L 0 79.798 L -0.5 79.798 Z M 0.5 86.869 C 0.5 86.593 0.276 86.369 0 86.369 C -0.276 86.369 -0.5 86.593 -0.5 86.869 L 0 86.869 L 0.5 86.869 Z M -0.5 90.909 C -0.5 91.185 -0.276 91.409 0 91.409 C 0.276 91.409 0.5 91.185 0.5 90.909 L 0 90.909 L -0.5 90.909 Z M 0.5 97.98 C 0.5 97.704 0.276 97.48 0 97.48 C -0.276 97.48 -0.5 97.704 -0.5 97.98 L 0 97.98 L 0.5 97.98 Z M 0 0 L -0.5 0 L -0.5 2.02 L 0 2.02 L 0.5 2.02 L 0.5 0 L 0 0 Z M 0 9.091 L -0.5 9.091 L -0.5 13.131 L 0 13.131 L 0.5 13.131 L 0.5 9.091 L 0 9.091 Z M 0 20.202 L -0.5 20.202 L -0.5 24.242 L 0 24.242 L 0.5 24.242 L 0.5 20.202 L 0 20.202 Z M 0 31.313 L -0.5 31.313 L -0.5 35.354 L 0 35.354 L 0.5 35.354 L 0.5 31.313 L 0 31.313 Z M 0 42.424 L -0.5 42.424 L -0.5 46.465 L 0 46.465 L 0.5 46.465 L 0.5 42.424 L 0 42.424 Z M 0 53.535 L -0.5 53.535 L -0.5 57.576 L 0 57.576 L 0.5 57.576 L 0.5 53.535 L 0 53.535 Z M 0 64.646 L -0.5 64.646 L -0.5 68.687 L 0 68.687 L 0.5 68.687 L 0.5 64.646 L 0 64.646 Z M 0 75.758 L -0.5 75.758 L -0.5 79.798 L 0 79.798 L 0.5 79.798 L 0.5 75.758 L 0 75.758 Z M 0 86.869 L -0.5 86.869 L -0.5 90.909 L 0 90.909 L 0.5 90.909 L 0.5 86.869 L 0 86.869 Z M 0 97.98 L -0.5 97.98 L -0.5 100 L 0 100 L 0.5 100 L 0.5 97.98 L 0 97.98 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      textAlign: "center",
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"));
  const __body18 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: 156,
      display: "flex",
      flexDirection: "row",
      gap: 16,
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      color: "rgb(225,228,237)",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("svg", {
    height: 1,
    viewBox: "0 -0.500 100 1",
    fill: "none",
    style: {
      position: "relative",
      height: 1,
      flexGrow: 1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 C -0.5 0.276 -0.276 0.5 0 0.5 L 0 0 L 0 -0.5 Z M 100 0.5 C 100.276 0.5 100.5 0.276 100.5 0 C 100.5 -0.276 100.276 -0.5 100 -0.5 L 100 0 L 100 0.5 Z M 0 0 L 0 0.5 L 100 0.5 L 100 0 L 100 -0.5 L 0 -0.5 L 0 0 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"));
  const __body19 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: 156,
      display: "flex",
      flexDirection: "row",
      gap: 16,
      alignItems: "center",
      flexWrap: "nowrap",
      position: "relative",
      color: "rgb(225,228,237)",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("svg", {
    height: 1,
    viewBox: "0 -0.500 100 1",
    fill: "none",
    style: {
      position: "relative",
      height: 1,
      flexGrow: 1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 C -0.5 0.276 -0.276 0.5 0 0.5 L 0 0 L 0 -0.5 Z M 100 0.5 C 100.276 0.5 100.5 0.276 100.5 0 C 100.5 -0.276 100.276 -0.5 100 -0.5 L 100 0 L 100 0.5 Z M 0 0 L 0 0.5 L 100 0.5 L 100 0 L 100 -0.5 L 0 -0.5 L 0 0 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"));
  const __body20 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: 156,
      display: "flex",
      flexDirection: "row",
      gap: 16,
      alignItems: "flex-end",
      flexWrap: "nowrap",
      position: "relative",
      color: "rgb(225,228,237)",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("svg", {
    height: 1,
    viewBox: "0 -0.500 100 1",
    fill: "none",
    style: {
      position: "relative",
      height: 1,
      flexGrow: 1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 C -0.5 0.276 -0.276 0.5 0 0.5 L 0 0 L 0 -0.5 Z M 100 0.5 C 100.276 0.5 100.5 0.276 100.5 0 C 100.5 -0.276 100.276 -0.5 100 -0.5 L 100 0 L 100 0.5 Z M 0 0 L 0 0.5 L 100 0.5 L 100 0 L 100 -0.5 L 0 -0.5 L 0 0 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"));
  const __body21 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: 156,
      display: "flex",
      flexDirection: "row",
      gap: 16,
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      height: 1,
      flexGrow: 1,
      border: "1px dashed currentColor",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      overflow: "hidden",
      fontSize: 10,
      opacity: 0.45,
      width: 1
    }
  }, "Line"), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"));
  const __body22 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: 156,
      display: "flex",
      flexDirection: "row",
      gap: 16,
      alignItems: "center",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      height: 1,
      flexGrow: 1,
      border: "1px dashed currentColor",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      overflow: "hidden",
      fontSize: 10,
      opacity: 0.45,
      width: 1
    }
  }, "Line"), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"));
  const __body23 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: 156,
      display: "flex",
      flexDirection: "row",
      gap: 16,
      alignItems: "flex-end",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      height: 1,
      flexGrow: 1,
      border: "1px dashed currentColor",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      overflow: "hidden",
      fontSize: 10,
      opacity: 0.45,
      width: 1
    }
  }, "Line"), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"));
  const __body24 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: 156,
      display: "flex",
      flexDirection: "row",
      gap: 16,
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("svg", {
    height: 1,
    viewBox: "0 -0.500 100 1",
    fill: "none",
    style: {
      position: "relative",
      height: 1,
      flexGrow: 1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 C -0.5 0.276 -0.276 0.5 0 0.5 L 0 0 L 0 -0.5 Z M 100 0.5 C 100.276 0.5 100.5 0.276 100.5 0 C 100.5 -0.276 100.276 -0.5 100 -0.5 L 100 0 L 100 0.5 Z M 2.02 0.5 C 2.296 0.5 2.52 0.276 2.52 0 C 2.52 -0.276 2.296 -0.5 2.02 -0.5 L 2.02 0 L 2.02 0.5 Z M 9.091 -0.5 C 8.815 -0.5 8.591 -0.276 8.591 0 C 8.591 0.276 8.815 0.5 9.091 0.5 L 9.091 0 L 9.091 -0.5 Z M 13.131 0.5 C 13.407 0.5 13.631 0.276 13.631 0 C 13.631 -0.276 13.407 -0.5 13.131 -0.5 L 13.131 0 L 13.131 0.5 Z M 20.202 -0.5 C 19.926 -0.5 19.702 -0.276 19.702 0 C 19.702 0.276 19.926 0.5 20.202 0.5 L 20.202 0 L 20.202 -0.5 Z M 24.242 0.5 C 24.519 0.5 24.742 0.276 24.742 0 C 24.742 -0.276 24.519 -0.5 24.242 -0.5 L 24.242 0 L 24.242 0.5 Z M 31.313 -0.5 C 31.037 -0.5 30.813 -0.276 30.813 0 C 30.813 0.276 31.037 0.5 31.313 0.5 L 31.313 0 L 31.313 -0.5 Z M 35.354 0.5 C 35.63 0.5 35.854 0.276 35.854 0 C 35.854 -0.276 35.63 -0.5 35.354 -0.5 L 35.354 0 L 35.354 0.5 Z M 42.424 -0.5 C 42.148 -0.5 41.924 -0.276 41.924 0 C 41.924 0.276 42.148 0.5 42.424 0.5 L 42.424 0 L 42.424 -0.5 Z M 46.465 0.5 C 46.741 0.5 46.965 0.276 46.965 0 C 46.965 -0.276 46.741 -0.5 46.465 -0.5 L 46.465 0 L 46.465 0.5 Z M 53.535 -0.5 C 53.259 -0.5 53.035 -0.276 53.035 0 C 53.035 0.276 53.259 0.5 53.535 0.5 L 53.535 0 L 53.535 -0.5 Z M 57.576 0.5 C 57.852 0.5 58.076 0.276 58.076 0 C 58.076 -0.276 57.852 -0.5 57.576 -0.5 L 57.576 0 L 57.576 0.5 Z M 64.646 -0.5 C 64.37 -0.5 64.146 -0.276 64.146 0 C 64.146 0.276 64.37 0.5 64.646 0.5 L 64.646 0 L 64.646 -0.5 Z M 68.687 0.5 C 68.963 0.5 69.187 0.276 69.187 0 C 69.187 -0.276 68.963 -0.5 68.687 -0.5 L 68.687 0 L 68.687 0.5 Z M 75.758 -0.5 C 75.481 -0.5 75.258 -0.276 75.258 0 C 75.258 0.276 75.481 0.5 75.758 0.5 L 75.758 0 L 75.758 -0.5 Z M 79.798 0.5 C 80.074 0.5 80.298 0.276 80.298 0 C 80.298 -0.276 80.074 -0.5 79.798 -0.5 L 79.798 0 L 79.798 0.5 Z M 86.869 -0.5 C 86.593 -0.5 86.369 -0.276 86.369 0 C 86.369 0.276 86.593 0.5 86.869 0.5 L 86.869 0 L 86.869 -0.5 Z M 90.909 0.5 C 91.185 0.5 91.409 0.276 91.409 0 C 91.409 -0.276 91.185 -0.5 90.909 -0.5 L 90.909 0 L 90.909 0.5 Z M 97.98 -0.5 C 97.704 -0.5 97.48 -0.276 97.48 0 C 97.48 0.276 97.704 0.5 97.98 0.5 L 97.98 0 L 97.98 -0.5 Z M 0 0 L 0 0.5 L 2.02 0.5 L 2.02 0 L 2.02 -0.5 L 0 -0.5 L 0 0 Z M 9.091 0 L 9.091 0.5 L 13.131 0.5 L 13.131 0 L 13.131 -0.5 L 9.091 -0.5 L 9.091 0 Z M 20.202 0 L 20.202 0.5 L 24.242 0.5 L 24.242 0 L 24.242 -0.5 L 20.202 -0.5 L 20.202 0 Z M 31.313 0 L 31.313 0.5 L 35.354 0.5 L 35.354 0 L 35.354 -0.5 L 31.313 -0.5 L 31.313 0 Z M 42.424 0 L 42.424 0.5 L 46.465 0.5 L 46.465 0 L 46.465 -0.5 L 42.424 -0.5 L 42.424 0 Z M 53.535 0 L 53.535 0.5 L 57.576 0.5 L 57.576 0 L 57.576 -0.5 L 53.535 -0.5 L 53.535 0 Z M 64.646 0 L 64.646 0.5 L 68.687 0.5 L 68.687 0 L 68.687 -0.5 L 64.646 -0.5 L 64.646 0 Z M 75.758 0 L 75.758 0.5 L 79.798 0.5 L 79.798 0 L 79.798 -0.5 L 75.758 -0.5 L 75.758 0 Z M 86.869 0 L 86.869 0.5 L 90.909 0.5 L 90.909 0 L 90.909 -0.5 L 86.869 -0.5 L 86.869 0 Z M 97.98 0 L 97.98 0.5 L 100 0.5 L 100 0 L 100 -0.5 L 97.98 -0.5 L 97.98 0 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"));
  const __body25 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: 156,
      display: "flex",
      flexDirection: "row",
      gap: 16,
      alignItems: "center",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("svg", {
    height: 1,
    viewBox: "0 -0.500 100 1",
    fill: "none",
    style: {
      position: "relative",
      height: 1,
      flexGrow: 1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 C -0.5 0.276 -0.276 0.5 0 0.5 L 0 0 L 0 -0.5 Z M 100 0.5 C 100.276 0.5 100.5 0.276 100.5 0 C 100.5 -0.276 100.276 -0.5 100 -0.5 L 100 0 L 100 0.5 Z M 2.02 0.5 C 2.296 0.5 2.52 0.276 2.52 0 C 2.52 -0.276 2.296 -0.5 2.02 -0.5 L 2.02 0 L 2.02 0.5 Z M 9.091 -0.5 C 8.815 -0.5 8.591 -0.276 8.591 0 C 8.591 0.276 8.815 0.5 9.091 0.5 L 9.091 0 L 9.091 -0.5 Z M 13.131 0.5 C 13.407 0.5 13.631 0.276 13.631 0 C 13.631 -0.276 13.407 -0.5 13.131 -0.5 L 13.131 0 L 13.131 0.5 Z M 20.202 -0.5 C 19.926 -0.5 19.702 -0.276 19.702 0 C 19.702 0.276 19.926 0.5 20.202 0.5 L 20.202 0 L 20.202 -0.5 Z M 24.242 0.5 C 24.519 0.5 24.742 0.276 24.742 0 C 24.742 -0.276 24.519 -0.5 24.242 -0.5 L 24.242 0 L 24.242 0.5 Z M 31.313 -0.5 C 31.037 -0.5 30.813 -0.276 30.813 0 C 30.813 0.276 31.037 0.5 31.313 0.5 L 31.313 0 L 31.313 -0.5 Z M 35.354 0.5 C 35.63 0.5 35.854 0.276 35.854 0 C 35.854 -0.276 35.63 -0.5 35.354 -0.5 L 35.354 0 L 35.354 0.5 Z M 42.424 -0.5 C 42.148 -0.5 41.924 -0.276 41.924 0 C 41.924 0.276 42.148 0.5 42.424 0.5 L 42.424 0 L 42.424 -0.5 Z M 46.465 0.5 C 46.741 0.5 46.965 0.276 46.965 0 C 46.965 -0.276 46.741 -0.5 46.465 -0.5 L 46.465 0 L 46.465 0.5 Z M 53.535 -0.5 C 53.259 -0.5 53.035 -0.276 53.035 0 C 53.035 0.276 53.259 0.5 53.535 0.5 L 53.535 0 L 53.535 -0.5 Z M 57.576 0.5 C 57.852 0.5 58.076 0.276 58.076 0 C 58.076 -0.276 57.852 -0.5 57.576 -0.5 L 57.576 0 L 57.576 0.5 Z M 64.646 -0.5 C 64.37 -0.5 64.146 -0.276 64.146 0 C 64.146 0.276 64.37 0.5 64.646 0.5 L 64.646 0 L 64.646 -0.5 Z M 68.687 0.5 C 68.963 0.5 69.187 0.276 69.187 0 C 69.187 -0.276 68.963 -0.5 68.687 -0.5 L 68.687 0 L 68.687 0.5 Z M 75.758 -0.5 C 75.481 -0.5 75.258 -0.276 75.258 0 C 75.258 0.276 75.481 0.5 75.758 0.5 L 75.758 0 L 75.758 -0.5 Z M 79.798 0.5 C 80.074 0.5 80.298 0.276 80.298 0 C 80.298 -0.276 80.074 -0.5 79.798 -0.5 L 79.798 0 L 79.798 0.5 Z M 86.869 -0.5 C 86.593 -0.5 86.369 -0.276 86.369 0 C 86.369 0.276 86.593 0.5 86.869 0.5 L 86.869 0 L 86.869 -0.5 Z M 90.909 0.5 C 91.185 0.5 91.409 0.276 91.409 0 C 91.409 -0.276 91.185 -0.5 90.909 -0.5 L 90.909 0 L 90.909 0.5 Z M 97.98 -0.5 C 97.704 -0.5 97.48 -0.276 97.48 0 C 97.48 0.276 97.704 0.5 97.98 0.5 L 97.98 0 L 97.98 -0.5 Z M 0 0 L 0 0.5 L 2.02 0.5 L 2.02 0 L 2.02 -0.5 L 0 -0.5 L 0 0 Z M 9.091 0 L 9.091 0.5 L 13.131 0.5 L 13.131 0 L 13.131 -0.5 L 9.091 -0.5 L 9.091 0 Z M 20.202 0 L 20.202 0.5 L 24.242 0.5 L 24.242 0 L 24.242 -0.5 L 20.202 -0.5 L 20.202 0 Z M 31.313 0 L 31.313 0.5 L 35.354 0.5 L 35.354 0 L 35.354 -0.5 L 31.313 -0.5 L 31.313 0 Z M 42.424 0 L 42.424 0.5 L 46.465 0.5 L 46.465 0 L 46.465 -0.5 L 42.424 -0.5 L 42.424 0 Z M 53.535 0 L 53.535 0.5 L 57.576 0.5 L 57.576 0 L 57.576 -0.5 L 53.535 -0.5 L 53.535 0 Z M 64.646 0 L 64.646 0.5 L 68.687 0.5 L 68.687 0 L 68.687 -0.5 L 64.646 -0.5 L 64.646 0 Z M 75.758 0 L 75.758 0.5 L 79.798 0.5 L 79.798 0 L 79.798 -0.5 L 75.758 -0.5 L 75.758 0 Z M 86.869 0 L 86.869 0.5 L 90.909 0.5 L 90.909 0 L 90.909 -0.5 L 86.869 -0.5 L 86.869 0 Z M 97.98 0 L 97.98 0.5 L 100 0.5 L 100 0 L 100 -0.5 L 97.98 -0.5 L 97.98 0 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"));
  const __body26 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: 156,
      display: "flex",
      flexDirection: "row",
      gap: 16,
      alignItems: "flex-end",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("svg", {
    height: 1,
    viewBox: "0 -0.500 100 1",
    fill: "none",
    style: {
      position: "relative",
      height: 1,
      flexGrow: 1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 C -0.5 0.276 -0.276 0.5 0 0.5 L 0 0 L 0 -0.5 Z M 100 0.5 C 100.276 0.5 100.5 0.276 100.5 0 C 100.5 -0.276 100.276 -0.5 100 -0.5 L 100 0 L 100 0.5 Z M 2.02 0.5 C 2.296 0.5 2.52 0.276 2.52 0 C 2.52 -0.276 2.296 -0.5 2.02 -0.5 L 2.02 0 L 2.02 0.5 Z M 9.091 -0.5 C 8.815 -0.5 8.591 -0.276 8.591 0 C 8.591 0.276 8.815 0.5 9.091 0.5 L 9.091 0 L 9.091 -0.5 Z M 13.131 0.5 C 13.407 0.5 13.631 0.276 13.631 0 C 13.631 -0.276 13.407 -0.5 13.131 -0.5 L 13.131 0 L 13.131 0.5 Z M 20.202 -0.5 C 19.926 -0.5 19.702 -0.276 19.702 0 C 19.702 0.276 19.926 0.5 20.202 0.5 L 20.202 0 L 20.202 -0.5 Z M 24.242 0.5 C 24.519 0.5 24.742 0.276 24.742 0 C 24.742 -0.276 24.519 -0.5 24.242 -0.5 L 24.242 0 L 24.242 0.5 Z M 31.313 -0.5 C 31.037 -0.5 30.813 -0.276 30.813 0 C 30.813 0.276 31.037 0.5 31.313 0.5 L 31.313 0 L 31.313 -0.5 Z M 35.354 0.5 C 35.63 0.5 35.854 0.276 35.854 0 C 35.854 -0.276 35.63 -0.5 35.354 -0.5 L 35.354 0 L 35.354 0.5 Z M 42.424 -0.5 C 42.148 -0.5 41.924 -0.276 41.924 0 C 41.924 0.276 42.148 0.5 42.424 0.5 L 42.424 0 L 42.424 -0.5 Z M 46.465 0.5 C 46.741 0.5 46.965 0.276 46.965 0 C 46.965 -0.276 46.741 -0.5 46.465 -0.5 L 46.465 0 L 46.465 0.5 Z M 53.535 -0.5 C 53.259 -0.5 53.035 -0.276 53.035 0 C 53.035 0.276 53.259 0.5 53.535 0.5 L 53.535 0 L 53.535 -0.5 Z M 57.576 0.5 C 57.852 0.5 58.076 0.276 58.076 0 C 58.076 -0.276 57.852 -0.5 57.576 -0.5 L 57.576 0 L 57.576 0.5 Z M 64.646 -0.5 C 64.37 -0.5 64.146 -0.276 64.146 0 C 64.146 0.276 64.37 0.5 64.646 0.5 L 64.646 0 L 64.646 -0.5 Z M 68.687 0.5 C 68.963 0.5 69.187 0.276 69.187 0 C 69.187 -0.276 68.963 -0.5 68.687 -0.5 L 68.687 0 L 68.687 0.5 Z M 75.758 -0.5 C 75.481 -0.5 75.258 -0.276 75.258 0 C 75.258 0.276 75.481 0.5 75.758 0.5 L 75.758 0 L 75.758 -0.5 Z M 79.798 0.5 C 80.074 0.5 80.298 0.276 80.298 0 C 80.298 -0.276 80.074 -0.5 79.798 -0.5 L 79.798 0 L 79.798 0.5 Z M 86.869 -0.5 C 86.593 -0.5 86.369 -0.276 86.369 0 C 86.369 0.276 86.593 0.5 86.869 0.5 L 86.869 0 L 86.869 -0.5 Z M 90.909 0.5 C 91.185 0.5 91.409 0.276 91.409 0 C 91.409 -0.276 91.185 -0.5 90.909 -0.5 L 90.909 0 L 90.909 0.5 Z M 97.98 -0.5 C 97.704 -0.5 97.48 -0.276 97.48 0 C 97.48 0.276 97.704 0.5 97.98 0.5 L 97.98 0 L 97.98 -0.5 Z M 0 0 L 0 0.5 L 2.02 0.5 L 2.02 0 L 2.02 -0.5 L 0 -0.5 L 0 0 Z M 9.091 0 L 9.091 0.5 L 13.131 0.5 L 13.131 0 L 13.131 -0.5 L 9.091 -0.5 L 9.091 0 Z M 20.202 0 L 20.202 0.5 L 24.242 0.5 L 24.242 0 L 24.242 -0.5 L 20.202 -0.5 L 20.202 0 Z M 31.313 0 L 31.313 0.5 L 35.354 0.5 L 35.354 0 L 35.354 -0.5 L 31.313 -0.5 L 31.313 0 Z M 42.424 0 L 42.424 0.5 L 46.465 0.5 L 46.465 0 L 46.465 -0.5 L 42.424 -0.5 L 42.424 0 Z M 53.535 0 L 53.535 0.5 L 57.576 0.5 L 57.576 0 L 57.576 -0.5 L 53.535 -0.5 L 53.535 0 Z M 64.646 0 L 64.646 0.5 L 68.687 0.5 L 68.687 0 L 68.687 -0.5 L 64.646 -0.5 L 64.646 0 Z M 75.758 0 L 75.758 0.5 L 79.798 0.5 L 79.798 0 L 79.798 -0.5 L 75.758 -0.5 L 75.758 0 Z M 86.869 0 L 86.869 0.5 L 90.909 0.5 L 90.909 0 L 90.909 -0.5 L 86.869 -0.5 L 86.869 0 Z M 97.98 0 L 97.98 0.5 L 100 0.5 L 100 0 L 100 -0.5 L 97.98 -0.5 L 97.98 0 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"));
  const __body27 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: "fit-content",
      height: 126,
      display: "flex",
      flexDirection: "column",
      gap: 16,
      justifyContent: "flex-end",
      alignItems: "flex-end",
      flexWrap: "nowrap",
      position: "relative",
      color: "rgb(225,228,237)",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      textAlign: "right",
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"), /*#__PURE__*/React.createElement("svg", {
    width: 1,
    viewBox: "-0.500 0 1 100",
    fill: "none",
    style: {
      position: "relative",
      width: 1,
      flexGrow: 1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0.5 0 C 0.5 -0.276 0.276 -0.5 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 L 0 0 L 0.5 0 Z M -0.5 100 C -0.5 100.276 -0.276 100.5 0 100.5 C 0.276 100.5 0.5 100.276 0.5 100 L 0 100 L -0.5 100 Z M 0 0 L -0.5 0 L -0.5 100 L 0 100 L 0.5 100 L 0.5 0 L 0 0 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })));
  const __body28 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: "fit-content",
      height: 126,
      display: "flex",
      flexDirection: "column",
      gap: 16,
      justifyContent: "flex-end",
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      color: "rgb(225,228,237)",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"), /*#__PURE__*/React.createElement("svg", {
    width: 1,
    viewBox: "-0.500 0 1 100",
    fill: "none",
    style: {
      position: "relative",
      width: 1,
      flexGrow: 1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0.5 0 C 0.5 -0.276 0.276 -0.5 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 L 0 0 L 0.5 0 Z M -0.5 100 C -0.5 100.276 -0.276 100.5 0 100.5 C 0.276 100.5 0.5 100.276 0.5 100 L 0 100 L -0.5 100 Z M 0 0 L -0.5 0 L -0.5 100 L 0 100 L 0.5 100 L 0.5 0 L 0 0 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })));
  const __body29 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: "fit-content",
      height: 126,
      display: "flex",
      flexDirection: "column",
      gap: 16,
      justifyContent: "flex-end",
      alignItems: "center",
      flexWrap: "nowrap",
      position: "relative",
      color: "rgb(225,228,237)",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      textAlign: "center",
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"), /*#__PURE__*/React.createElement("svg", {
    width: 1,
    viewBox: "-0.500 0 1 100",
    fill: "none",
    style: {
      position: "relative",
      width: 1,
      flexGrow: 1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0.5 0 C 0.5 -0.276 0.276 -0.5 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 L 0 0 L 0.5 0 Z M -0.5 100 C -0.5 100.276 -0.276 100.5 0 100.5 C 0.276 100.5 0.5 100.276 0.5 100 L 0 100 L -0.5 100 Z M 0 0 L -0.5 0 L -0.5 100 L 0 100 L 0.5 100 L 0.5 0 L 0 0 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })));
  const __body30 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: "fit-content",
      height: 126,
      display: "flex",
      flexDirection: "column",
      gap: 16,
      justifyContent: "flex-end",
      alignItems: "flex-end",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      textAlign: "right",
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      width: 1,
      flexGrow: 1,
      border: "1px dashed currentColor",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      overflow: "hidden",
      fontSize: 10,
      opacity: 0.45,
      height: 1
    }
  }, "Line"));
  const __body31 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: "fit-content",
      height: 126,
      display: "flex",
      flexDirection: "column",
      gap: 16,
      justifyContent: "flex-end",
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      width: 1,
      flexGrow: 1,
      border: "1px dashed currentColor",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      overflow: "hidden",
      fontSize: 10,
      opacity: 0.45,
      height: 1
    }
  }, "Line"));
  const __body32 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: "fit-content",
      height: 126,
      display: "flex",
      flexDirection: "column",
      gap: 16,
      justifyContent: "flex-end",
      alignItems: "center",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      textAlign: "center",
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      width: 1,
      flexGrow: 1,
      border: "1px dashed currentColor",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      overflow: "hidden",
      fontSize: 10,
      opacity: 0.45,
      height: 1
    }
  }, "Line"));
  const __body33 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: "fit-content",
      height: 126,
      display: "flex",
      flexDirection: "column",
      gap: 16,
      justifyContent: "flex-end",
      alignItems: "flex-end",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      textAlign: "right",
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"), /*#__PURE__*/React.createElement("svg", {
    width: 1,
    viewBox: "-0.500 0 1 100",
    fill: "none",
    style: {
      position: "relative",
      width: 1,
      flexGrow: 1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0.5 0 C 0.5 -0.276 0.276 -0.5 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 L 0 0 L 0.5 0 Z M -0.5 100 C -0.5 100.276 -0.276 100.5 0 100.5 C 0.276 100.5 0.5 100.276 0.5 100 L 0 100 L -0.5 100 Z M -0.5 2.02 C -0.5 2.296 -0.276 2.52 0 2.52 C 0.276 2.52 0.5 2.296 0.5 2.02 L 0 2.02 L -0.5 2.02 Z M 0.5 9.091 C 0.5 8.815 0.276 8.591 0 8.591 C -0.276 8.591 -0.5 8.815 -0.5 9.091 L 0 9.091 L 0.5 9.091 Z M -0.5 13.131 C -0.5 13.407 -0.276 13.631 0 13.631 C 0.276 13.631 0.5 13.407 0.5 13.131 L 0 13.131 L -0.5 13.131 Z M 0.5 20.202 C 0.5 19.926 0.276 19.702 0 19.702 C -0.276 19.702 -0.5 19.926 -0.5 20.202 L 0 20.202 L 0.5 20.202 Z M -0.5 24.242 C -0.5 24.519 -0.276 24.742 0 24.742 C 0.276 24.742 0.5 24.519 0.5 24.242 L 0 24.242 L -0.5 24.242 Z M 0.5 31.313 C 0.5 31.037 0.276 30.813 0 30.813 C -0.276 30.813 -0.5 31.037 -0.5 31.313 L 0 31.313 L 0.5 31.313 Z M -0.5 35.354 C -0.5 35.63 -0.276 35.854 0 35.854 C 0.276 35.854 0.5 35.63 0.5 35.354 L 0 35.354 L -0.5 35.354 Z M 0.5 42.424 C 0.5 42.148 0.276 41.924 0 41.924 C -0.276 41.924 -0.5 42.148 -0.5 42.424 L 0 42.424 L 0.5 42.424 Z M -0.5 46.465 C -0.5 46.741 -0.276 46.965 0 46.965 C 0.276 46.965 0.5 46.741 0.5 46.465 L 0 46.465 L -0.5 46.465 Z M 0.5 53.535 C 0.5 53.259 0.276 53.035 0 53.035 C -0.276 53.035 -0.5 53.259 -0.5 53.535 L 0 53.535 L 0.5 53.535 Z M -0.5 57.576 C -0.5 57.852 -0.276 58.076 0 58.076 C 0.276 58.076 0.5 57.852 0.5 57.576 L 0 57.576 L -0.5 57.576 Z M 0.5 64.646 C 0.5 64.37 0.276 64.146 0 64.146 C -0.276 64.146 -0.5 64.37 -0.5 64.646 L 0 64.646 L 0.5 64.646 Z M -0.5 68.687 C -0.5 68.963 -0.276 69.187 0 69.187 C 0.276 69.187 0.5 68.963 0.5 68.687 L 0 68.687 L -0.5 68.687 Z M 0.5 75.758 C 0.5 75.481 0.276 75.258 0 75.258 C -0.276 75.258 -0.5 75.481 -0.5 75.758 L 0 75.758 L 0.5 75.758 Z M -0.5 79.798 C -0.5 80.074 -0.276 80.298 0 80.298 C 0.276 80.298 0.5 80.074 0.5 79.798 L 0 79.798 L -0.5 79.798 Z M 0.5 86.869 C 0.5 86.593 0.276 86.369 0 86.369 C -0.276 86.369 -0.5 86.593 -0.5 86.869 L 0 86.869 L 0.5 86.869 Z M -0.5 90.909 C -0.5 91.185 -0.276 91.409 0 91.409 C 0.276 91.409 0.5 91.185 0.5 90.909 L 0 90.909 L -0.5 90.909 Z M 0.5 97.98 C 0.5 97.704 0.276 97.48 0 97.48 C -0.276 97.48 -0.5 97.704 -0.5 97.98 L 0 97.98 L 0.5 97.98 Z M 0 0 L -0.5 0 L -0.5 2.02 L 0 2.02 L 0.5 2.02 L 0.5 0 L 0 0 Z M 0 9.091 L -0.5 9.091 L -0.5 13.131 L 0 13.131 L 0.5 13.131 L 0.5 9.091 L 0 9.091 Z M 0 20.202 L -0.5 20.202 L -0.5 24.242 L 0 24.242 L 0.5 24.242 L 0.5 20.202 L 0 20.202 Z M 0 31.313 L -0.5 31.313 L -0.5 35.354 L 0 35.354 L 0.5 35.354 L 0.5 31.313 L 0 31.313 Z M 0 42.424 L -0.5 42.424 L -0.5 46.465 L 0 46.465 L 0.5 46.465 L 0.5 42.424 L 0 42.424 Z M 0 53.535 L -0.5 53.535 L -0.5 57.576 L 0 57.576 L 0.5 57.576 L 0.5 53.535 L 0 53.535 Z M 0 64.646 L -0.5 64.646 L -0.5 68.687 L 0 68.687 L 0.5 68.687 L 0.5 64.646 L 0 64.646 Z M 0 75.758 L -0.5 75.758 L -0.5 79.798 L 0 79.798 L 0.5 79.798 L 0.5 75.758 L 0 75.758 Z M 0 86.869 L -0.5 86.869 L -0.5 90.909 L 0 90.909 L 0.5 90.909 L 0.5 86.869 L 0 86.869 Z M 0 97.98 L -0.5 97.98 L -0.5 100 L 0 100 L 0.5 100 L 0.5 97.98 L 0 97.98 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })));
  const __body34 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: "fit-content",
      height: 126,
      display: "flex",
      flexDirection: "column",
      gap: 16,
      justifyContent: "flex-end",
      alignItems: "flex-start",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"), /*#__PURE__*/React.createElement("svg", {
    width: 1,
    viewBox: "-0.500 0 1 100",
    fill: "none",
    style: {
      position: "relative",
      width: 1,
      flexGrow: 1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0.5 0 C 0.5 -0.276 0.276 -0.5 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 L 0 0 L 0.5 0 Z M -0.5 100 C -0.5 100.276 -0.276 100.5 0 100.5 C 0.276 100.5 0.5 100.276 0.5 100 L 0 100 L -0.5 100 Z M -0.5 2.02 C -0.5 2.296 -0.276 2.52 0 2.52 C 0.276 2.52 0.5 2.296 0.5 2.02 L 0 2.02 L -0.5 2.02 Z M 0.5 9.091 C 0.5 8.815 0.276 8.591 0 8.591 C -0.276 8.591 -0.5 8.815 -0.5 9.091 L 0 9.091 L 0.5 9.091 Z M -0.5 13.131 C -0.5 13.407 -0.276 13.631 0 13.631 C 0.276 13.631 0.5 13.407 0.5 13.131 L 0 13.131 L -0.5 13.131 Z M 0.5 20.202 C 0.5 19.926 0.276 19.702 0 19.702 C -0.276 19.702 -0.5 19.926 -0.5 20.202 L 0 20.202 L 0.5 20.202 Z M -0.5 24.242 C -0.5 24.519 -0.276 24.742 0 24.742 C 0.276 24.742 0.5 24.519 0.5 24.242 L 0 24.242 L -0.5 24.242 Z M 0.5 31.313 C 0.5 31.037 0.276 30.813 0 30.813 C -0.276 30.813 -0.5 31.037 -0.5 31.313 L 0 31.313 L 0.5 31.313 Z M -0.5 35.354 C -0.5 35.63 -0.276 35.854 0 35.854 C 0.276 35.854 0.5 35.63 0.5 35.354 L 0 35.354 L -0.5 35.354 Z M 0.5 42.424 C 0.5 42.148 0.276 41.924 0 41.924 C -0.276 41.924 -0.5 42.148 -0.5 42.424 L 0 42.424 L 0.5 42.424 Z M -0.5 46.465 C -0.5 46.741 -0.276 46.965 0 46.965 C 0.276 46.965 0.5 46.741 0.5 46.465 L 0 46.465 L -0.5 46.465 Z M 0.5 53.535 C 0.5 53.259 0.276 53.035 0 53.035 C -0.276 53.035 -0.5 53.259 -0.5 53.535 L 0 53.535 L 0.5 53.535 Z M -0.5 57.576 C -0.5 57.852 -0.276 58.076 0 58.076 C 0.276 58.076 0.5 57.852 0.5 57.576 L 0 57.576 L -0.5 57.576 Z M 0.5 64.646 C 0.5 64.37 0.276 64.146 0 64.146 C -0.276 64.146 -0.5 64.37 -0.5 64.646 L 0 64.646 L 0.5 64.646 Z M -0.5 68.687 C -0.5 68.963 -0.276 69.187 0 69.187 C 0.276 69.187 0.5 68.963 0.5 68.687 L 0 68.687 L -0.5 68.687 Z M 0.5 75.758 C 0.5 75.481 0.276 75.258 0 75.258 C -0.276 75.258 -0.5 75.481 -0.5 75.758 L 0 75.758 L 0.5 75.758 Z M -0.5 79.798 C -0.5 80.074 -0.276 80.298 0 80.298 C 0.276 80.298 0.5 80.074 0.5 79.798 L 0 79.798 L -0.5 79.798 Z M 0.5 86.869 C 0.5 86.593 0.276 86.369 0 86.369 C -0.276 86.369 -0.5 86.593 -0.5 86.869 L 0 86.869 L 0.5 86.869 Z M -0.5 90.909 C -0.5 91.185 -0.276 91.409 0 91.409 C 0.276 91.409 0.5 91.185 0.5 90.909 L 0 90.909 L -0.5 90.909 Z M 0.5 97.98 C 0.5 97.704 0.276 97.48 0 97.48 C -0.276 97.48 -0.5 97.704 -0.5 97.98 L 0 97.98 L 0.5 97.98 Z M 0 0 L -0.5 0 L -0.5 2.02 L 0 2.02 L 0.5 2.02 L 0.5 0 L 0 0 Z M 0 9.091 L -0.5 9.091 L -0.5 13.131 L 0 13.131 L 0.5 13.131 L 0.5 9.091 L 0 9.091 Z M 0 20.202 L -0.5 20.202 L -0.5 24.242 L 0 24.242 L 0.5 24.242 L 0.5 20.202 L 0 20.202 Z M 0 31.313 L -0.5 31.313 L -0.5 35.354 L 0 35.354 L 0.5 35.354 L 0.5 31.313 L 0 31.313 Z M 0 42.424 L -0.5 42.424 L -0.5 46.465 L 0 46.465 L 0.5 46.465 L 0.5 42.424 L 0 42.424 Z M 0 53.535 L -0.5 53.535 L -0.5 57.576 L 0 57.576 L 0.5 57.576 L 0.5 53.535 L 0 53.535 Z M 0 64.646 L -0.5 64.646 L -0.5 68.687 L 0 68.687 L 0.5 68.687 L 0.5 64.646 L 0 64.646 Z M 0 75.758 L -0.5 75.758 L -0.5 79.798 L 0 79.798 L 0.5 79.798 L 0.5 75.758 L 0 75.758 Z M 0 86.869 L -0.5 86.869 L -0.5 90.909 L 0 90.909 L 0.5 90.909 L 0.5 86.869 L 0 86.869 Z M 0 97.98 L -0.5 97.98 L -0.5 100 L 0 100 L 0.5 100 L 0.5 97.98 L 0 97.98 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })));
  const __body35 = () => /*#__PURE__*/React.createElement("div", {
    className: props.className,
    style: {
      width: "fit-content",
      height: 126,
      display: "flex",
      flexDirection: "column",
      gap: 16,
      justifyContent: "flex-end",
      alignItems: "center",
      flexWrap: "nowrap",
      position: "relative",
      ...props.style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      fontFamily: "Inter, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif",
      fontWeight: 400,
      fontSize: 14,
      textAlign: "center",
      lineHeight: "20px",
      textBox: "trim-both cap alphabetic",
      letterSpacing: "0.060em",
      color: "rgb(25,33,61)",
      flexShrink: 0,
      alignSelf: "stretch",
      whiteSpace: "nowrap"
    }
  }, props.text1 ?? "###"), /*#__PURE__*/React.createElement("svg", {
    width: 1,
    viewBox: "-0.500 0 1 100",
    fill: "none",
    style: {
      position: "relative",
      width: 1,
      flexGrow: 1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0.5 0 C 0.5 -0.276 0.276 -0.5 0 -0.5 C -0.276 -0.5 -0.5 -0.276 -0.5 0 L 0 0 L 0.5 0 Z M -0.5 100 C -0.5 100.276 -0.276 100.5 0 100.5 C 0.276 100.5 0.5 100.276 0.5 100 L 0 100 L -0.5 100 Z M -0.5 2.02 C -0.5 2.296 -0.276 2.52 0 2.52 C 0.276 2.52 0.5 2.296 0.5 2.02 L 0 2.02 L -0.5 2.02 Z M 0.5 9.091 C 0.5 8.815 0.276 8.591 0 8.591 C -0.276 8.591 -0.5 8.815 -0.5 9.091 L 0 9.091 L 0.5 9.091 Z M -0.5 13.131 C -0.5 13.407 -0.276 13.631 0 13.631 C 0.276 13.631 0.5 13.407 0.5 13.131 L 0 13.131 L -0.5 13.131 Z M 0.5 20.202 C 0.5 19.926 0.276 19.702 0 19.702 C -0.276 19.702 -0.5 19.926 -0.5 20.202 L 0 20.202 L 0.5 20.202 Z M -0.5 24.242 C -0.5 24.519 -0.276 24.742 0 24.742 C 0.276 24.742 0.5 24.519 0.5 24.242 L 0 24.242 L -0.5 24.242 Z M 0.5 31.313 C 0.5 31.037 0.276 30.813 0 30.813 C -0.276 30.813 -0.5 31.037 -0.5 31.313 L 0 31.313 L 0.5 31.313 Z M -0.5 35.354 C -0.5 35.63 -0.276 35.854 0 35.854 C 0.276 35.854 0.5 35.63 0.5 35.354 L 0 35.354 L -0.5 35.354 Z M 0.5 42.424 C 0.5 42.148 0.276 41.924 0 41.924 C -0.276 41.924 -0.5 42.148 -0.5 42.424 L 0 42.424 L 0.5 42.424 Z M -0.5 46.465 C -0.5 46.741 -0.276 46.965 0 46.965 C 0.276 46.965 0.5 46.741 0.5 46.465 L 0 46.465 L -0.5 46.465 Z M 0.5 53.535 C 0.5 53.259 0.276 53.035 0 53.035 C -0.276 53.035 -0.5 53.259 -0.5 53.535 L 0 53.535 L 0.5 53.535 Z M -0.5 57.576 C -0.5 57.852 -0.276 58.076 0 58.076 C 0.276 58.076 0.5 57.852 0.5 57.576 L 0 57.576 L -0.5 57.576 Z M 0.5 64.646 C 0.5 64.37 0.276 64.146 0 64.146 C -0.276 64.146 -0.5 64.37 -0.5 64.646 L 0 64.646 L 0.5 64.646 Z M -0.5 68.687 C -0.5 68.963 -0.276 69.187 0 69.187 C 0.276 69.187 0.5 68.963 0.5 68.687 L 0 68.687 L -0.5 68.687 Z M 0.5 75.758 C 0.5 75.481 0.276 75.258 0 75.258 C -0.276 75.258 -0.5 75.481 -0.5 75.758 L 0 75.758 L 0.5 75.758 Z M -0.5 79.798 C -0.5 80.074 -0.276 80.298 0 80.298 C 0.276 80.298 0.5 80.074 0.5 79.798 L 0 79.798 L -0.5 79.798 Z M 0.5 86.869 C 0.5 86.593 0.276 86.369 0 86.369 C -0.276 86.369 -0.5 86.593 -0.5 86.869 L 0 86.869 L 0.5 86.869 Z M -0.5 90.909 C -0.5 91.185 -0.276 91.409 0 91.409 C 0.276 91.409 0.5 91.185 0.5 90.909 L 0 90.909 L -0.5 90.909 Z M 0.5 97.98 C 0.5 97.704 0.276 97.48 0 97.48 C -0.276 97.48 -0.5 97.704 -0.5 97.98 L 0 97.98 L 0.5 97.98 Z M 0 0 L -0.5 0 L -0.5 2.02 L 0 2.02 L 0.5 2.02 L 0.5 0 L 0 0 Z M 0 9.091 L -0.5 9.091 L -0.5 13.131 L 0 13.131 L 0.5 13.131 L 0.5 9.091 L 0 9.091 Z M 0 20.202 L -0.5 20.202 L -0.5 24.242 L 0 24.242 L 0.5 24.242 L 0.5 20.202 L 0 20.202 Z M 0 31.313 L -0.5 31.313 L -0.5 35.354 L 0 35.354 L 0.5 35.354 L 0.5 31.313 L 0 31.313 Z M 0 42.424 L -0.5 42.424 L -0.5 46.465 L 0 46.465 L 0.5 46.465 L 0.5 42.424 L 0 42.424 Z M 0 53.535 L -0.5 53.535 L -0.5 57.576 L 0 57.576 L 0.5 57.576 L 0.5 53.535 L 0 53.535 Z M 0 64.646 L -0.5 64.646 L -0.5 68.687 L 0 68.687 L 0.5 68.687 L 0.5 64.646 L 0 64.646 Z M 0 75.758 L -0.5 75.758 L -0.5 79.798 L 0 79.798 L 0.5 79.798 L 0.5 75.758 L 0 75.758 Z M 0 86.869 L -0.5 86.869 L -0.5 90.909 L 0 90.909 L 0.5 90.909 L 0.5 86.869 L 0 86.869 Z M 0 97.98 L -0.5 97.98 L -0.5 100 L 0 100 L 0.5 100 L 0.5 97.98 L 0 97.98 Z",
    fill: "currentColor",
    fillRule: "nonzero"
  })));
  const __impls = {
    // figma: Type=X-Asis, Dash=False, Line=True, Inverted=False, Alignment=Top/Right
    "type=x-asis|alignment=top/right|dash=false|inverted=false|line=true": __body0,
    // figma: Type=Y-Asis, Dash=False, Line=True, Inverted=False, Alignment=Top/Right
    "type=y-asis|alignment=top/right|dash=false|inverted=false|line=true": __body1,
    // figma: Type=Y-Asis, Dash=False, Line=True, Inverted=False, Alignment=Center/Middle
    "type=y-asis|alignment=center/middle|dash=false|inverted=false|line=true": __body2,
    // figma: Type=Y-Asis, Dash=False, Line=True, Inverted=False, Alignment=Bottom/Left
    "type=y-asis|alignment=bottom/left|dash=false|inverted=false|line=true": __body3,
    // figma: Type=Y-Asis, Dash=False, Line=False, Inverted=False, Alignment=Top/Right
    "type=y-asis|alignment=top/right|dash=false|inverted=false|line=false": __body4,
    // figma: Type=Y-Asis, Dash=False, Line=False, Inverted=False, Alignment=Center/Middle
    "type=y-asis|alignment=center/middle|dash=false|inverted=false|line=false": __body5,
    // figma: Type=Y-Asis, Dash=False, Line=False, Inverted=False, Alignment=Bottom/Left
    "type=y-asis|alignment=bottom/left|dash=false|inverted=false|line=false": __body6,
    // figma: Type=Y-Asis, Dash=True, Line=True, Inverted=False, Alignment=Top/Right
    "type=y-asis|alignment=top/right|dash=true|inverted=false|line=true": __body7,
    // figma: Type=Y-Asis, Dash=True, Line=True, Inverted=False, Alignment=Center/Middle
    "type=y-asis|alignment=center/middle|dash=true|inverted=false|line=true": __body8,
    // figma: Type=Y-Asis, Dash=True, Line=True, Inverted=False, Alignment=Bottom/Left
    "type=y-asis|alignment=bottom/left|dash=true|inverted=false|line=true": __body9,
    // figma: Type=X-Asis, Dash=False, Line=True, Inverted=False, Alignment=Bottom/Left
    "type=x-asis|alignment=bottom/left|dash=false|inverted=false|line=true": __body10,
    // figma: Type=X-Asis, Dash=False, Line=True, Inverted=False, Alignment=Center/Middle
    "type=x-asis|alignment=center/middle|dash=false|inverted=false|line=true": __body11,
    // figma: Type=X-Asis, Dash=False, Line=False, Inverted=False, Alignment=Top/Right
    "type=x-asis|alignment=top/right|dash=false|inverted=false|line=false": __body12,
    // figma: Type=X-Asis, Dash=False, Line=False, Inverted=False, Alignment=Bottom/Left
    "type=x-asis|alignment=bottom/left|dash=false|inverted=false|line=false": __body13,
    // figma: Type=X-Asis, Dash=False, Line=False, Inverted=False, Alignment=Center/Middle
    "type=x-asis|alignment=center/middle|dash=false|inverted=false|line=false": __body14,
    // figma: Type=X-Asis, Dash=True, Line=True, Inverted=False, Alignment=Top/Right
    "type=x-asis|alignment=top/right|dash=true|inverted=false|line=true": __body15,
    // figma: Type=X-Asis, Dash=True, Line=True, Inverted=False, Alignment=Bottom/Left
    "type=x-asis|alignment=bottom/left|dash=true|inverted=false|line=true": __body16,
    // figma: Type=X-Asis, Dash=True, Line=True, Inverted=False, Alignment=Center/Middle
    "type=x-asis|alignment=center/middle|dash=true|inverted=false|line=true": __body17,
    // figma: Type=Y-Asis, Dash=False, Line=True, Inverted=True, Alignment=Top/Right
    "type=y-asis|alignment=top/right|dash=false|inverted=true|line=true": __body18,
    // figma: Type=Y-Asis, Dash=False, Line=True, Inverted=True, Alignment=Center/Middle
    "type=y-asis|alignment=center/middle|dash=false|inverted=true|line=true": __body19,
    // figma: Type=Y-Asis, Dash=False, Line=True, Inverted=True, Alignment=Bottom/Left
    "type=y-asis|alignment=bottom/left|dash=false|inverted=true|line=true": __body20,
    // figma: Type=Y-Asis, Dash=False, Line=False, Inverted=True, Alignment=Top/Right
    "type=y-asis|alignment=top/right|dash=false|inverted=true|line=false": __body21,
    // figma: Type=Y-Asis, Dash=False, Line=False, Inverted=True, Alignment=Center/Middle
    "type=y-asis|alignment=center/middle|dash=false|inverted=true|line=false": __body22,
    // figma: Type=Y-Asis, Dash=False, Line=False, Inverted=True, Alignment=Bottom/Left
    "type=y-asis|alignment=bottom/left|dash=false|inverted=true|line=false": __body23,
    // figma: Type=Y-Asis, Dash=True, Line=True, Inverted=True, Alignment=Top/Right
    "type=y-asis|alignment=top/right|dash=true|inverted=true|line=true": __body24,
    // figma: Type=Y-Asis, Dash=True, Line=True, Inverted=True, Alignment=Center/Middle
    "type=y-asis|alignment=center/middle|dash=true|inverted=true|line=true": __body25,
    // figma: Type=Y-Asis, Dash=True, Line=True, Inverted=True, Alignment=Bottom/Left
    "type=y-asis|alignment=bottom/left|dash=true|inverted=true|line=true": __body26,
    // figma: Type=X-Asis, Dash=False, Line=True, Inverted=True, Alignment=Top/Right
    "type=x-asis|alignment=top/right|dash=false|inverted=true|line=true": __body27,
    // figma: Type=X-Asis, Dash=False, Line=True, Inverted=True, Alignment=Bottom/Left
    "type=x-asis|alignment=bottom/left|dash=false|inverted=true|line=true": __body28,
    // figma: Type=X-Asis, Dash=False, Line=True, Inverted=True, Alignment=Center/Middle
    "type=x-asis|alignment=center/middle|dash=false|inverted=true|line=true": __body29,
    // figma: Type=X-Asis, Dash=False, Line=False, Inverted=True, Alignment=Top/Right
    "type=x-asis|alignment=top/right|dash=false|inverted=true|line=false": __body30,
    // figma: Type=X-Asis, Dash=False, Line=False, Inverted=True, Alignment=Bottom/Left
    "type=x-asis|alignment=bottom/left|dash=false|inverted=true|line=false": __body31,
    // figma: Type=X-Asis, Dash=False, Line=False, Inverted=True, Alignment=Center/Middle
    "type=x-asis|alignment=center/middle|dash=false|inverted=true|line=false": __body32,
    // figma: Type=X-Asis, Dash=True, Line=True, Inverted=True, Alignment=Top/Right
    "type=x-asis|alignment=top/right|dash=true|inverted=true|line=true": __body33,
    // figma: Type=X-Asis, Dash=True, Line=True, Inverted=True, Alignment=Bottom/Left
    "type=x-asis|alignment=bottom/left|dash=true|inverted=true|line=true": __body34,
    // figma: Type=X-Asis, Dash=True, Line=True, Inverted=True, Alignment=Center/Middle
    "type=x-asis|alignment=center/middle|dash=true|inverted=true|line=true": __body35
  };
  return (__impls[__vkey(props)] ?? __body26)();
}
Object.assign(__ds_scope, { XYAsis, __ds_default_components_misc_XYAsis_1y4h0c6: XYAsis });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/misc/XYAsis.jsx", error: String((e && e.message) || e) }); }

// components/navigation/BottomNav.jsx
try { (() => {
/**
 * Mobile bottom navigation — a floating translucent white bar. The active
 * item shows a muted pill behind its icon + label; labels are tiny (8–10px)
 * navy Lato Bold. Icons swap to their "selected" glyph when active.
 */
const DEFAULT_ITEMS = [{
  key: "home",
  label: "Home",
  icon: "IconHomeStateHomeSize1rem",
  selectedIcon: "IconHomeStateSelectedSize1rem"
}, {
  key: "action",
  label: "Action Plan",
  icon: "IconClipboardProperty1DefaultSize1rem",
  selectedIcon: "IconClipboardProperty1SelectedSize1rem"
}, {
  key: "content",
  label: "Content",
  icon: "IconBookProperty1DefaultSize1rem",
  selectedIcon: "IconBookProperty1SelectedSize1rem"
}, {
  key: "events",
  label: "Events",
  icon: "IconCalendarProperty1DefaultSize1rem",
  selectedIcon: "IconCalendarProperty1SelectedSize1rem"
}, {
  key: "life",
  label: "Life Events",
  icon: "IconLifeEventsProperty1DefaultSize1rem",
  selectedIcon: "IconLifeEventsProperty1SelectedSize1rem"
}];
function BottomNav({
  items = DEFAULT_ITEMS,
  active = "home",
  onNavigate,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: "4px",
      padding: "8px 16px 16px",
      backgroundColor: "rgba(255,255,255,0.9)",
      backdropFilter: "blur(8px)",
      boxShadow: "inset 0 0 0 1px var(--ff-white), 0 2px 4px rgba(214,220,234,0.4)",
      borderRadius: "var(--ff-radius-xl)",
      fontFamily: "var(--ff-font)",
      ...style
    }
  }, items.map(it => {
    const on = it.key === active;
    return /*#__PURE__*/React.createElement("button", {
      key: it.key,
      type: "button",
      onClick: () => onNavigate && onNavigate(it.key),
      style: {
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: "2px",
        padding: "6px 12px",
        border: "none",
        cursor: "pointer",
        borderRadius: "var(--ff-radius-pill)",
        backgroundColor: on ? "rgba(244,247,254,0.9)" : "transparent",
        color: on ? "var(--ff-navy)" : "var(--ff-ink)"
      }
    }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: on ? it.selectedIcon : it.icon,
      size: 24
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: "10px",
        fontWeight: "var(--ff-weight-bold)",
        color: "var(--ff-navy)"
      }
    }, it.label));
  }));
}
Object.assign(__ds_scope, { BottomNav });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/BottomNav.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Nav.jsx
try { (() => {
/**
 * Nav — a lightweight horizontal navigation link row (Figma "Nav"). Bold Lato
 * links; the active link is underlined. `TopNav` composes this inside the navy
 * header; use `Nav` on its own for sub-navigation.
 */
function Nav({
  items = [],
  active,
  onNavigate,
  tone = "ink",
  gap = 40,
  style = {}
}) {
  const color = tone === "white" ? "var(--ff-white)" : "var(--ff-text-primary)";
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      gap: `${gap}px`,
      fontFamily: "var(--ff-font)",
      ...style
    }
  }, items.map(it => {
    const label = typeof it === "string" ? it : it.label;
    const key = typeof it === "string" ? it : it.key || it.label;
    const on = key === active;
    return /*#__PURE__*/React.createElement("button", {
      key: key,
      type: "button",
      onClick: () => onNavigate && onNavigate(key),
      style: {
        border: "none",
        background: "transparent",
        cursor: "pointer",
        fontFamily: "var(--ff-font)",
        fontSize: "18px",
        fontWeight: "var(--ff-weight-bold)",
        color,
        opacity: on ? 1 : 0.82,
        padding: "4px 0",
        borderBottom: on ? `2px solid ${color}` : "2px solid transparent"
      }
    }, label);
  }));
}
Object.assign(__ds_scope, { Nav });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Nav.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tab.jsx
try { (() => {
/**
 * Tab — underline navigation tab. Selected tab shows navy label with a navy
 * underline; default is secondary-grey label, no underline.
 */
function Tab({
  children,
  selected = false,
  onClick,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClick,
    style: {
      border: "none",
      background: "transparent",
      cursor: "pointer",
      padding: "8px 4px",
      fontFamily: "var(--ff-font)",
      fontSize: "16px",
      fontWeight: "var(--ff-weight-bold)",
      color: selected ? "var(--ff-navy)" : "var(--ff-text-secondary)",
      borderBottom: selected ? "2px solid var(--ff-navy)" : "2px solid transparent",
      transition: "color .15s ease, border-color .15s ease",
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Tab });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tab.jsx", error: String((e && e.message) || e) }); }

// components/navigation/TopNav.jsx
try { (() => {
/**
 * Top navigation bar — the Hub's global header. Navy #063853 fill, white
 * logo, centred nav links (bold, white; active link is underlined), and a
 * right cluster of icon buttons + user avatar.
 */
function TopNav({
  items = ["Action Plan", "Content", "Events", "Coaches", "Life Events"],
  active = "Action Plan",
  onNavigate,
  user = {
    name: "Josh Miller"
  },
  notifications = 0,
  style = {}
}) {
  const iconBtn = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    width: "40px",
    height: "40px",
    border: "1.4px solid rgba(255,255,255,0.35)",
    borderRadius: "10px",
    background: "transparent",
    color: "var(--ff-white)",
    cursor: "pointer",
    position: "relative"
  };
  return /*#__PURE__*/React.createElement("header", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "24px",
      padding: "16px 40px",
      backgroundColor: "var(--ff-navy)",
      fontFamily: "var(--ff-font)",
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Logo, {
    variant: "icon",
    tone: "white",
    height: 40
  }), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      gap: "40px",
      margin: "0 auto"
    }
  }, items.map(it => {
    const on = it === active;
    return /*#__PURE__*/React.createElement("button", {
      key: it,
      type: "button",
      onClick: () => onNavigate && onNavigate(it),
      style: {
        border: "none",
        background: "transparent",
        cursor: "pointer",
        fontFamily: "var(--ff-font)",
        fontSize: "18px",
        fontWeight: "var(--ff-weight-bold)",
        color: "var(--ff-white)",
        opacity: on ? 1 : 0.82,
        padding: "4px 0",
        borderBottom: on ? "2px solid var(--ff-white)" : "2px solid transparent"
      }
    }, it);
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "12px"
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    style: iconBtn,
    "aria-label": "Messages"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "IconChatBubble",
    size: 22
  })), /*#__PURE__*/React.createElement("button", {
    type: "button",
    style: iconBtn,
    "aria-label": "Help"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "IconHelp",
    size: 22
  })), /*#__PURE__*/React.createElement("button", {
    type: "button",
    style: iconBtn,
    "aria-label": "Notifications"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "IconNotificationProperty1Bell",
    size: 22
  }), notifications > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: "7px",
      right: "8px",
      width: "8px",
      height: "8px",
      borderRadius: "50%",
      background: "var(--ff-accent-red)"
    }
  })), /*#__PURE__*/React.createElement(__ds_scope.Avatar, {
    name: user.name,
    src: user.src,
    size: 40
  })));
}
Object.assign(__ds_scope, { TopNav });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/TopNav.jsx", error: String((e && e.message) || e) }); }

// ui_kits/hub/HubAimee.jsx
try { (() => {
// Hub — Aimee full-screen chat. Greeting → quick prompts → live conversation.
const HA = window.FinancialFinesseDesignSystem_019e0d;
const PROMPTS = ["How much should I save for retirement?", "Help me build a budget", "Am I on track to pay off debt?", "Explain my HSA options"];
const REPLY = "Great question! Based on what you've shared, aim to save 15% of your income toward retirement — including any employer match. Want me to add a savings goal to your Action Plan?";
function HubAimee() {
  const [msgs, setMsgs] = React.useState([]);
  const [text, setText] = React.useState("");
  const send = t => {
    const q = (t ?? text).trim();
    if (!q) return;
    setMsgs(m => [...m, {
      role: "user",
      text: q
    }]);
    setText("");
    setTimeout(() => setMsgs(m => [...m, {
      role: "aimee",
      text: REPLY
    }]), 400);
  };
  const started = msgs.length > 0;
  return /*#__PURE__*/React.createElement("main", {
    style: {
      background: "var(--ff-white)",
      display: "flex",
      flexDirection: "column",
      height: "100%",
      maxWidth: 760,
      margin: "0 auto",
      width: "100%"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      gap: 8,
      padding: "20px 0"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 28,
      fontWeight: 900,
      color: "var(--ff-ink)"
    }
  }, "Aimee"), /*#__PURE__*/React.createElement("span", {
    style: {
      background: "var(--ff-blue)",
      color: "#fff",
      fontSize: 14,
      fontWeight: 700,
      padding: "2px 8px",
      borderRadius: 6
    }
  }, "AI")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: "auto",
      padding: "0 32px",
      display: "flex",
      flexDirection: "column",
      gap: 16,
      justifyContent: started ? "flex-start" : "center"
    }
  }, !started && /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center",
      display: "flex",
      flexDirection: "column",
      gap: 20,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 24,
      fontWeight: 700,
      color: "var(--ff-blue-dark)",
      lineHeight: 1.35
    }
  }, "Hi, Josh.", /*#__PURE__*/React.createElement("br", null), "What can I help you with today?"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      flexWrap: "wrap",
      justifyContent: "center",
      maxWidth: 620
    }
  }, PROMPTS.map(p => /*#__PURE__*/React.createElement(HA.ChatQuickReply, {
    key: p,
    onClick: () => send(p)
  }, p)))), msgs.map((m, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      alignSelf: m.role === "user" ? "flex-end" : "flex-start",
      maxWidth: "80%"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "12px 18px",
      borderRadius: 18,
      fontSize: 16,
      lineHeight: 1.5,
      background: m.role === "user" ? "var(--ff-navy)" : "var(--ff-surface-muted)",
      color: m.role === "user" ? "#fff" : "var(--ff-ink)"
    }
  }, m.text)))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "16px 32px 8px"
    }
  }, /*#__PURE__*/React.createElement(HA.Input, {
    placeholder: "Ask Aimee anything",
    button: "IconArrowUp",
    value: text,
    onChange: e => setText(e.target.value),
    onKeyDown: e => e.key === "Enter" && send(),
    onButtonClick: () => send(),
    containerStyle: {
      borderRadius: 16
    }
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      padding: "0 0 16px",
      textAlign: "center",
      fontSize: 12,
      color: "var(--ff-ink-soft)"
    }
  }, "Aimee can get things wrong. Double check answers."));
}
window.HubAimee = HubAimee;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/hub/HubAimee.jsx", error: String((e && e.message) || e) }); }

// ui_kits/hub/HubContent.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// Hub — Content Library screen. Filter chips + category rail + content grid.
const HC = window.FinancialFinesseDesignSystem_019e0d;
const LIBRARY = [{
  title: "25 Creative Ways to Find Extra Money in Your Budget",
  category: "articles",
  featured: true,
  minutes: 6
}, {
  title: "Retirement Savings Calculator",
  category: "calculators",
  minutes: 3
}, {
  title: "What Is an HSA and Should You Have One?",
  category: "bite-sized",
  minutes: 2
}, {
  title: "Building Your First Budget (Video)",
  category: "videos",
  featured: true,
  minutes: 9
}, {
  title: "The Anatomy of a Credit Score",
  category: "infographics",
  minutes: 4
}, {
  title: "Expert Q&A: Paying Down Student Loans",
  category: "expert",
  minutes: 7
}, {
  title: "Preparing Financially for a New Baby",
  category: "life-events",
  minutes: 5
}, {
  title: "How Compound Interest Works",
  category: "bite-sized",
  minutes: 2
}];
const FILTERS = ["All", "Articles", "Bite-Sized", "Calculators", "Videos", "Life Events"];
function HubContent() {
  const [f, setF] = React.useState("All");
  const [bm, setBm] = React.useState({});
  const [q, setQ] = React.useState("");
  const norm = s => s.toLowerCase().replace(/[^a-z]/g, "");
  const items = LIBRARY.filter(c => (f === "All" || norm(HC.ContentChips.categories[c.category].label) === norm(f)) && c.title.toLowerCase().includes(q.toLowerCase()));
  return /*#__PURE__*/React.createElement("main", {
    style: {
      background: "var(--ff-white)",
      padding: "40px 48px",
      display: "flex",
      flexDirection: "column",
      gap: 24,
      minHeight: "100%"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 24,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontSize: 32,
      fontWeight: 900,
      color: "var(--ff-ink)"
    }
  }, "Content Library"), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 340
    }
  }, /*#__PURE__*/React.createElement(HC.Input, {
    icon: "IconSearch",
    placeholder: "Search articles, calculators, videos\u2026",
    value: q,
    onChange: e => setQ(e.target.value)
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      flexWrap: "wrap"
    }
  }, FILTERS.map(x => /*#__PURE__*/React.createElement(HC.Chip, {
    key: x,
    selected: f === x,
    onClick: () => setF(x)
  }, x))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))",
      gap: 20
    }
  }, items.map((c, i) => /*#__PURE__*/React.createElement(HC.ContentThumbnailCard, _extends({
    key: c.title
  }, c, {
    width: "100%",
    bookmarked: !!bm[c.title],
    onBookmark: v => setBm({
      ...bm,
      [c.title]: v
    })
  })))), items.length === 0 && /*#__PURE__*/React.createElement("p", {
    style: {
      color: "var(--ff-ink-soft)"
    }
  }, "No results. Try another filter."));
}
window.HubContent = HubContent;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/hub/HubContent.jsx", error: String((e && e.message) || e) }); }

// ui_kits/hub/HubHome.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// Hub — Home / Dashboard screen. Recreates the FF Hub "Center panel" view:
// a muted left rail (Benefits Updates carousel, Progress, Connect with a Coach)
// and a white main column (welcome, top-priority action items, curated content).
const H = window.FinancialFinesseDesignSystem_019e0d;
function BenefitsUpdate() {
  const [i, setI] = React.useState(0);
  const slides = [{
    tag: "Benefits Updates",
    title: "Annual Enrollment is Open!",
    body: "Explore your benefits and preventive care options at the ABC Health Virtual Benefits Fair or join a new webcast to learn more.",
    cta: "Join a webcast"
  }, {
    tag: "Coaching",
    title: "Meet with a CFP® pro",
    body: "Book a free one-on-one session with a Certified Financial Planner™ this week.",
    cta: "Book a session"
  }, {
    tag: "New",
    title: "Your 2026 goals await",
    body: "Set fresh savings targets and let Aimee build your plan.",
    cta: "Set a goal"
  }];
  const s = slides[i];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--ff-white)",
      border: "1px solid var(--ff-border)",
      borderRadius: 16,
      padding: 24,
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(H.Tag, {
    inverse: true,
    uppercase: true
  }, s.tag), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontSize: 22,
      fontWeight: 700,
      color: "var(--ff-navy)",
      lineHeight: 1.25
    }
  }, s.title), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 16,
      lineHeight: 1.5,
      color: "var(--ff-ink-soft)"
    }
  }, s.body), /*#__PURE__*/React.createElement(H.Button, {
    variant: "secondary",
    style: {
      alignSelf: "stretch"
    }
  }, s.cta), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setI((i + slides.length - 1) % slides.length),
    style: arrowBtn,
    "aria-label": "Previous"
  }, /*#__PURE__*/React.createElement(H.Icon, {
    name: "IconChevronLeftSize1rem",
    size: 20
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: "var(--ff-ink-soft)"
    }
  }, i + 1, "/", slides.length), /*#__PURE__*/React.createElement("button", {
    onClick: () => setI((i + 1) % slides.length),
    style: arrowBtn,
    "aria-label": "Next"
  }, /*#__PURE__*/React.createElement(H.Icon, {
    name: "IconChevronRightSize1rem",
    size: 20
  }))));
}
const arrowBtn = {
  border: "none",
  background: "transparent",
  cursor: "pointer",
  color: "var(--ff-blue)",
  display: "inline-flex",
  padding: 4
};
function CoachRail() {
  const coaches = ["Marcus Lee", "Dana Ruiz", "Priya Shah", "Tom Berg"];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 12,
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex"
    }
  }, coaches.map((c, idx) => /*#__PURE__*/React.createElement("div", {
    key: c,
    style: {
      marginLeft: idx ? -10 : 0
    }
  }, /*#__PURE__*/React.createElement(H.Avatar, {
    name: c,
    size: 48,
    ring: true
  })))), /*#__PURE__*/React.createElement("h4", {
    style: {
      margin: 0,
      fontSize: 22,
      fontWeight: 700,
      color: "var(--ff-navy)"
    }
  }, "Connect with a Coach"), /*#__PURE__*/React.createElement(H.Button, {
    variant: "primary",
    icon: "IconUser",
    style: {
      width: "100%"
    }
  }, "Start a conversation"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 13,
      color: "var(--ff-ink-soft)",
      lineHeight: 1.4
    }
  }, "Live financial coaches are available:", /*#__PURE__*/React.createElement("br", null), "Monday to Friday, 9am to 8pm ET"));
}
const CURATED = [{
  title: "25 Creative Ways to Find Extra Money in Your Budget",
  category: "articles",
  featured: true,
  minutes: 6
}, {
  title: "How Much Should You Save for Retirement?",
  category: "calculators",
  minutes: 4
}, {
  title: "Understanding Your Emergency Fund",
  category: "videos",
  featured: true,
  minutes: 8
}, {
  title: "5 Signs You're Ready to Buy a Home",
  category: "life-events",
  minutes: 5
}];
function HubHome() {
  const [bm, setBm] = React.useState({});
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "340px 1fr",
      minHeight: "100%"
    }
  }, /*#__PURE__*/React.createElement("aside", {
    style: {
      background: "var(--ff-surface-muted)",
      padding: 24,
      display: "flex",
      flexDirection: "column",
      gap: 24,
      borderRight: "1px solid var(--ff-border)"
    }
  }, /*#__PURE__*/React.createElement(BenefitsUpdate, null), /*#__PURE__*/React.createElement(H.ProgressLevel, {
    level: 5,
    progress: 64
  }), /*#__PURE__*/React.createElement(CoachRail, null)), /*#__PURE__*/React.createElement("main", {
    style: {
      background: "var(--ff-white)",
      padding: "40px 48px",
      display: "flex",
      flexDirection: "column",
      gap: 32
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontSize: 40,
      fontWeight: 900,
      color: "var(--ff-ink)"
    }
  }, "Welcome, Josh!"), /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: "0 0 16px",
      fontSize: 24,
      fontWeight: 700,
      color: "var(--ff-ink)"
    }
  }, "Here are your top priorities"), /*#__PURE__*/React.createElement("div", {
    style: {
      border: "1px solid var(--ff-border)",
      borderRadius: 16,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement(H.ActionItem, {
    title: "Consider getting health insurance coverage",
    status: "in-progress"
  }), /*#__PURE__*/React.createElement(H.ActionItem, {
    title: "Build a starter emergency fund of $1,000",
    status: "assigned"
  }), /*#__PURE__*/React.createElement(H.ActionItem, {
    title: "Review your 401(k) contribution rate",
    status: "assigned",
    last: true
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement("button", {
    style: {
      width: "100%",
      padding: "16px",
      borderRadius: 999,
      border: "1px solid var(--ff-border)",
      background: "var(--ff-surface-muted)",
      fontFamily: "var(--ff-font)",
      fontSize: 16,
      fontWeight: 700,
      color: "var(--ff-ink)",
      cursor: "pointer"
    }
  }, "See My Action Plan"))), /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "0 0 16px",
      fontSize: 14,
      fontWeight: 700,
      letterSpacing: ".06em",
      textTransform: "uppercase",
      color: "var(--ff-ink-soft)"
    }
  }, "Curated for you"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))",
      gap: 20
    }
  }, CURATED.map((c, i) => /*#__PURE__*/React.createElement(H.ContentThumbnailCard, _extends({
    key: i
  }, c, {
    width: "100%",
    bookmarked: !!bm[i],
    onBookmark: v => setBm({
      ...bm,
      [i]: v
    })
  })))))));
}
window.HubHome = HubHome;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/hub/HubHome.jsx", error: String((e && e.message) || e) }); }

if (__ds_scope.__ds_default_assets_icons_icon_data_imae2q$nab192 === undefined) __ds_scope.__ds_default_assets_icons_icon_data_imae2q$nab192 = __ds_scope.__ds_default_assets_icons_icon_data_imae2q;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.AimeeLogo = __ds_scope.AimeeLogo;

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.AccentButton = __ds_scope.AccentButton;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.NavButton = __ds_scope.NavButton;

__ds_ns.PrimaryButton = __ds_scope.PrimaryButton;

__ds_ns.SecondaryButton = __ds_scope.SecondaryButton;

__ds_ns.TertiaryButton = __ds_scope.TertiaryButton;

__ds_ns.Accordion = __ds_scope.Accordion;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Chip = __ds_scope.Chip;

__ds_ns.ChipStructure = __ds_scope.ChipStructure;

__ds_ns.ContentChips = __ds_scope.ContentChips;

__ds_ns.ContentTags = __ds_scope.ContentTags;

__ds_ns.ContentThumbnailCard = __ds_scope.ContentThumbnailCard;

__ds_ns.ImagePlaceholder = __ds_scope.ImagePlaceholder;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.TagStructure = __ds_scope.TagStructure;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Toggle = __ds_scope.Toggle;

__ds_ns.IconAimee = __ds_scope.IconAimee;

__ds_ns.IconAlarm = __ds_scope.IconAlarm;

__ds_ns.IconArrowDown = __ds_scope.IconArrowDown;

__ds_ns.IconArrowLeft = __ds_scope.IconArrowLeft;

__ds_ns.IconArrowRight = __ds_scope.IconArrowRight;

__ds_ns.IconArrowUp = __ds_scope.IconArrowUp;

__ds_ns.IconArticles = __ds_scope.IconArticles;

__ds_ns.IconBiteSize = __ds_scope.IconBiteSize;

__ds_ns.IconBook = __ds_scope.IconBook;

__ds_ns.IconBookmark = __ds_scope.IconBookmark;

__ds_ns.IconBulb = __ds_scope.IconBulb;

__ds_ns.IconCalculator = __ds_scope.IconCalculator;

__ds_ns.IconCalendar = __ds_scope.IconCalendar;

__ds_ns.IconCalendarCheck = __ds_scope.IconCalendarCheck;

__ds_ns.IconCall = __ds_scope.IconCall;

__ds_ns.IconChatBubble = __ds_scope.IconChatBubble;

__ds_ns.IconCheck = __ds_scope.IconCheck;

__ds_ns.IconChevronDown = __ds_scope.IconChevronDown;

__ds_ns.IconChevronLeft = __ds_scope.IconChevronLeft;

__ds_ns.IconChevronRight = __ds_scope.IconChevronRight;

__ds_ns.IconChevronUp = __ds_scope.IconChevronUp;

__ds_ns.IconChipPlaceholder = __ds_scope.IconChipPlaceholder;

__ds_ns.IconClipboard = __ds_scope.IconClipboard;

__ds_ns.IconClose = __ds_scope.IconClose;

__ds_ns.IconCopy = __ds_scope.IconCopy;

__ds_ns.IconEdit = __ds_scope.IconEdit;

__ds_ns.IconExpand = __ds_scope.IconExpand;

__ds_ns.IconFilter = __ds_scope.IconFilter;

__ds_ns.IconHelp = __ds_scope.IconHelp;

__ds_ns.IconHome = __ds_scope.IconHome;

__ds_ns.IconInfo = __ds_scope.IconInfo;

__ds_ns.IconInfographic = __ds_scope.IconInfographic;

__ds_ns.IconLifeEvents = __ds_scope.IconLifeEvents;

__ds_ns.IconLogOut = __ds_scope.IconLogOut;

__ds_ns.IconMenu = __ds_scope.IconMenu;

__ds_ns.IconMenuDots = __ds_scope.IconMenuDots;

__ds_ns.IconMenuOpen = __ds_scope.IconMenuOpen;

__ds_ns.IconNotification = __ds_scope.IconNotification;

__ds_ns.IconPlus = __ds_scope.IconPlus;

__ds_ns.IconReset = __ds_scope.IconReset;

__ds_ns.IconSearch = __ds_scope.IconSearch;

__ds_ns.IconShare = __ds_scope.IconShare;

__ds_ns.IconShow = __ds_scope.IconShow;

__ds_ns.IconStars = __ds_scope.IconStars;

__ds_ns.IconUser = __ds_scope.IconUser;

__ds_ns.IconVideos = __ds_scope.IconVideos;

__ds_ns.IconWorld = __ds_scope.IconWorld;

__ds_ns.ActionItem = __ds_scope.ActionItem;

__ds_ns.Aimee = __ds_scope.Aimee;

__ds_ns.AimeeWidget = __ds_scope.AimeeWidget;

__ds_ns.AimeeLauncher = __ds_scope.AimeeLauncher;

__ds_ns.BadgeCard = __ds_scope.BadgeCard;

__ds_ns.Beak = __ds_scope.Beak;

__ds_ns.BeakWrapper = __ds_scope.BeakWrapper;

__ds_ns.Benefit = __ds_scope.Benefit;

__ds_ns.ChatQuickReply = __ds_scope.ChatQuickReply;

__ds_ns.EventsCards = __ds_scope.EventsCards;

__ds_ns.HomeSummaryCard = __ds_scope.HomeSummaryCard;

__ds_ns.LifeEventCard = __ds_scope.LifeEventCard;

__ds_ns.MilestoneBadge = __ds_scope.MilestoneBadge;

__ds_ns.MyFinancialWellnessScore = __ds_scope.MyFinancialWellnessScore;

__ds_ns.Notif = __ds_scope.Notif;

__ds_ns.NotifList = __ds_scope.NotifList;

__ds_ns.ProgressLevel = __ds_scope.ProgressLevel;

__ds_ns.SmallMilestoneBadge = __ds_scope.SmallMilestoneBadge;

__ds_ns.SmallMilsetoneBadge = __ds_scope.SmallMilsetoneBadge;

__ds_ns.StatusDropdown = __ds_scope.StatusDropdown;

__ds_ns.StatusIndicator = __ds_scope.StatusIndicator;

__ds_ns.StatusPill = __ds_scope.StatusPill;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Image11LandscapeNone = __ds_scope.Image11LandscapeNone;

__ds_ns.Image21LandscapeNone = __ds_scope.Image21LandscapeNone;

__ds_ns.Component2 = __ds_scope.Component2;

__ds_ns.Frame1000004665 = __ds_scope.Frame1000004665;

__ds_ns.Frame1000004752 = __ds_scope.Frame1000004752;

__ds_ns.Frame2087327407 = __ds_scope.Frame2087327407;

__ds_ns.Frame36070 = __ds_scope.Frame36070;

__ds_ns.Group6829 = __ds_scope.Group6829;

__ds_ns.Group6832 = __ds_scope.Group6832;

__ds_ns.XYAsis = __ds_scope.XYAsis;

__ds_ns.BottomNav = __ds_scope.BottomNav;

__ds_ns.Nav = __ds_scope.Nav;

__ds_ns.Tab = __ds_scope.Tab;

__ds_ns.TopNav = __ds_scope.TopNav;

})();
