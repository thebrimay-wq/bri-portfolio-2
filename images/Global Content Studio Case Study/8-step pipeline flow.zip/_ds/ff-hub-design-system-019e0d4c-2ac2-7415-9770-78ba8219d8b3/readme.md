# Financial Finesse Design System

A design system for the **Financial Finesse Hub** — an employer-sponsored
financial-wellness platform. Members land in a personalized hub where they get
an **Action Plan** of prioritized next steps, a curated **Content** library
(articles, videos, calculators, life-event guides), live **Coaches**, and
**Aimee**, an AI financial guide. The tone is warm, plain-spoken, and
encouraging — money coaching, not banking software.

This project is the extracted, runnable design system: brand tokens, the Lato
type system, the icon set, reusable React components, and a click-through Hub
UI kit.

---

## Sources
- **Figma:** "FF Hub [Public].fig" (mounted). Primary pages used:
  `Pages---V3.2---Feb-2026` (V3.2 Hub screens — Center panel, Aimee, Action
  Plan, NPS), `Components` (the canonical component library), `Aimee-Chat`,
  `Aimee-Onboarding-Flow`, `FF-Content---Quizzes`, `FF-Content---User-Stories`,
  `Gamification`. 425 Figma Variables across 6 collections were extracted
  verbatim into `materialized/fig-tokens.css`.
- **Uploaded brand assets:** `uploads/ff-logo.svg` (FINESSE wordmark),
  `uploads/ff-icon.svg` (circular F mark).
- No production codebase was provided; components are recreations from the
  Figma component sets (exact paddings, radii, and colors copied from the
  reconstructed JSX, not rounded).

---

## Logo & brand mark
The uploaded logo/icon SVGs are the real Financial Finesse mark. Their gradient
class bindings were lost on export (the `<svg>` referenced undefined `cls-1`/
`cls-2`), so `assets/logo/` also carries recolored solid variants
(`*-navy.svg`, `*-white.svg`) and the `Logo` component renders a **monochrome
silhouette** (navy on light, white on the navy nav). This matches how the app
tokenizes the logo (`--surfaces-color-logo = primary-blue-3`). **If you need
the full-color gradient mark, please re-supply a logo SVG with intact fills.**

---

## CONTENT FUNDAMENTALS
How Financial Finesse writes.

- **Voice:** warm, plain-English coach. Second person ("you", "your money"),
  first person for Aimee ("I can help you…"). Never lectures, never jargon-heavy.
- **Address the member by first name:** "Welcome, Josh!", "Hi, Josh. What can
  I help you with today?"
- **Casing:** Title Case for nav, section eyebrows in ALL-CAPS with letter-
  spacing ("BENEFITS UPDATES", "CURATED FOR YOU", "YOUR PROGRESS"). Headings in
  sentence case ("Here are your top priorities").
- **Encouraging, action-first copy:** action items start with a verb —
  "Consider getting health insurance coverage", "Build a starter emergency
  fund". CTAs are short and concrete — "Join a webcast", "Start a conversation",
  "See My Action Plan".
- **Honest about AI:** Aimee always shows "Aimee can get things wrong. Double
  check answers."
- **No emoji.** Iconography and color carry the friendliness; copy stays
  professional but approachable.
- **Numbers are human:** "9am to 8pm ET", "$1,000", "15% of your income" —
  round, legible, never precise-to-the-cent unless it's real data.

---

## VISUAL FOUNDATIONS

**Color.** A deep-blue brand ramp anchors everything: **Navy `#063853`** (top
nav, primary buttons, logo, headings-on-light), **Blue Dark `#00507C`** (links,
Aimee greeting), **Blue `#007CAB`** (accent circle buttons, toggles/checkbox
"on", the "AI" badge). Neutrals are warm-grey ink `#383838` / `#565656` on
white, with a signature **muted lavender-white `#F4F7FE`** for the left rail
and secondary buttons, bordered by **`#D6DCEA`**. Content is color-coded by
category with soft pastel tints (articles=yellow, bite-sized=blue,
calculators=green, expert=teal, infographics=grey, life-events=orange,
videos=purple). Status uses tint+dot pills (assigned=grey, in-progress=yellow,
completed=green).

**Type.** **Lato** for everything — headings and body. Weights: Regular 400,
Bold 700, Black 900 (hero numbers/wordmark). The source uses SemiBold 600 for
controls; Google Fonts Lato ships 400/700/900, so **700 substitutes for 600** —
flagged below. Scale runs 12 → 48px; body 16, small 14, captions/eyebrows 12
uppercase.

**Shape & elevation.** Everything is soft and rounded. Buttons, tags, chips,
status pills, and inputs are **fully pill-shaped** (radius 32+). Cards use
**16px** radius, large panels 24px. Borders are a hairline `#D6DCEA`.
Elevation is gentle and cool: `0 4px 16px rgba(214,220,234,.4)` on cards,
`0 8px 24px rgba(0,0,0,.12)` on popovers/tooltips. Content thumbnails and life-
event tiles carry a 1px inner border on the image.

**Backgrounds & imagery.** Flat color — no gradients, no textures, no patterns.
The app is a white canvas beside a `#F4F7FE` rail. Photography is warm,
natural-light lifestyle portraits (people reading, working); unfilled images
use a neutral `#D9D9D9` placeholder (kept in this kit as image slots).

**Motion.** Restrained. Color/opacity transitions ~.15s ease on hover; chevrons
rotate .2s; the toggle knob slides. No bounces, no infinite loops.

**States.** Hover lightens/darkens fills a step (secondary → `#EBEEF4`, nav
link gains an underline, tertiary text → blue). Selected = filled (chip →
navy, quick-reply → deep blue, tab → navy underline). Disabled = 40% opacity.
Press is a subtle transform, not a color change.

**Layout.** Desktop Hub is a fixed navy top bar + a two-column body
(340px rail / fluid main, 40–48px main padding). Mobile uses a floating
translucent-white bottom nav with a blurred backdrop. Aimee floats as a
launcher (white circle, blue ring) and expands to a panel or full screen.

---

## ICONOGRAPHY
- **One custom line-icon set**, ~46 glyphs, extracted to
  `assets/icons/icon-data.js` and rendered via `<Icon name="…" size={…} />`
  (`assets/icons/Icon.jsx`; valid names in `Icon.d.ts`). Style: **rounded,
  ~1.5px stroke, single-color** — they paint with `currentColor`, so set the
  CSS `color`. Sizes are 1rem (24) and 1.5rem in the source; render at 20–24px.
- Coverage: navigation (home, clipboard/action, book/content, calendar,
  life-events), chrome (search, close, chevrons, arrows, menu, notification),
  content actions (bookmark, share, filter, expand), and product glyphs
  (aimee, stars, bulb, calculator, chat-bubble, infographic, videos, articles).
- **Selected/default pairs:** several nav icons ship a filled "selected"
  variant (e.g. `IconHomeStateSelectedSize1rem`) — `BottomNav` swaps them.
- **No emoji, no unicode-glyph icons.** Do not hand-draw new icons; reuse the
  set or request additions.

---

## Foundations (tokens)
`styles.css` is the entry point (consumers link this one file). It `@import`s:
- `tokens/fonts.css` — Lato `@font-face` (Google Fonts).
- `materialized/fig-tokens.css` — all 425 Figma Variables, verbatim
  (colors, font sizes, spacing "Units", radii, stroke weights; incl. mobile/
  tablet mode scopes).
- `tokens/semantic.css` — friendly `--ff-*` aliases to author against (brand
  palette, category tints, status colors, type scale, spacing, radii, shadows).

---

## Components
Namespace: `window.FinancialFinesseDesignSystem_019e0d`. All are React
components referencing the CSS tokens.

**buttons/** — `Button` (primary · secondary · tertiary · nav; sizes; icon;
icon-only), `AccentButton` (circular blue icon FAB).
**forms/** — `Input` (pill field + optional icon/accent button), `Checkbox`,
`Toggle`.
**content/** — `ContentThumbnailCard` (curated/library thumbnail),
`ContentChips` (taxonomy-tinted), `Chip` (filter), `Tag` (eyebrow/FEATURED),
`ChipStructure` / `TagStructure` (base shells the chips/tags compose from),
`ImagePlaceholder`, `Accordion`, `Avatar`.
**navigation/** — `TopNav` (navy global header), `BottomNav` (mobile floating),
`Tab` (underline).
**hub/** — `StatusPill`, `StatusDropdown`, `StatusIndicator`, `ActionItem`,
`ChatQuickReply`, `Tooltip`, `MilestoneBadge`, `LifeEventCard`, `EventsCards`,
`HomeSummaryCard`, `NotificationItem`, `Benefit`, `BadgeCard`, `ProgressLevel`,
`Aimee`, `AimeeWidget` + `AimeeLauncher`.
**brand/** — `Logo` (wordmark/icon, navy/white), `AimeeLogo`.
**assets/icons/** — `Icon`.

### Intentional additions / substitutions
- **`Tooltip` positions & `ProgressLevel` bar** are generalized beyond the raw
  Figma variants for real use.
- **`MilestoneBadge`** substitutes an icon glyph for the source's bespoke
  per-badge illustrations (pass `art` to supply real artwork).
- **Font weight 600 → 700** (Google Lato has no SemiBold).

**hub/** additions — `HomeSummaryCard`, `EventsCards` (card + compact),
`StatusIndicator`. **content/** — `ImagePlaceholder`. **brand/** — `AimeeLogo`.

### Scope note — 159 families → 38 canonical components
The Figma file reports **159 component "families,"** but that count is inflated
by duplication, an icon set, and internal substructure. This system implements
the **canonical `/Components`-page inventory once**; every *distinct,
user-facing* family is covered. The ~120 uncovered "families" are:

- **The ~41-glyph icon set** (`icon/aimee`, `icon/arrow-down`, `icon/home`, …).
  By design this ships as **one `Icon` component + `assets/icons/icon-data.js`**
  (the recommended approach for icon sets) — not ~41 separate component files.
  This alone accounts for the bulk of the "unbuilt" count.
- **Exact duplicates across page revisions** — buttons, tags, chips, inputs,
  bottom navs, avatars, tooltips, statuses each appear 2–4× (one copy per
  V3.0 / V3.1 / V3.2 / Aimee / working-files page). Built once each.
- **Chart internals & junk frames** — `XY-Asis` (a 36-variant chart axis left
  over from an html.to.design import; no charts exist in the FF Hub product, so
  it is out of scope) and auto-named layout artifacts the Figma file left
  behind (`Component 2`, `Frame 1000004665`, `Frame 1000004752`,
  `Frame 2087327407`, `Frame 36070`, `Group 6829`, `Group 6832`). These are not
  real product components and are intentionally not built.

The `image/1:1` and `image/2:1` symbols are materialized as
`Image11LandscapeNone` / `Image21LandscapeNone` (see `components/media/`).
**`ProgressLevel`** is the one intentional composite — the gamification
progress-level header — with no 1:1 named family in the source; kept under a
clear English name.
- **`Small Milsetone Badge`** — a misspelled duplicate of the milestone badge;
  built as **`SmallMilestoneBadge`** (correct spelling).

Distinct families ARE all built, including base shells (`ChipStructure`,
`TagStructure`), the button-variant presets (`PrimaryButton`, `SecondaryButton`,
`TertiaryButton`, `NavButton`), both chip/tag content variants (`ContentChips`,
`ContentTags`), the status set (`StatusPill`, `StatusDropdown`,
`StatusIndicator`), the Aimee set (`Aimee`, `AimeeLogo`, `AimeeWidget`), and a
named wrapper component for every icon glyph (see `components/glyphs/`).

**Data maps (not components):** `ContentChips.categories`, `StatusPill.statuses`,
and `StatusIndicator.states` are exposed as **static properties**, not bundle
exports. **`Notif`** / **`NotifList`** map to the kit's `notif` / `notif list`
families. **`ProgressLevel`** is an intentional composite (the gamification
progress header) with no 1:1 named family; kept under a clear English name.

No net-new components were invented beyond the substitutions noted above.

### Full component index (every bundled component)
**buttons/** — `Button`, `PrimaryButton`, `SecondaryButton`, `TertiaryButton`,
`NavButton`, `AccentButton`.
**forms/** — `Input`, `Checkbox`, `Toggle`.
**content/** — `ContentThumbnailCard`, `ContentChips`, `ContentTags`, `Chip`,
`Tag`, `ChipStructure`, `TagStructure`, `ImagePlaceholder`, `Accordion`, `Avatar`.
**navigation/** — `TopNav`, `Nav`, `BottomNav`, `Tab`.
**hub/** — `StatusPill`, `StatusDropdown`, `StatusIndicator`, `ActionItem`,
`ChatQuickReply`, `Tooltip`, `MilestoneBadge`, `SmallMilestoneBadge`,
`LifeEventCard`, `EventsCards`, `HomeSummaryCard`, `Notif`, `NotifList`,
`Benefit`, `BadgeCard`, `ProgressLevel`, `MyFinancialWellnessScore`, `Aimee`, `AimeeWidget`, `AimeeLauncher`, `Beak`, `BeakWrapper`, `SmallMilsetoneBadge`.
**brand/** — `Logo`, `AimeeLogo`.
**assets/icons/** — `Icon` (data-driven, all glyphs).
**media/** — `Image11LandscapeNone`, `Image21LandscapeNone` (materialized image symbols).
**misc/** — verbatim-materialized source leftovers (not part of the product API,
included only for full-file coverage): `XYAsis` (chart axis), `Component2`,
`Frame1000004665`, `Frame1000004752`, `Frame2087327407`, `Frame36070`,
`Group6829`, `Group6832`.
**glyphs/** — named per-icon wrappers: `IconAimee`, `IconAlarm`, `IconArrowDown`,
`IconArrowLeft`, `IconArrowRight`, `IconArrowUp`, `IconArticles`, `IconBiteSize`,
`IconBook`, `IconBookmark`, `IconBulb`, `IconCalculator`, `IconCalendar`,
`IconCalendarCheck`, `IconCall`, `IconChatBubble`, `IconCheck`, `IconChevronDown`,
`IconChevronLeft`, `IconChevronRight`, `IconChevronUp`, `IconClipboard`,
`IconClose`, `IconCopy`, `IconEdit`, `IconExpand`, `IconFilter`, `IconHelp`,
`IconHome`, `IconInfo`, `IconInfographic`, `IconLifeEvents`, `IconLogOut`,
`IconMenu`, `IconMenuDots`, `IconMenuOpen`, `IconNotification`, `IconPlus`,
`IconReset`, `IconSearch`, `IconShare`, `IconShow`, `IconStars`, `IconUser`,
`IconVideos`, `IconWorld`, `IconChipPlaceholder`.

---

## UI kits
- **ui_kits/hub/** — the Financial Finesse Hub (desktop): Home dashboard,
  Content library, and Aimee chat, click-through via the top nav.

---

## Index / manifest
- `styles.css` — global CSS entry (link this).
- `tokens/` — `fonts.css`, `semantic.css`.
- `materialized/` — `fig-tokens.css`, `fig-typography.css` (Figma extraction).
- `assets/logo/` — logo/icon SVGs (original + navy/white variants).
- `assets/icons/` — `icon-data.js`, `Icon.jsx`, `Icon.d.ts`, `icons.card.html`.
- `components/{buttons,forms,content,navigation,hub,brand}/` — components +
  `.d.ts` + `@dsCard` HTML.
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing).
- `ui_kits/hub/` — the Hub UI kit (`index.html` + screen JSX).
- `SKILL.md` — Agent-Skill entry point.

---

## Caveats
- Full-color **gradient logo** unavailable (export lost fills) — mark renders
  monochrome; re-supply an SVG for the gradient version.
- **SemiBold (600)** not available on Google Lato → 700 used.
- Milestone/achievement **illustrations** substituted with icon glyphs.
- Content **photography** shown as neutral placeholders (source images are
  licensed stock, not in scope).
